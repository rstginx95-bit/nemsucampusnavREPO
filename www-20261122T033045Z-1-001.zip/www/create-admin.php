<?php
declare(strict_types=1);
header('Cache-Control: no-store, private');
header('X-Robots-Tag: noindex, nofollow', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/auth_page.php';

$errors = [];
$email = '';
// If an admin already exists, permit recovery setup only from the same computer (loopback).
// This lets a Laragon developer create a replacement admin without exposing public admin signup.
$adminExists = (int)q("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn() > 0;
$remoteAddress = (string)($_SERVER['REMOTE_ADDR'] ?? '');
$isLocalRequest = in_array($remoteAddress, ['127.0.0.1', '::1'], true);
if ($adminExists && !$isLocalRequest) {
    http_response_code(403);
    auth_start('Admin setup unavailable');
    ?>
    <section class="holo card enter">
      <h1>Admin setup unavailable</h1>
      <p class="muted">An administrator account already exists. For security, creating a replacement Admin is allowed only from the local Laragon computer.</p>
      <a class="btn btn-primary" href="<?= e(app_url('admin-login.php')) ?>">Go to Admin Login</a>
    </section>
    <?php auth_end();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if ($password !== $confirm) $errors[] = 'The passwords do not match.';
    $problem = password_problem($password, $email);
    if ($problem !== null) $errors[] = $problem;
    if (!$errors) {
        $lock = (int)q("SELECT GET_LOCK('campusnav_admin_setup', 10)")->fetchColumn();
        if ($lock !== 1) {
            $errors[] = 'Admin setup is busy. Please try again.';
        } else {
            try {
                if ((int)q("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn() > 0 && !$isLocalRequest) {
                    $errors[] = 'Admin recovery setup is available only from the local Laragon computer.';
                } elseif (q('SELECT id FROM users WHERE LOWER(email) = LOWER(?) LIMIT 1', [$email])->fetch()) {
                    $errors[] = 'That email is already registered. Use a different email address.';
                } else {
                    $now = date('Y-m-d H:i:s');
                    db()->beginTransaction();
                    try {
                        q("INSERT INTO users (email, password_hash, full_name, profile_done, role, requested_role, status, email_verified_at, activated_at, approved_at, password_changed_at) VALUES (?, ?, 'Administrator', 1, 'admin', 'student', 'approved', ?, ?, ?, ?)",
                            [$email, hash_password($password), $now, $now, $now, $now]);
                        $newId = (int)db()->lastInsertId();
                        // Revoke Admin access from every previous administrator without deleting
                        // their user rows or related history. Only the newly created account stays Admin.
                        q("UPDATE users SET role = 'student', requested_role = 'student', status = 'suspended' WHERE role = 'admin' AND id <> ?", [$newId]);
                        audit($adminExists ? 'replacement_admin_created' : 'first_admin_created', 'user', $newId, $adminExists ? 'New administrator created; previous administrator access revoked' : 'Initial administrator account created');
                        db()->commit();
                    } catch (Throwable $e) {
                        if (db()->inTransaction()) db()->rollBack();
                        throw $e;
                    }
                    flash('success', 'Administrator account created. You can now sign in.');
                    redirect('admin-login.php');
                }
            } finally {
                q("SELECT RELEASE_LOCK('campusnav_admin_setup')");
            }
        }
    }
}

auth_start('Create administrator account');
?>
<section class="holo card enter" id="card" aria-labelledby="t">
  <h1 id="t">Create Admin Account</h1>
  <p class="muted"><?= $adminExists ? 'Create your new Admin account from this local Laragon computer. After creation, previous Admin access will be revoked; their records will be retained.' : 'Set up the first administrator account for NEMSU CampusNav AI.' ?></p>
  <?php auth_errors($errors); ?>
  <form method="post" class="form" autocomplete="on">
    <?= csrf_field() ?>
    <label class="field">Email address
      <input type="email" name="email" value="<?= e($email) ?>" autocomplete="email" placeholder="Enter admin email" required>
    </label>
    <label class="field">Password
      <input type="password" name="password" autocomplete="new-password" minlength="12" required>
    </label>
    <label class="field">Confirm password
      <input type="password" name="confirm_password" autocomplete="new-password" minlength="12" required>
    </label>
    <button class="btn btn-primary" type="submit">Create Admin Account</button>
    <a class="hu center-link" href="<?= e(app_url('admin-login.php')) ?>">Back to Admin Login</a>
  </form>
  <p class="foot muted">This setup page is restricted to the local Laragon computer when an Admin already exists. Creating a new Admin revokes previous Admin access but retains existing user records. Passwords are securely hashed.</p>
  <?php render_safety_notes(false); ?>
</section>
<?php auth_end(); ?>
