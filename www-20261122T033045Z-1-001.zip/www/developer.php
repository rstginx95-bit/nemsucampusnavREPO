<?php

require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';

$developer = require_developer();

$counts = [
    'total' => 0,
    'students' => 0,
    'staff' => 0,
    'pending' => 0,
    'approved' => 0,
    'suspended' => 0
];

$recentUsers = [];
$recentLogs = [];
$dashboardError = '';

try {
    $counts['total'] = (int) q(
        "SELECT COUNT(*) FROM users"
    )->fetchColumn();

    $counts['students'] = (int) q(
        "SELECT COUNT(*) FROM users
         WHERE role = 'student'"
    )->fetchColumn();

    $counts['staff'] = (int) q(
        "SELECT COUNT(*) FROM users
         WHERE role IN ('admin', 'staff', 'instructor')"
    )->fetchColumn();

    $counts['pending'] = (int) q(
        "SELECT COUNT(*) FROM users
         WHERE status IN (
            'pending_admin',
            'pending_identity',
            'pending_email'
         )"
    )->fetchColumn();

    $counts['approved'] = (int) q(
        "SELECT COUNT(*) FROM users
         WHERE status = 'approved'"
    )->fetchColumn();

    $counts['suspended'] = (int) q(
        "SELECT COUNT(*) FROM users
         WHERE status = 'suspended'"
    )->fetchColumn();

    $recentUsers = q(
        "SELECT id, full_name, email, role,
                status, created_at
         FROM users
         ORDER BY created_at DESC
         LIMIT 20"
    )->fetchAll(PDO::FETCH_ASSOC);

    $recentLogs = q(
        "SELECT a.action, a.target_type,
                a.target_id, a.created_at,
                u.full_name AS actor_name
         FROM audit_log a
         LEFT JOIN users u
             ON u.id = a.actor_id
         ORDER BY a.id DESC
         LIMIT 20"
    )->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $exception) {
    error_log(
        'Developer dashboard error: ' .
        $exception->getMessage()
    );

    $dashboardError =
        'Some dashboard information could not be loaded. ' .
        'Please check the database structure.';
}

render_head('Developer Control Center', 'admin');
?>

<style>
.dev-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 24px 16px 70px;
}

.dev-header {
    margin-bottom: 26px;
}

.dev-header h1 {
    font-size: clamp(26px, 4vw, 36px);
    margin-bottom: 8px;
}

.dev-subtitle {
    opacity: 0.7;
}

.dev-grid {
    display: grid;
    grid-template-columns: repeat(
        auto-fit,
        minmax(160px, 1fr)
    );
    gap: 16px;
    margin: 22px 0 30px;
}

.dev-card {
    background: #ffffff;
    color: #172b22;
    border: 1px solid #e3e8e5;
    border-radius: 14px;
    padding: 22px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04);
}

.dev-card strong {
    display: block;
    font-size: 30px;
    margin-top: 10px;
    color: #145c3b;
}

.dev-card span {
    font-size: 14px;
}

.dev-section {
    margin: 30px 0;
}

.dev-section h2 {
    margin-bottom: 16px;
}

.dev-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
}

.dev-button {
    display: inline-block;
    padding: 12px 18px;
    border-radius: 9px;
    background: #145c3b;
    color: white;
    text-decoration: none;
    font-weight: 600;
}

.dev-button:hover {
    background: #0b4028;
    color: white;
}

.dev-table-wrap {
    overflow-x: auto;
    background: white;
    border-radius: 12px;
    border: 1px solid #e3e8e5;
}

.dev-table {
    width: 100%;
    border-collapse: collapse;
    color: #172b22;
    font-size: 14px;
}

.dev-table th,
.dev-table td {
    padding: 13px;
    text-align: left;
    border-bottom: 1px solid #edf0ee;
    white-space: nowrap;
}

.dev-table th {
    background: #f2f7f4;
}

.dev-note {
    margin-top: 18px;
    font-size: 13px;
    opacity: 0.7;
}

.dev-error {
    padding: 15px;
    border-radius: 10px;
    margin: 20px 0;
    background: #fff3f3;
    border: 1px solid #ffc9c9;
    color: #9c2020;
}

@media (max-width: 600px) {
    .dev-container {
        padding: 16px 12px 50px;
    }

    .dev-card {
        padding: 16px;
    }

    .dev-table {
        font-size: 12px;
    }
}
</style>

<main class="dev-container">

    <header class="dev-header">

        <h1>Developer Control Center</h1>

        <p class="dev-subtitle">
            NEMSU CampusNav AI — System Administration
        </p>

        <p>
            Signed in as:
            <strong>
                <?= e(
                    $developer['full_name']
                    ?: $developer['email']
                ) ?>
            </strong>
        </p>

    </header>

    <?php if ($dashboardError !== ''): ?>

        <div class="dev-error" role="alert">
            <?= e($dashboardError) ?>
        </div>

    <?php endif; ?>

    <section
        class="dev-grid"
        aria-label="Account statistics"
    >

        <div class="dev-card">
            <span>Total Accounts</span>
            <strong>
                <?= $counts['total'] ?>
            </strong>
        </div>

        <div class="dev-card">
            <span>Students</span>
            <strong>
                <?= $counts['students'] ?>
            </strong>
        </div>

        <div class="dev-card">
            <span>Staff and Administrators</span>
            <strong>
                <?= $counts['staff'] ?>
            </strong>
        </div>

        <div class="dev-card">
            <span>Pending Accounts</span>
            <strong>
                <?= $counts['pending'] ?>
            </strong>
        </div>

        <div class="dev-card">
            <span>Approved Accounts</span>
            <strong>
                <?= $counts['approved'] ?>
            </strong>
        </div>

        <div class="dev-card">
            <span>Suspended Accounts</span>
            <strong>
                <?= $counts['suspended'] ?>
            </strong>
        </div>

    </section>

    <section class="dev-section">

        <h2>System Management</h2>

        <div class="dev-actions">

            <a
                class="dev-button"
                href="admin.php"
            >
                Manage Accounts
            </a>
            <a class="dev-button" href="developer-instructors.php">Manage Instructor Invitations</a>
            <a class="dev-button" href="developer-location-photos.php">Manage Location Photos</a>

            <a
                class="dev-button"
                href="map.php"
            >
                Campus Map
            </a>

            <a
                class="dev-button"
                href="ai.php"
            >
                AI Assistant
            </a>

            <a
                class="dev-button"
                href="home.php"
            >
                Home
            </a>

            <a
                class="dev-button"
                href="logout.php"
            >
                Log Out
            </a>

        </div>

    </section>

    <section class="dev-section">

        <h2>Recently Registered Accounts</h2>

        <div class="dev-table-wrap">

            <table class="dev-table">

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Registered</th>
                    </tr>
                </thead>

                <tbody>

                    <?php foreach ($recentUsers as $user): ?>

                        <tr>
                            <td>
                                <?= e($user['id']) ?>
                            </td>

                            <td>
                                <?= e($user['full_name']) ?>
                            </td>

                            <td>
                                <?= e($user['email']) ?>
                            </td>

                            <td>
                                <?= e($user['role']) ?>
                            </td>

                            <td>
                                <?= e($user['status']) ?>
                            </td>

                            <td>
                                <?= e($user['created_at']) ?>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                    <?php if (empty($recentUsers)): ?>

                        <tr>
                            <td colspan="6">
                                No accounts found.
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

    <section class="dev-section">

        <h2>Recent System Activity</h2>

        <div class="dev-table-wrap">

            <table class="dev-table">

                <thead>
                    <tr>
                        <th>Action</th>
                        <th>Performed By</th>
                        <th>Target</th>
                        <th>Date</th>
                    </tr>
                </thead>

                <tbody>

                    <?php foreach ($recentLogs as $log): ?>

                        <tr>

                            <td>
                                <?= e($log['action']) ?>
                            </td>

                            <td>
                                <?= e(
                                    $log['actor_name']
                                    ?: 'System'
                                ) ?>
                            </td>

                            <td>
                                <?= e($log['target_type']) ?>
                                #
                                <?= e($log['target_id']) ?>
                            </td>

                            <td>
                                <?= e($log['created_at']) ?>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                    <?php if (empty($recentLogs)): ?>

                        <tr>
                            <td colspan="4">
                                No activity recorded.
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

    <p class="dev-note">
        Developer access is restricted to the configured Developer email.
        Students and instructors use separate login pages. Administrator access is separate and not linked from public sign-in screens.
    </p>

</main>

<?php render_foot('admin'); ?>
