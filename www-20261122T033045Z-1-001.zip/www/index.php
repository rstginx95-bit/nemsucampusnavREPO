<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/auth_page.php';
$u = current_user();
if ($u) {
    redirect(is_staff($u) && ($u['preview'] ?? '') !== 'student' ? 'admin.php' : (($u['mode'] ?? '') === 'blocked' ? 'status.php' : 'home.php'));
}
auth_start('Choose your CampusNav login');
?>
<section class="holo card enter" aria-labelledby="portal-title">
  <h1 id="portal-title">Welcome to NEMSU CampusNav AI</h1>
  <p class="muted">Choose your own sign-in page. Student and instructor accounts use separate login links.</p>
  <div class="portal-choices">
    <a class="btn btn-primary portal-choice" href="<?= e(app_url('student-login.php')) ?>">
      <span class="portal-choice-title">Student Login</span>
      <span class="portal-choice-note">Sign in using your registered email or Student ID</span>
    </a>
    <a class="btn btn-ghost portal-choice" href="<?= e(app_url('instructor-login.php')) ?>">
      <span class="portal-choice-title">Instructor Login</span>
      <span class="portal-choice-note">Sign in using your registered email or Employee ID</span>
    </a>
  </div>
  <p class="foot">New student? <a class="hu" href="<?= e(app_url('register.php')) ?>">Create a student account</a></p>
</section>
<div class="chips enter" aria-hidden="true"><div class="chip"><?= icon('map') ?>Map</div><div class="chip"><?= icon('calendar') ?>Schedule</div><div class="chip"><?= icon('ai') ?>Ask AI</div></div>
<?php auth_end(); ?>
