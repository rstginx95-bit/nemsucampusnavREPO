# NEMSU CampusNav AI — build notes and test report

## Changes in this package
- Preserved the existing visual design, CSS, interactive JavaScript, dashboard pages and campus map implementation.
- Separated public Student and Instructor login pages. `student-login.php` is the named Student entry point; legacy `login.php` remains compatible. `instructor-login.php` is the separate Instructor entry point.
- Removed the Administrator link/choice from public Student and Instructor login pages. Administrator sign-in remains available only at the separate direct URL `admin-login.php`.
- Added a dedicated instructor application URL `instructor-register.php`; it opens the instructor-only registration flow.
- Student and instructor registration accept any valid email provider; no NEMSU email domain restriction is imposed.
- Student sign-in accepts email or Student ID. Instructor sign-in accepts email or Employee ID.
- Instructor applications require email verification and remain pending until administrator review and approval, followed by account activation. Registration never grants instructor privileges.
- Successful instructor sign-ins are audited and notify approved administrators; student sign-ins do not generate these notifications. Delivery depends on real SMTP configuration.
- Retained operational snapshot metrics in the administrator Manage page.
- Kept administrator password and other live credentials out of the distributable archive.

## Static checks performed for this archive
- PHP syntax checks (`php -l`) on all PHP files.
- JavaScript syntax checks (`node --check`) on JavaScript files and service worker where Node is available.
- ZIP integrity check.

## Not verified in this build environment
- Live MySQL queries, migrations, and existing account records.
- Whether the deployed administrator row has email `smquezada@nemsu.edu.ph` and whether its password hash matches the password known to the administrator.
- Real SMTP delivery to the administrator or applicant inboxes.
- Gemini API access, Google Maps API configuration, billing/referrer restrictions, campus path accuracy, and browser/mobile end-to-end behavior.
- Production hosting configuration, HTTPS, file permissions, backups, and access-control behavior under a real database.

This is a source-code package with static validation, not a production certification. Back up the database and preserve the existing `database/app.key` before updating an installation. Do not rerun the installer against a populated database.
