/* NEMSU calendar: month grid + day details */
(function () {
  'use strict';

  var grid = document.getElementById('cal-grid');
  var title = document.getElementById('cal-title');
  var dayTitle = document.getElementById('day-title');
  var dayBody = document.getElementById('day-body');
  var cache = {};
  var view = new Date();
  view.setDate(1);
  var selected = null;       // 'YYYY-MM-DD'
  var todayStr = null;

  var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  var DOW = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  var CAT = { academic: 'Academic', exam: 'Exam', holiday: 'Holiday', event: 'Event' };

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function ymd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function monthKey(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1); }
  function isoDow(d) { return d.getDay() === 0 ? 7 : d.getDay(); }   // 1 = Monday

  function load(key) {
    if (cache[key]) { return Promise.resolve(cache[key]); }
    return CN.api('api/calendar.php?m=' + key).then(function (d) { cache[key] = d; todayStr = d.today; return d; });
  }

  function eventsOn(data, dateStr) {
    return data.events.filter(function (e) { return e.start <= dateStr && e.end >= dateStr; });
  }
  function classesOn(data, d) {
    var dow = isoDow(d);
    return data.classes.filter(function (c) { return c.dow === dow; }).sort(function (a, b) { return a.sort < b.sort ? -1 : 1; });
  }

  function render(data) {
    var y = view.getFullYear(), m = view.getMonth();
    title.textContent = MONTHS[m] + ' ' + y;
    grid.textContent = '';

    DOW.forEach(function (n) { grid.appendChild(CN.el('div', 'cal-dow', n)); });

    var first = new Date(y, m, 1);
    var lead = isoDow(first) - 1;
    var days = new Date(y, m + 1, 0).getDate();
    for (var i = 0; i < lead; i++) { grid.appendChild(CN.el('div', 'cal-cell is-empty')); }

    for (var day = 1; day <= days; day++) {
      var d = new Date(y, m, day);
      var s = ymd(d);
      var evs = eventsOn(data, s);
      var cls = classesOn(data, d);
      var btn = CN.el('button', 'cal-cell');
      btn.type = 'button';
      btn.setAttribute('role', 'gridcell');
      btn.dataset.date = s;
      if (s === todayStr) { btn.classList.add('is-today'); }
      if (s === selected) { btn.classList.add('is-selected'); btn.setAttribute('aria-selected', 'true'); }
      if (isoDow(d) >= 6) { btn.classList.add('is-weekend'); }
      btn.appendChild(CN.el('span', 'cal-num', String(day)));

      var dots = CN.el('span', 'cal-dots');
      var seen = {};
      evs.forEach(function (e) { if (!seen[e.category]) { seen[e.category] = 1; dots.appendChild(CN.el('i', 'cat-' + e.category)); } });
      if (cls.length) { dots.appendChild(CN.el('i', 'cat-class')); }
      btn.appendChild(dots);

      var label = d.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
      if (evs.length) { label += ', ' + evs.map(function (e) { return e.title; }).join(', '); }
      if (cls.length) { label += ', ' + cls.length + ' class' + (cls.length > 1 ? 'es' : ''); }
      btn.setAttribute('aria-label', label);
      grid.appendChild(btn);
    }
  }

  function showDay(data, dateStr) {
    var d = new Date(dateStr + 'T00:00:00');
    dayTitle.textContent = d.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
    dayBody.textContent = '';

    var evs = eventsOn(data, dateStr);
    var cls = classesOn(data, d);

    if (!evs.length && !cls.length) {
      dayBody.appendChild(CN.el('p', 'muted', 'Nothing scheduled.'));
      return;
    }
    if (evs.length) {
      var list = CN.el('ul', 'event-list');
      evs.forEach(function (e) {
        var li = CN.el('li', 'cat-' + e.category);
        li.appendChild(CN.el('strong', '', e.title));
        li.appendChild(CN.el('span', '', CAT[e.category] + (e.start !== e.end ? ', ' + e.start + ' to ' + e.end : '')));
        if (e.desc) { li.appendChild(CN.el('small', '', e.desc)); }
        list.appendChild(li);
      });
      dayBody.appendChild(list);
    }
    if (cls.length) {
      dayBody.appendChild(CN.el('h3', 'day-sub', 'Classes'));
      var cl = CN.el('ul', 'mini-list');
      cls.forEach(function (c) {
        var li = document.createElement('li');
        var row = c.room_id ? CN.el('a', 'cal-class') : CN.el('div', 'cal-class');
        if (c.room_id) { row.href = 'map.php?to=' + c.room_id; }
        row.appendChild(CN.el('time', '', c.start));
        var sp = CN.el('span', '');
        sp.appendChild(CN.el('strong', '', c.code));
        sp.appendChild(document.createTextNode(' ' + c.place));
        row.appendChild(sp);
        if (c.room_id) { row.appendChild(CN.icon('nav')); }
        li.appendChild(row);
        cl.appendChild(li);
      });
      dayBody.appendChild(cl);
    }
  }

  function refresh() {
    load(monthKey(view)).then(function (data) {
      render(data);
      if (!selected) { selected = todayStr && todayStr.slice(0, 7) === monthKey(view) ? todayStr : monthKey(view) + '-01'; }
      if (selected.slice(0, 7) === monthKey(view)) {
        var cell = grid.querySelector('[data-date="' + selected + '"]');
        if (cell) { cell.classList.add('is-selected'); }
        showDay(data, selected);
      }
    }).catch(function (e) {
      grid.textContent = '';
      grid.appendChild(CN.el('p', 'notice notice-error', e.message));
    });
  }

  grid.addEventListener('click', function (ev) {
    var cell = ev.target.closest('.cal-cell[data-date]');
    if (!cell) { return; }
    selected = cell.dataset.date;
    Array.prototype.forEach.call(grid.querySelectorAll('.is-selected'), function (c) { c.classList.remove('is-selected'); c.removeAttribute('aria-selected'); });
    cell.classList.add('is-selected');
    cell.setAttribute('aria-selected', 'true');
    showDay(cache[monthKey(view)], selected);
    if (window.matchMedia('(max-width: 899px)').matches) {
      document.querySelector('.cal-day').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  });

  document.getElementById('cal-prev').addEventListener('click', function () { view.setMonth(view.getMonth() - 1); refresh(); });
  document.getElementById('cal-next').addEventListener('click', function () { view.setMonth(view.getMonth() + 1); refresh(); });
  document.getElementById('cal-today').addEventListener('click', function () {
    view = new Date(); view.setDate(1); selected = null; refresh();
  });
  document.addEventListener('keydown', function (ev) {
    if (ev.target.closest && ev.target.closest('input, textarea')) { return; }
    if (ev.key === 'ArrowLeft' && ev.altKey) { view.setMonth(view.getMonth() - 1); refresh(); }
    if (ev.key === 'ArrowRight' && ev.altKey) { view.setMonth(view.getMonth() + 1); refresh(); }
  });

  refresh();
})();
