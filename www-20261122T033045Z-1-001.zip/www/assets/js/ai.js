/* NEMSU CampusNav - chat assistant */
(function () {
  'use strict';

  var boot = window.CN_AI || {};
  var log = document.getElementById('chat-log');
  var form = document.getElementById('chat-form');
  var input = document.getElementById('chat-input');
  var chipsBox = document.getElementById('chat-chips');
  var busy = false;

  function scrollDown() { log.scrollTop = log.scrollHeight; }

  function bubble(who, text) {
    var row = CN.el('div', 'msg msg-' + who);
    row.appendChild(CN.el('div', 'bubble', text));
    log.appendChild(row);
    scrollDown();
    return row;
  }

  function renderActions(row, actions) {
    if (!actions || !actions.length) { return; }
    var box = CN.el('div', 'msg-actions');
    actions.forEach(function (a) {
      var link = CN.el('a', 'btn btn-sign btn-small');
      if (a.type === 'navigate') {
        link.href = 'map.php?to=' + encodeURIComponent(a.location_id);
        link.appendChild(CN.icon('nav'));
      } else {
        link.href = a.href;
      }
      link.appendChild(document.createTextNode(' ' + a.label));
      box.appendChild(link);
    });
    row.appendChild(box);
    scrollDown();
  }

  function renderChips(chips) {
    chipsBox.textContent = '';
    (chips || []).forEach(function (c) {
      var b = CN.el('button', 'chip', c);
      b.type = 'button';
      b.addEventListener('click', function () { send(c); });
      chipsBox.appendChild(b);
    });
  }

  function typing() {
    var row = CN.el('div', 'msg msg-ai msg-typing');
    var b = CN.el('div', 'bubble');
    b.setAttribute('aria-label', 'Assistant is typing');
    for (var i = 0; i < 3; i++) { b.appendChild(CN.el('i')); }
    row.appendChild(b);
    log.appendChild(row);
    scrollDown();
    return row;
  }

  function send(text) {
    text = (text || '').trim();
    if (!text || busy) { return; }
    busy = true;
    input.value = '';
    bubble('user', text);
    chipsBox.textContent = '';
    var t = typing();

    CN.quietPosition().then(function (pos) {
      var body = { message: text };
      if (pos) { body.lat = pos.lat; body.lng = pos.lng; }
      return CN.api('api/ai.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
    }).then(function (res) {
      t.remove();
      var row = bubble('ai', res.reply);
      renderActions(row, res.actions);
      renderChips(res.chips);
    }).catch(function (e) {
      t.remove();
      bubble('ai', e.message);
    }).then(function () {
      busy = false;
      input.focus({ preventScroll: true });
    });
  }

  form.addEventListener('submit', function (ev) { ev.preventDefault(); send(input.value); });
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-ask]');
    if (b) { send(b.getAttribute('data-ask')); }
  });

  /* ---- start: previous messages, then a greeting ---- */
  CN.api('api/ai.php').then(function (d) {
    var hist = d.history.slice(-10);
    hist.forEach(function (m) { bubble(m.sender === 'user' ? 'user' : 'ai', m.body); });
    if (!hist.length) {
      bubble('ai', 'Hi ' + (boot.first || 'there') + '! Ask me about your schedule or where something is on campus.');
    }
    renderChips(d.chips);
    if (boot.q) { send(boot.q); }
  }).catch(function () {
    bubble('ai', 'I could not load your chat. Reload the page to try again.');
  });
})();
