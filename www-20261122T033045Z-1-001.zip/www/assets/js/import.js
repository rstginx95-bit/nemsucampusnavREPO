/* Drag-and-drop import with column matching, live preview and a final confirmation */
(function () {
  'use strict';
  var cfg = window.CN_IMPORT || {};
  var drop = document.getElementById('drop'), file = document.getElementById('file');
  var err = document.getElementById('imp-error'), step2 = document.getElementById('imp-step2');
  var grid = document.getElementById('map-grid'), table = document.getElementById('imp-table');
  var counts = document.getElementById('imp-counts'), go = document.getElementById('imp-go');
  var state = { token: null, header: [], fields: {}, mapping: {} }, timer = null;

  function showError(m) { err.textContent = m; err.hidden = !m; }
  function post(data) {
    var fd = new FormData();
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    fd.append('target', cfg.target);
    return CN.api('import.php?target=' + cfg.target, { method: 'POST', body: fd });
  }

  function upload(f) {
    showError('');
    if (!f) { return; }
    if (!/\.(xlsx|docx|csv)$/i.test(f.name)) { showError('Use an Excel (.xlsx), Word (.docx) or CSV file.'); return; }
    if (f.size > 5 * 1024 * 1024) { showError('That file is larger than 5 MB.'); return; }
    drop.classList.add('is-busy');
    post({ action: 'parse', file: f }).then(function (r) {
      state.token = r.token; state.header = r.header; state.fields = r.fields; state.mapping = r.mapping;
      document.getElementById('imp-file').textContent = r.file;
      buildMapping(); drop.hidden = true; step2.hidden = false; preview();
    }).catch(function (e) { showError(e.message); }).then(function () { drop.classList.remove('is-busy'); });
  }

  function buildMapping() {
    grid.textContent = '';
    Object.keys(state.fields).forEach(function (field) {
      var lab = CN.el('label', 'field'); lab.appendChild(document.createTextNode(state.fields[field]));
      var sel = document.createElement('select'); sel.dataset.field = field;
      var none = document.createElement('option'); none.value = ''; none.textContent = 'Not in my file'; sel.appendChild(none);
      state.header.forEach(function (h, i) { var o = document.createElement('option'); o.value = String(i); o.textContent = h || ('Column ' + (i + 1)); sel.appendChild(o); });
      if (state.mapping[field] !== undefined) { sel.value = String(state.mapping[field]); }
      sel.addEventListener('change', function () { if (sel.value === '') { delete state.mapping[field]; } else { state.mapping[field] = parseInt(sel.value, 10); } schedule(); });
      lab.appendChild(sel); grid.appendChild(lab);
    });
  }

  function schedule() { clearTimeout(timer); timer = setTimeout(preview, 250); }
  function opts(action) {
    var b = document.getElementById('imp-block');
    return { action: action, token: state.token, mapping: JSON.stringify(state.mapping), block: b ? b.value : '', mode: document.getElementById('imp-mode').value };
  }

  function preview() {
    post(opts('preview')).then(function (r) {
      var c = r.counts;
      counts.textContent = '';
      [['ok', c.ok + ' new', 'pill-live'], ['exists', c.exists + ' already exist', ''], ['duplicate', c.duplicate + ' repeated', 'pill-warn'], ['invalid', c.invalid + ' need fixing', 'pill-bad']].forEach(function (x) {
        counts.appendChild(CN.el('span', 'pill ' + x[2], x[1]));
      });
      table.textContent = '';
      var head = document.createElement('thead'), hr = document.createElement('tr');
      ['Line', 'Status', 'Details'].forEach(function (t) { hr.appendChild(CN.el('th', '', t)); });
      Object.keys(state.fields).forEach(function (f) { if (state.mapping[f] !== undefined) { hr.appendChild(CN.el('th', '', state.fields[f])); } });
      head.appendChild(hr); table.appendChild(head);
      var body = document.createElement('tbody');
      r.rows.forEach(function (row) {
        var tr = document.createElement('tr'); tr.className = 'row-' + row.status;
        tr.appendChild(CN.el('td', '', String(row.line)));
        tr.appendChild(CN.el('td', '', { ok: 'New', exists: 'Exists', duplicate: 'Repeated', invalid: 'Fix' }[row.status]));
        tr.appendChild(CN.el('td', '', row.msg));
        Object.keys(state.fields).forEach(function (f) {
          if (state.mapping[f] === undefined) { return; }
          var v = row[f] !== undefined ? row[f] : ''; if (f === 'block') { v = row.section_id ? '✓' : ''; }
          tr.appendChild(CN.el('td', '', String(v)));
        });
        body.appendChild(tr);
      });
      table.appendChild(body);
      var n = c.ok + (document.getElementById('imp-mode').value === 'update' ? c.exists : 0);
      go.textContent = 'Import ' + n + (cfg.target === 'roster' ? ' staff' : ' students'); go.disabled = n === 0;
      if (r.total > r.rows.length) { counts.appendChild(CN.el('span', 'muted', ' Showing the first ' + r.rows.length + ' rows.')); }
    }).catch(function (e) { showError(e.message); });
  }

  go.addEventListener('click', function () {
    go.disabled = true; showError('');
    post(opts('commit')).then(function (r) {
      step2.hidden = true;
      var d = document.getElementById('imp-done');
      d.textContent = 'Done. ' + r.added + ' added, ' + r.updated + ' updated, ' + r.skipped + ' skipped.'; d.hidden = false;
    }).catch(function (e) { showError(e.message); go.disabled = false; });
  });
  ['imp-mode', 'imp-block'].forEach(function (id) { var el = document.getElementById(id); if (el) { el.addEventListener('change', schedule); } });
  document.getElementById('imp-cancel').addEventListener('click', function () { step2.hidden = true; drop.hidden = false; file.value = ''; });

  drop.addEventListener('click', function () { file.click(); });
  drop.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); file.click(); } });
  file.addEventListener('change', function () { upload(file.files[0]); });
  ['dragenter', 'dragover'].forEach(function (t) { drop.addEventListener(t, function (e) { e.preventDefault(); drop.classList.add('is-over'); }); });
  ['dragleave', 'drop'].forEach(function (t) { drop.addEventListener(t, function (e) { e.preventDefault(); drop.classList.remove('is-over'); }); });
  drop.addEventListener('drop', function (e) { upload(e.dataTransfer.files[0]); });
})();
