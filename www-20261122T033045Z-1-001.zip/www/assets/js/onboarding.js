/* Step-by-step profile wizard */
(function () {
  'use strict';
  var wizard = document.getElementById('wizard');
  if (!wizard) { return; }

  var form = document.getElementById('wizard-form');
  var steps = Array.prototype.slice.call(form.querySelectorAll('.step'));
  var back = document.getElementById('btn-back');
  var next = document.getElementById('btn-next');
  var bar = document.getElementById('progress-bar');
  var count = document.getElementById('step-count');
  var errBox = document.getElementById('step-error');
  var current = 0;

  /* Birthday -> age */
  var bd = document.getElementById('birthday');
  var age = document.getElementById('age');
  function showAge() {
    if (!bd.value) { age.value = ''; return; }
    var b = new Date(bd.value + 'T00:00:00'), n = new Date();
    var a = n.getFullYear() - b.getFullYear();
    var m = n.getMonth() - b.getMonth();
    if (m < 0 || (m === 0 && n.getDate() < b.getDate())) { a--; }
    age.value = a >= 0 && a < 120 ? a + ' years old' : '';
  }
  bd.addEventListener('input', showAge);
  showAge();

  function show(i, dir) {
    current = i;
    steps.forEach(function (s, idx) {
      var on = idx === i;
      s.hidden = !on;
      s.classList.remove('from-left', 'from-right');
      if (on && dir) { s.classList.add(dir > 0 ? 'from-right' : 'from-left'); }
    });
    var total = steps.length;
    bar.style.width = ((i + 1) / total * 100) + '%';
    count.textContent = 'Step ' + (i + 1) + ' of ' + total;
    back.style.visibility = i === 0 ? 'hidden' : 'visible';
    next.textContent = i === total - 1 ? 'Finish' : 'Next';
    errBox.hidden = true;
    var first = steps[i].querySelector('input:not([readonly]), textarea');
    if (first && dir) { first.focus({ preventScroll: true }); }
  }

  function validStep(i) {
    var fields = steps[i].querySelectorAll('input, textarea');
    for (var k = 0; k < fields.length; k++) {
      var f = fields[k];
      if (f.readOnly) { continue; }
      if (f.name === 'full_name' && f.value.trim().indexOf(' ') === -1) {
        return { el: f, msg: 'Enter your first name and last name.' };
      }
      if (f.name === 'student_type') {
        if (!steps[i].querySelector('input[name=student_type]:checked')) { return { el: f, msg: 'Choose one option.' }; }
        continue;
      }
      if (!f.checkValidity()) {
        return { el: f, msg: f.validationMessage || 'Check this field.' };
      }
    }
    return null;
  }

  next.addEventListener('click', function () {
    var bad = validStep(current);
    if (bad) {
      errBox.textContent = bad.msg;
      errBox.hidden = false;
      bad.el.focus();
      return;
    }
    if (current === steps.length - 1) {
      next.disabled = true;
      next.textContent = 'Saving...';
      form.submit();
    } else {
      show(current + 1, 1);
    }
  });
  back.addEventListener('click', function () { if (current > 0) { show(current - 1, -1); } });
  form.addEventListener('keydown', function (ev) {
    if (ev.key === 'Enter' && ev.target.tagName !== 'TEXTAREA') { ev.preventDefault(); next.click(); }
  });

  // After a server error, start on the first step again so nothing is hidden from the person.
  show(0, 0);
})();
