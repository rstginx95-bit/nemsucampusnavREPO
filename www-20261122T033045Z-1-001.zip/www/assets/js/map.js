
/* NEMSU CampusNav - Live GPS Navigation */
(function () {
  'use strict';

  var boot = window.CN_MAP || {};
  var $ = function (s) { return document.querySelector(s); };
  var panel = $('#panel');
  var input = $('#q');
  var resultsBox = $('#results');
  var routeBox = $('#route');
  var isMobile = function () {
    return window.matchMedia('(max-width: 899px)').matches;
  };

  var provider = boot.provider === 'google' ? 'google' : 'osm';
  var engine = null;
  var pendingRoute = null;
  var markersData = [];
  var activeDest = null;
  var searchTimer = null;
  var watchId = null;
  var userPos = null;
  var lastAccuracy = null;
  var lastRoutePosition = null;
  var lastRouteTime = 0;
  var routeRequest = 0;
  var routeBusy = false;
  var followUser = false;
  var destinationCoords = null;
  var arrived = false;

  function distanceMeters(a, b) {
    var rad = Math.PI / 180;
    var dLat = (b.lat - a.lat) * rad;
    var dLng = (b.lng - a.lng) * rad;

    var h =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(a.lat * rad) *
      Math.cos(b.lat * rad) *
      Math.sin(dLng / 2) ** 2;

    return 12742000 * Math.asin(Math.min(1, Math.sqrt(h)));
  }

  var navStatus = document.createElement('p');
  navStatus.id = 'live-nav-status';
  navStatus.className = 'muted route-note';
  navStatus.setAttribute('role', 'status');

  var routeSteps = $('#route-steps');
  if (routeSteps) {
    routeSteps.parentNode.insertBefore(navStatus, routeSteps);
  }

  function navigationStatus(message) {
    navStatus.textContent = message;
  }

  function arrivalCheck(pos) {
    if (
      !destinationCoords ||
      !activeDest ||
      !pos ||
      lastAccuracy > 35
    ) {
      return false;
    }

    var remaining = distanceMeters(pos, destinationCoords);

    if (remaining <= 15) {
      if (!arrived) {
        arrived = true;
        CN.toast('You have arrived at your destination!');
      }

      navigationStatus('You have arrived at your destination.');
      return true;
    }

    arrived = false;

    navigationStatus(
      'Live navigation • Approximately ' +
      Math.round(remaining) +
      ' m straight-line distance remaining' +
      (
        lastAccuracy > 20
          ? ' • GPS accuracy ±' + Math.round(lastAccuracy) + ' m'
          : ''
      )
    );

    return false;
  }

  /* ============================================================
     GOOGLE MAPS ENGINE
     ============================================================ */

  function GoogleEngine() {
    var center = {
      lat: boot.campus.lat,
      lng: boot.campus.lng
    };

    var map = new google.maps.Map($('#map'), {
      center: center,
      zoom: 18,
      mapTypeControl: true,
      streetViewControl: true,
      fullscreenControl: false,
      zoomControl: !isMobile(),
      gestureHandling: 'greedy',
      clickableIcons: false
    });

    var routeLines = [];
    var destMarker = null;
    var userDot = null;
    var userRing = null;

    function pin(fill, stroke, scale) {
      return {
        path: 'M12 2C7.6 2 4 5.5 4 9.8 4 15.6 12 22 12 22s8-6.4 8-12.2C20 5.5 16.4 2 12 2z',
        fillColor: fill,
        fillOpacity: 1,
        strokeColor: stroke,
        strokeWeight: 2,
        scale: scale,
        anchor: new google.maps.Point(12, 22)
      };
    }

    return {
      addMarker: function (l, onClick) {
        var m = new google.maps.Marker({
          position: {
            lat: l.lat,
            lng: l.lng
          },
          map: map,
          title: l.name,
          icon: pin('#0f3d2e', '#ffffff', 1.5)
        });

        m.addListener('click', onClick);
      },

      drawRoute: function (coords, dest, straight, fit) {
        routeLines.forEach(function (p) {
          p.setMap(null);
        });

        routeLines = [];

        if (destMarker) {
          destMarker.setMap(null);
        }

        var path = coords.map(function (c) {
          return {
            lat: c[0],
            lng: c[1]
          };
        });

        routeLines.push(new google.maps.Polyline({
          path: path,
          map: map,
          strokeColor: '#0f3d2e',
          strokeWeight: 10,
          strokeOpacity: 0.9
        }));

        routeLines.push(new google.maps.Polyline({
          path: path,
          map: map,
          strokeColor: '#f5b800',
          strokeWeight: 6,
          strokeOpacity: straight ? 0 : 1,
          icons: straight
            ? [{
                icon: {
                  path: 'M 0,-1 0,1',
                  strokeOpacity: 1,
                  scale: 3
                },
                offset: '0',
                repeat: '14px'
              }]
            : null
        }));

        var end = path[path.length - 1];

        destMarker = new google.maps.Marker({
          position: end,
          map: map,
          title: dest.name,
          icon: pin('#f5b800', '#1a1400', 2),
          zIndex: 10
        });

        var bounds = new google.maps.LatLngBounds();

        path.forEach(function (p) {
          bounds.extend(p);
        });

        if (fit !== false) {
          map.fitBounds(
            bounds,
            isMobile()
              ? {
                  top: 90,
                  left: 28,
                  right: 28,
                  bottom: Math.round(window.innerHeight * 0.5)
                }
              : 60
          );

          google.maps.event.addListenerOnce(
            map,
            'idle',
            function () {
              if (map.getZoom() > 19) {
                map.setZoom(19);
              }
            }
          );
        }
      },

      clearRoute: function () {
        routeLines.forEach(function (p) {
          p.setMap(null);
        });

        routeLines = [];

        if (destMarker) {
          destMarker.setMap(null);
          destMarker = null;
        }
      },

      showUser: function (pos, acc) {
        var ll = {
          lat: pos.lat,
          lng: pos.lng
        };

        if (!userDot) {
          userRing = new google.maps.Circle({
            map: map,
            center: ll,
            radius: acc || 20,
            strokeColor: '#1a73e8',
            strokeWeight: 1,
            fillColor: '#1a73e8',
            fillOpacity: 0.12
          });

          userDot = new google.maps.Marker({
            position: ll,
            map: map,
            title: 'You are here',
            zIndex: 20,
            icon: {
              path: google.maps.SymbolPath.CIRCLE,
              scale: 8,
              fillColor: '#1a73e8',
              fillOpacity: 1,
              strokeColor: '#ffffff',
              strokeWeight: 3
            }
          });
        } else {
          userDot.setPosition(ll);
          userRing.setCenter(ll);
          userRing.setRadius(acc || 20);
        }
      },

      centerOn: function (pos) {
        map.panTo({
          lat: pos.lat,
          lng: pos.lng
        });

        map.setZoom(Math.max(map.getZoom(), 18));
      }
    };
  }

  /* ============================================================
     OPENSTREETMAP / LEAFLET ENGINE
     ============================================================ */

  function LeafletEngine() {
    var map = L.map('map', {
      zoomControl: false
    }).setView([
      boot.campus.lat,
      boot.campus.lng
    ], 18);

    L.control.zoom({
      position: 'topright'
    }).addTo(map);

    var tiles = L.tileLayer(
      'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors'
      }
    ).addTo(map);

    var failed = 0;

    tiles.on('tileerror', function () {
      failed++;

      if (failed === 6) {
        $('#map-fallback').hidden = false;
      }
    });

    tiles.on('tileload', function () {
      $('#map-fallback').hidden = true;
    });

    var layer = L.layerGroup().addTo(map);
    var userDot = null;
    var userRing = null;

    return {
      addMarker: function (l, onClick) {
        var icon = L.divIcon({
          className: 'cn-pin',
          html: '<span></span>',
          iconSize: [30, 36],
          iconAnchor: [15, 34]
        });

        var marker = L.marker(
          [l.lat, l.lng],
          {
            icon: icon,
            title: l.name
          }
        ).addTo(map);

        marker.bindTooltip(l.name, {
          direction: 'top',
          offset: [0, -30]
        });

        marker.on('click', onClick);
      },

      drawRoute: function (coords, dest, straight, fit) {
        layer.clearLayers();

        L.polyline(coords, {
          color: '#0f3d2e',
          weight: 10,
          opacity: 0.9,
          lineCap: 'round',
          lineJoin: 'round'
        }).addTo(layer);

        L.polyline(coords, {
          color: '#f5b800',
          weight: 6,
          lineCap: 'round',
          lineJoin: 'round',
          dashArray: straight ? '2 10' : null
        }).addTo(layer);

        var icon = L.divIcon({
          className: 'cn-pin is-dest',
          html: '<span></span>',
          iconSize: [36, 44],
          iconAnchor: [18, 42]
        });

        L.marker(
          coords[coords.length - 1],
          {
            icon: icon,
            title: dest.name
          }
        ).addTo(layer);

        var padding = isMobile()
          ? {
              paddingTopLeft: [28, 90],
              paddingBottomRight: [
                28,
                Math.round(window.innerHeight * 0.5)
              ]
            }
          : {
              paddingTopLeft: [40, 40],
              paddingBottomRight: [40, 40]
            };

        if (fit !== false) {
          map.fitBounds(
            L.latLngBounds(coords),
            Object.assign({
              maxZoom: 19
            }, padding)
          );
        }
      },

      clearRoute: function () {
        layer.clearLayers();
      },

      showUser: function (pos, acc) {
        var ll = [pos.lat, pos.lng];

        if (!userDot) {
          userRing = L.circle(ll, {
            radius: acc || 20,
            color: '#1a73e8',
            weight: 1,
            fillOpacity: 0.12
          }).addTo(map);

          userDot = L.circleMarker(ll, {
            radius: 8,
            color: '#ffffff',
            weight: 3,
            fillColor: '#1a73e8',
            fillOpacity: 1
          }).addTo(map);
        } else {
          userDot.setLatLng(ll);
          userRing.setLatLng(ll).setRadius(acc || 20);
        }
      },

      centerOn: function (pos) {
        map.setView(
          [pos.lat, pos.lng],
          Math.max(map.getZoom(), 18)
        );
      }
    };
  }

  /* ============================================================
     INITIALIZE MAP
     ============================================================ */

  function startEngine() {
    try {
      engine = provider === 'google'
        ? GoogleEngine()
        : LeafletEngine();
    } catch (err) {
      $('#map-fallback').hidden = false;
      return;
    }

    markersData.forEach(function (location) {
      engine.addMarker(location, function () {
        goTo(location.id);
      });
    });

    if (pendingRoute) {
      engine.drawRoute(
        pendingRoute.coords,
        pendingRoute.dest,
        pendingRoute.straight
      );
    }

    if (userPos) {
      engine.showUser(userPos, 20);
    }
  }

  window.cnGoogleReady = function () {
    startEngine();
  };

  if (provider === 'osm') {
    if (typeof L !== 'undefined') {
      startEngine();
    } else {
      $('#map-fallback').hidden = false;
    }
  } else {
    window.gm_authFailure = function () {
      $('#map-fallback').hidden = false;
      $('#map-fallback').textContent =
        'Google Maps could not load. Check the API key, billing, and Maps JavaScript API settings.';
    };
  }

  CN.api('api/locations.php?all=1')
    .then(function (data) {
      markersData = data.items.filter(function (location) {
        return location.lat !== null;
      });

      if (engine) {
        markersData.forEach(function (location) {
          engine.addMarker(location, function () {
            goTo(location.id);
          });
        });
      }
    })
    .catch(function () {});

  /* ============================================================
     SEARCH PANEL
     ============================================================ */

  function setSheet(open) {
    panel.classList.toggle('sheet-open', open);
    panel.classList.toggle('sheet-peek', !open);
  }

  $('#sheet-handle').addEventListener('click', function () {
    setSheet(!panel.classList.contains('sheet-open'));
  });

  input.addEventListener('focus', function () {
    setSheet(true);
  });

  function renderResults(items) {
    resultsBox.textContent = '';

    if (!items.length) {
      resultsBox.appendChild(
        CN.el(
          'p',
          'muted empty-line',
          'No place matches that. Try a building name, room number, or office.'
        )
      );
      return;
    }

    var list = CN.el('ul', 'result-list');

    items.forEach(function (location) {
      var li = document.createElement('li');
      var btn = CN.el('button', 'result');

      btn.type = 'button';

      btn.appendChild(
        CN.icon(
          location.type === 'room' ||
          location.type === 'lab' ||
          location.type === 'office'
            ? 'pin'
            : 'map'
        )
      );

      if (location.image) {
        var photo = document.createElement('img');
        photo.className = 'result-photo';
        photo.src = location.image;
        photo.alt = '';
        photo.loading = 'lazy';
        btn.appendChild(photo);
      }

      var text = CN.el('span', 'result-text');

      text.appendChild(
        CN.el('strong', '', location.name)
      );

      var sub =
        location.type === 'building' ||
        location.type === 'facility'
          ? (location.desc || 'Campus location')
          : location.label.replace(location.name + ', ', '');

      text.appendChild(
        CN.el('small', '', sub)
      );

      btn.appendChild(text);
      btn.appendChild(CN.icon('chevron'));

      btn.addEventListener('click', function () {
        goTo(location.id);
      });

      li.appendChild(btn);
      list.appendChild(li);
    });

    resultsBox.appendChild(list);
  }

  function search(query) {
    CN.api(
      'api/locations.php?q=' + encodeURIComponent(query)
    )
      .then(function (data) {
        renderResults(data.items);
      })
      .catch(function (error) {
        resultsBox.textContent = '';

        resultsBox.appendChild(
          CN.el(
            'p',
            'notice notice-error',
            error.message
          )
        );
      });
  }

  input.addEventListener('input', function () {
    clearTimeout(searchTimer);

    var query = input.value.trim();

    if (query === '') {
      search('');
      return;
    }

    setSheet(true);
    routeBox.hidden = true;

    searchTimer = setTimeout(function () {
      search(query);
    }, 180);
  });

  $('#search-form').addEventListener('submit', function (event) {
    event.preventDefault();

    var query = input.value.trim();

    if (query) {
      search(query);
    }
  });

  document.addEventListener('click', function (event) {
    var button = event.target.closest('[data-nav-to]');

    if (button) {
      goTo(
        parseInt(
          button.getAttribute('data-nav-to'),
          10
        )
      );
    }
  });

  /* ============================================================
     ROUTE GENERATION
     ============================================================ */

  function goTo(id) {
    if (!id) {
      return;
    }

    activeDest = id;
    destinationCoords = null;
    lastRoutePosition = null;
    lastRouteTime = 0;
    arrived = false;
    routeRequest++;

    navigationStatus('Preparing walking directions…');

    resultsBox.textContent = '';
    routeBox.hidden = false;

    $('#route-title').textContent = 'Finding the way...';
    $('#route-meta').textContent = '';
    $('#route-crumbs').textContent = '';
    $('#route-steps').textContent = '';
    $('#route-note').hidden = true;
    $('#gmaps-link').hidden = true;

    setSheet(true);

    CN.getPosition(6000)
      .then(function (pos) {
        if (pos) {
          userPos = pos;

          if (engine) {
            engine.showUser(pos, lastAccuracy || 20);
          }

          startWatching();
        }

        var url =
          'api/route.php?to=' + id +
          (
            pos
              ? '&lat=' + pos.lat + '&lng=' + pos.lng
              : ''
          );

        return CN.api(url).then(function (route) {
          return {
            r: route,
            pos: pos
          };
        });
      })
      .then(function (result) {
        if (activeDest !== id) {
          return;
        }

        showRoute(result.r, result.pos, true);

        if (result.pos) {
          lastRoutePosition = result.pos;
          lastRouteTime = Date.now();
        }
      })
      .catch(function (error) {
        $('#route-title').textContent =
          'Could not find a route';

        $('#route-meta').textContent = error.message;
      });
  }

  function showRoute(route, pos, fit) {
    var destination = route.destination;

    destinationCoords =
      Number.isFinite(Number(destination.lat)) &&
      Number.isFinite(Number(destination.lng))
        ? {
            lat: Number(destination.lat),
            lng: Number(destination.lng)
          }
        : null;

    $('#route-title').textContent = destination.name;

    var routePhoto = $('#route-photo');
    if (routePhoto) {
      if (destination.image) {
        routePhoto.src = destination.image;
        routePhoto.alt = 'Photo of ' + destination.name;
        routePhoto.hidden = false;
      } else {
        routePhoto.removeAttribute('src');
        routePhoto.alt = '';
        routePhoto.hidden = true;
      }
    }

    $('#route-meta').textContent =
      route.minutes +
      ' min walk, about ' +
      route.distance_m +
      ' m';

    var crumbs = $('#route-crumbs');
    crumbs.textContent = '';

    route.breadcrumb.forEach(function (crumb) {
      crumbs.appendChild(
        CN.el('li', '', crumb)
      );
    });

    var steps = $('#route-steps');
    steps.textContent = '';

    route.steps.forEach(function (step) {
      steps.appendChild(
        CN.el('li', '', step)
      );
    });

    var googleLink = $('#gmaps-link');

    googleLink.href =
      'https://www.google.com/maps/dir/?api=1&destination=' +
      destination.lat +
      ',' +
      destination.lng +
      '&travelmode=walking';

    googleLink.hidden = false;

    var messages = [];

    if (!pos) {
      messages.push(
        'Location is off, so directions start at the campus entrance. Tap the target button to use your current location.'
      );
    } else if (!route.from_gps) {
      messages.push(
        'You seem to be away from campus, so directions start at the entrance.'
      );
    }

    if (route.straight) {
      messages.push(
        'No walkway connects these points yet, so the line on the map is a straight line.'
      );
    }

    var note = $('#route-note');
    note.textContent = messages.join(' ');
    note.hidden = messages.length === 0;

    pendingRoute = {
      coords: route.coords,
      dest: destination,
      straight: route.straight
    };

    if (engine) {
      engine.drawRoute(
        route.coords,
        destination,
        route.straight,
        fit
      );
    }

    if (userPos) {
      arrivalCheck(userPos);
    } else {
      navigationStatus(
        'Enable your location for live walking navigation.'
      );
    }
  }

  $('#route-clear').addEventListener('click', function () {
    activeDest = null;
    pendingRoute = null;
    destinationCoords = null;
    routeRequest++;
    routeBusy = false;
    followUser = false;

    navigationStatus('');
    routeBox.hidden = true;

    if (engine) {
      engine.clearRoute();
    }

    if (history.replaceState) {
      history.replaceState(null, '', 'map.php');
    }
  });

  /* ============================================================
     LIVE GPS ROUTE REFRESH
     ============================================================ */

  function refreshLiveRoute(pos) {
    if (
      !activeDest ||
      !destinationCoords ||
      routeBusy ||
      arrived
    ) {
      return;
    }

    if (
      lastAccuracy !== null &&
      lastAccuracy > 60
    ) {
      navigationStatus(
        'Waiting for a more accurate GPS fix (±' +
        Math.round(lastAccuracy) +
        ' m).'
      );

      return;
    }

    if (arrivalCheck(pos)) {
      return;
    }

    var now = Date.now();

    if (now - lastRouteTime < 8000) {
      return;
    }

    if (
      lastRoutePosition &&
      distanceMeters(lastRoutePosition, pos) < 12
    ) {
      return;
    }

    var id = activeDest;
    var request = ++routeRequest;

    routeBusy = true;
    lastRouteTime = now;

    CN.api(
      'api/route.php?to=' +
      encodeURIComponent(id) +
      '&lat=' +
      encodeURIComponent(pos.lat) +
      '&lng=' +
      encodeURIComponent(pos.lng)
    )
      .then(function (route) {
        if (
          id !== activeDest ||
          request !== routeRequest
        ) {
          return;
        }

        lastRoutePosition = pos;

        showRoute(route, pos, false);
      })
      .catch(function () {
        if (id === activeDest) {
          navigationStatus(
            'Could not refresh route. Showing the last available directions.'
          );
        }
      })
      .then(function () {
        routeBusy = false;
      });
  }

  /* ============================================================
     GPS LOCATION TRACKING
     ============================================================ */

  function startWatching() {
    if (watchId !== null) {
      return;
    }

    watchId = CN.watchPosition(function (pos, accuracy) {
      if (!pos) {
        return;
      }

      var first = !userPos;

      userPos = pos;

      lastAccuracy = Number.isFinite(Number(accuracy))
        ? Number(accuracy)
        : 100;

      if (engine) {
        engine.showUser(pos, accuracy);

        if (
          (first && !activeDest) ||
          followUser
        ) {
          engine.centerOn(pos);
        }
      }

      if (activeDest) {
        refreshLiveRoute(pos);
      }
    });
  }

  var prompt = $('#loc-prompt');

  function askForLocation() {
    CN.getPosition(10000).then(function (pos) {
      prompt.hidden = true;

      if (pos) {
        userPos = pos;
        startWatching();

        if (engine) {
          engine.showUser(pos, 20);
          engine.centerOn(pos);
        }
      } else {
        CN.toast(
          'Location is blocked. Allow location access in your browser settings.'
        );
      }
    });
  }

  $('#loc-allow').addEventListener('click', askForLocation);

  $('#loc-dismiss').addEventListener('click', function () {
    prompt.hidden = true;

    try {
      sessionStorage.setItem(
        'cnLocDismissed',
        '1'
      );
    } catch (error) {}
  });

  $('#locate-btn').addEventListener('click', function () {
    followUser = true;

    if (userPos && engine) {
      engine.centerOn(userPos);
      CN.toast('Following your location');
    } else {
      askForLocation();
    }
  });

  var dismissed = false;

  try {
    dismissed =
      sessionStorage.getItem('cnLocDismissed') === '1';
  } catch (error) {}

  if (
    navigator.permissions &&
    navigator.permissions.query
  ) {
    navigator.permissions
      .query({
        name: 'geolocation'
      })
      .then(function (status) {
        if (status.state === 'granted') {
          startWatching();
        } else if (
          status.state === 'prompt' &&
          !dismissed
        ) {
          prompt.hidden = false;
        }
      })
      .catch(function () {
        if (!dismissed) {
          prompt.hidden = false;
        }
      });
  } else if (!dismissed) {
    prompt.hidden = false;
  }

  /* ============================================================
     START APPLICATION
     ============================================================ */

  if (boot.to) {
    goTo(boot.to);
  } else {
    search('');
  }
})();
