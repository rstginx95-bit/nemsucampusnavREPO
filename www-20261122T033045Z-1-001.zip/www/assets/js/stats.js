/* Statistics charts. Reads real data from #stats-data (written by includes/stats.php). Nothing is hardcoded. */
(function () {
  var el = document.getElementById('stats-data');
  if (!el) return;
  var D; try { D = JSON.parse(el.textContent); } catch (e) { return; }
  var css = getComputedStyle(document.documentElement);
  function v(n, d) { return (css.getPropertyValue(n) || '').trim() || d; }
  var C = { green: v('--green-600', '#1c7a58'), dark: v('--green-800', '#0f3d2e'), sign: v('--sign', '#f5b800'), red: v('--danger', '#b3261e'), grey: '#8a9a90', blue: '#2f6fb3' };
  var ink = v('--ink', '#14201a'), line = v('--line', '#d9e0d6');
  var has = typeof window.Chart === 'function';
  function sum(a) { return (a || []).reduce(function (x, y) { return x + y; }, 0); }
  function show(id, ok) {
    var cv = document.getElementById('ch-' + id); if (!cv) return null;
    var fig = cv.closest('figure');
    fig.querySelector('.chart-box').hidden = !ok;
    fig.querySelector('.chart-empty').hidden = ok;
    return ok ? cv : null;
  }
  function table(cv, labels, sets) {              // fallback when Chart.js could not be loaded (offline)
    var t = document.createElement('table'); t.className = 'table';
    t.innerHTML = '<thead><tr><th>Period</th>' + sets.map(function (s) { return '<th>' + s.label + '</th>'; }).join('') + '</tr></thead>';
    var b = document.createElement('tbody');
    labels.forEach(function (l, i) { var r = document.createElement('tr'); r.innerHTML = '<td>' + l + '</td>' + sets.map(function (s) { return '<td>' + s.data[i] + '</td>'; }).join(''); b.appendChild(r); });
    t.appendChild(b);
    var w = document.createElement('div'); w.className = 'table-wrap'; w.appendChild(t);
    cv.parentNode.replaceChild(w, cv);
  }
  function make(id, ok, type, labels, sets, opts) {
    var cv = show(id, ok); if (!cv) return;
    if (!has) { table(cv, labels, sets); return; }
    var pie = type === 'doughnut';
    new Chart(cv, {
      type: type,
      data: { labels: labels, datasets: sets.map(function (s) {
        return pie ? { data: s.data, backgroundColor: s.colors, borderWidth: 0 }
                   : { label: s.label, data: s.data, backgroundColor: s.color, borderColor: s.color, tension: .3, fill: false, pointRadius: labels.length > 40 ? 0 : 3 };
      }) },
      options: Object.assign({
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: pie || sets.length > 1, labels: { color: ink } } },
        scales: pie ? {} : {
          x: { stacked: !!(opts && opts.stack), ticks: { color: ink, maxRotation: 0, autoSkip: true }, grid: { display: false } },
          y: { stacked: !!(opts && opts.stack), beginAtZero: true, ticks: { color: ink, precision: 0 }, grid: { color: line } }
        }
      }, pie ? { cutout: '60%' } : {})
    });
  }
  var L = D.labels;
  make('byType', sum(D.byType.values) > 0, 'doughnut', D.byType.labels, [{ data: D.byType.values, colors: [C.green, C.sign] }]);
  make('byStatus', sum(D.byStatus.values) > 0, 'doughnut', D.byStatus.labels, [{ data: D.byStatus.values, colors: [C.green, C.sign, C.red, C.grey] }]);
  make('registrations', sum(D.registrations.student) + sum(D.registrations.instructor) > 0, 'bar', L,
    [{ label: 'Students', data: D.registrations.student, color: C.green }, { label: 'Instructors', data: D.registrations.instructor, color: C.sign }], { stack: true });
  var tot = L.map(function (_, i) { return D.logins.student[i] + D.logins.instructor[i] + D.logins.admin[i]; });
  make('logins', sum(tot) > 0, 'line', L, [{ label: 'All sign-ins', data: tot, color: C.dark }]);
  make('signins', sum(tot) > 0, 'line', L,
    [{ label: 'Students', data: D.logins.student, color: C.green }, { label: 'Instructors', data: D.logins.instructor, color: C.sign }, { label: 'Administrators', data: D.logins.admin, color: C.blue }]);
  make('growth', sum(D.growth.values) > 0, 'line', D.growth.labels, [{ label: 'Total accounts', data: D.growth.values, color: C.green }]);
})();
