/* NEMSU CampusNav - shared helpers */
(function () {
  'use strict';

  var CN = (window.CN = window.CN || {});
  CN.csrf = document.body.getAttribute('data-csrf') || '';

  /** JSON fetch helper. Throws Error(message) on failure; sends you to login when the session ended. */
  CN.api = function (url, options) {
    options = options || {};
    var headers = Object.assign({ Accept: 'application/json', 'X-CSRF-Token': CN.csrf }, options.headers || {});
    return fetch(url, Object.assign({ credentials: 'same-origin' }, options, { headers: headers })).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (res.status === 401) { window.location.href = 'login.php'; }
        if (!res.ok) { throw new Error(data.error || 'Something went wrong. Try again.'); }
        return data;
      });
    });
  };

  /** Tiny DOM builder: el('div', 'class', 'text') */
  CN.el = function (tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) { n.className = cls; }
    if (text !== undefined && text !== null) { n.textContent = text; }
    return n;
  };

  CN.icon = function (name) {
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'ic');
    svg.setAttribute('aria-hidden', 'true');
    var use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', '#i-' + name);
    svg.appendChild(use);
    return svg;
  };

  /* ---- Toasts ---- */
  CN.toast = function (message, type) {
    var box = document.getElementById('toasts');
    if (!box) { box = CN.el('div', 'toasts'); box.id = 'toasts'; document.body.appendChild(box); }
    var t = CN.el('div', 'toast toast-' + (type || 'ok'), message);
    t.setAttribute('role', 'status');
    box.appendChild(t);
    setTimeout(function () { t.classList.add('is-leaving'); setTimeout(function () { t.remove(); }, 300); }, 5000);
  };
  // Messages rendered by the server also fade out.
  Array.prototype.forEach.call(document.querySelectorAll('.toasts .toast'), function (t) {
    setTimeout(function () { t.classList.add('is-leaving'); setTimeout(function () { t.remove(); }, 300); }, 6000);
  });

  /* ---- Location ---- */
  var lastPos = null;

  function readPosition(timeoutMs) {
    return new Promise(function (resolve) {
      if (!('geolocation' in navigator)) { resolve(null); return; }
      navigator.geolocation.getCurrentPosition(
        function (p) {
          lastPos = { lat: p.coords.latitude, lng: p.coords.longitude, at: Date.now() };
          resolve(lastPos);
        },
        function () { resolve(null); },
        { enableHighAccuracy: true, timeout: timeoutMs || 8000, maximumAge: 15000 }
      );
    });
  }

  /** Asks the browser for the position (may show a permission prompt). Resolves null if unavailable. */
  CN.getPosition = function (timeoutMs) {
    if (lastPos && Date.now() - lastPos.at < 20000) { return Promise.resolve(lastPos); }
    return readPosition(timeoutMs);
  };

  /** Uses the position only when permission was already granted (never shows a prompt). */
  CN.quietPosition = function () {
    if (lastPos && Date.now() - lastPos.at < 20000) { return Promise.resolve(lastPos); }
    if (!navigator.permissions || !navigator.permissions.query) { return Promise.resolve(null); }
    return navigator.permissions.query({ name: 'geolocation' }).then(function (s) {
      return s.state === 'granted' ? readPosition(4000) : null;
    }).catch(function () { return null; });
  };

  CN.watchPosition = function (cb) {
    if (!('geolocation' in navigator)) { return null; }
    return navigator.geolocation.watchPosition(function (p) {
      lastPos = { lat: p.coords.latitude, lng: p.coords.longitude, at: Date.now() };
      cb(lastPos, p.coords.accuracy);
    }, function () { cb(null); }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 });
  };

  /* ---- Password fields: eye button + live hints ---- */
  var EYE = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  var EYE_OFF = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.6 6.1A10.5 10.5 0 0112 6c6.4 0 10 6 10 6a17 17 0 01-3.2 3.9M6.5 7.6C3.9 9.4 2 12 2 12s3.6 6 10 6c1.7 0 3.2-.4 4.5-1"/><path d="M9.9 9.9a3 3 0 004.2 4.2"/></svg>';

  CN.initPasswordFields = function () {
    var inputs = document.querySelectorAll('input[type=password]');
    Array.prototype.forEach.call(inputs, function (inp) {
      if (inp.dataset.pw) { return; }
      inp.dataset.pw = '1';

      var wrap = CN.el('div', 'pw');
      inp.parentNode.insertBefore(wrap, inp);
      wrap.appendChild(inp);

      var btn = CN.el('button', 'pw-toggle');
      btn.type = 'button';
      btn.setAttribute('aria-label', 'Show password');
      btn.setAttribute('aria-pressed', 'false');
      btn.innerHTML = EYE;
      btn.addEventListener('click', function () {
        var show = inp.type === 'password';
        var pos = inp.selectionStart;
        inp.type = show ? 'text' : 'password';
        btn.innerHTML = show ? EYE_OFF : EYE;
        btn.setAttribute('aria-pressed', show ? 'true' : 'false');
        btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
        inp.focus();
        try { inp.setSelectionRange(pos, pos); } catch (e) {}
      });
      wrap.appendChild(btn);

      // Live hint: match check for "confirm" fields, length check for new passwords.
      var label = wrap.parentNode;
      var hint = null;
      function ensureHint() {
        if (!hint) { hint = CN.el('small', 'pw-hint'); hint.setAttribute('aria-live', 'polite'); label.appendChild(hint); }
        return hint;
      }
      var form = inp.form;
      if (inp.name === 'confirm' && form) {
        var main = form.querySelector('input[name=password]');
        var update = function () {
          if (!main) { return; }
          var h = ensureHint();
          if (inp.value === '') { h.textContent = ''; h.className = 'pw-hint'; return; }
          var same = inp.value === main.value;
          h.textContent = same ? 'Passwords match' : 'Passwords do not match yet';
          h.className = 'pw-hint ' + (same ? 'ok' : 'bad');
        };
        inp.addEventListener('input', update);
        if (main) { main.addEventListener('input', update); }
      } else if (inp.getAttribute('autocomplete') === 'new-password' && parseInt(inp.getAttribute('minlength') || '0', 10) >= 8) {
        inp.addEventListener('input', function () {
          var h = ensureHint(), n = inp.value.length;
          if (n === 0) { h.textContent = ''; h.className = 'pw-hint'; return; }
          h.textContent = n >= 8 ? 'Long enough (' + n + ' characters)' : n + ' of 8 characters';
          h.className = 'pw-hint ' + (n >= 8 ? 'ok' : 'bad');
        });
      }
    });
  };
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', CN.initPasswordFields); }
  else { CN.initPasswordFields(); }

  /* ---- Theme switch (light / dark), remembered on this device ---- */
  var root = document.documentElement, THEME_KEY = 'cn-theme';
  var darkMq = window.matchMedia('(prefers-color-scheme: dark)');
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function isDark() { var t = root.getAttribute('data-theme'); return t ? t === 'dark' : darkMq.matches; }
  function syncToggles() {
    var d = isDark();
    Array.prototype.forEach.call(document.querySelectorAll('[data-theme-toggle]'), function (b) {
      b.classList.toggle('is-dark', d);
      b.setAttribute('aria-pressed', d ? 'true' : 'false');
      b.setAttribute('aria-label', d ? 'Switch to light mode' : 'Switch to dark mode');
    });
    if (reduceMotion && CN.drawFx) { CN.drawFx(); }
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-theme-toggle]');
    if (!b) { return; }
    var next = isDark() ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try { localStorage.setItem(THEME_KEY, next); } catch (err) {}
    syncToggles();
  });
  if (darkMq.addEventListener) { darkMq.addEventListener('change', syncToggles); }

  /* ---- Background: interactive galaxy (dark) / soft aurora (light) ---- */
  (function () {
    var cv = document.getElementById('fx');
    if (!cv) { return; }
    var ctx = cv.getContext('2d');
    var W = 0, H = 0, stars = [], orbs = [], shoot = null, tick = 0, running = true;
    var heavy = document.body.classList.contains('page-auth');
    var m = { x: -999, y: -999, px: 0, py: 0, tx: 0, ty: 0 };
    function rnd(a, b) { return a + Math.random() * (b - a); }
    function size() {
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = window.innerWidth; H = window.innerHeight;
      cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var n = Math.round(Math.min(heavy ? 150 : 80, W * H / (heavy ? 9500 : 16000))); stars = [];
      for (var i = 0; i < n; i++) { stars.push({ x: rnd(0, W), y: rnd(0, H), z: rnd(.25, 1), r: rnd(.4, 1.6), p: rnd(0, 6.28), vx: rnd(-.12, .12), vy: rnd(-.12, .12), c: i % 3 }); }
      orbs = [[.15, .2, .42, '15,61,46'], [.85, .15, .34, '245,184,0'], [.75, .85, .42, '28,122,88'], [.1, .9, .3, '245,184,0']]
        .map(function (o, i) { return { x: o[0], y: o[1], r: o[2], c: o[3], p: i * 1.7 }; });
      if (reduceMotion) { draw(); }
    }
    function galaxy() {
      var cols = ['200,225,255', '120,220,255', '190,160,255'];
      for (var i = 0; i < stars.length; i++) {
        var s = stars[i];
        s.x += s.vx * s.z; s.y += s.vy * s.z;
        if (s.x < -5) { s.x = W + 5; } if (s.x > W + 5) { s.x = -5; } if (s.y < -5) { s.y = H + 5; } if (s.y > H + 5) { s.y = -5; }
        s.p += .02;
        var x = s.x + m.px * s.z * 26, y = s.y + m.py * s.z * 26;
        var dx = m.x - x, dy = m.y - y, d = Math.sqrt(dx * dx + dy * dy), a = .35 + .65 * Math.abs(Math.sin(s.p));
        if (d < 150) {
          ctx.strokeStyle = 'rgba(34,211,238,' + ((1 - d / 150) * .55) + ')'; ctx.lineWidth = .7;
          ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(m.x, m.y); ctx.stroke();
          s.x += dx * .002; s.y += dy * .002; a = 1;
        }
        ctx.fillStyle = 'rgba(' + cols[s.c] + ',' + a + ')';
        ctx.beginPath(); ctx.arc(x, y, s.r * (d < 150 ? 1.6 : 1), 0, 6.283); ctx.fill();
      }
      if (!shoot && !reduceMotion && Math.random() < .004) { shoot = { x: rnd(0, W), y: rnd(0, H * .4), l: 1 }; }
      if (shoot) {
        var g = ctx.createLinearGradient(shoot.x, shoot.y, shoot.x - 120, shoot.y - 50);
        g.addColorStop(0, 'rgba(255,255,255,' + shoot.l + ')'); g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.strokeStyle = g; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(shoot.x, shoot.y); ctx.lineTo(shoot.x - 120, shoot.y - 50); ctx.stroke();
        shoot.x += 9; shoot.y += 3.6; shoot.l -= .02; if (shoot.l <= 0) { shoot = null; }
      }
    }
    function aurora() {
      for (var i = 0; i < orbs.length; i++) {
        var o = orbs[i], R = o.r * Math.max(W, H);
        var x = o.x * W + Math.sin(tick / 380 + o.p) * 50 + m.px * 40, y = o.y * H + Math.cos(tick / 450 + o.p) * 40 + m.py * 40;
        var g = ctx.createRadialGradient(x, y, 0, x, y, R);
        g.addColorStop(0, 'rgba(' + o.c + ',.2)'); g.addColorStop(1, 'rgba(' + o.c + ',0)');
        ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      }
      var n = Math.min(stars.length, 60);
      for (var j = 0; j < n; j++) {
        var s = stars[j]; s.x += s.vx * s.z * 1.4; s.y += s.vy * s.z * 1.4;
        if (s.x < 0) { s.x = W; } if (s.x > W) { s.x = 0; } if (s.y < 0) { s.y = H; } if (s.y > H) { s.y = 0; }
        for (var k = j + 1; k < n; k++) {
          var q = stars[k], dx = s.x - q.x, dy = s.y - q.y, d = dx * dx + dy * dy;
          if (d < 8100) { ctx.strokeStyle = 'rgba(15,61,46,' + ((1 - d / 8100) * .16) + ')'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(q.x, q.y); ctx.stroke(); }
        }
        var mx = m.x - s.x, my = m.y - s.y, md = Math.sqrt(mx * mx + my * my), pop = md < 120 ? 1 - md / 120 : 0;
        ctx.fillStyle = 'rgba(15,61,46,' + (.3 + pop * .6) + ')';
        ctx.beginPath(); ctx.arc(s.x, s.y, s.r * 1.3 + pop * 3, 0, 6.283); ctx.fill();
      }
    }
    function draw() {
      tick++;
      m.px += (m.tx - m.px) * .06; m.py += (m.ty - m.py) * .06;
      ctx.clearRect(0, 0, W, H);
      if (isDark()) { galaxy(); } else { aurora(); }
    }
    function loop() { if (!running) { return; } draw(); requestAnimationFrame(loop); }
    CN.drawFx = draw;
    window.addEventListener('resize', size);
    window.addEventListener('pointermove', function (e) { m.x = e.clientX; m.y = e.clientY; m.tx = (e.clientX / W - .5) * 2; m.ty = (e.clientY / H - .5) * 2; }, { passive: true });
    window.addEventListener('pointerleave', function () { m.x = m.y = -999; });
    document.addEventListener('visibilitychange', function () { running = !document.hidden && !reduceMotion; if (running) { loop(); } });
    size();
    if (!reduceMotion) { loop(); }
  })();

  /* ---- Holographic card tilt + button ripple ---- */
  Array.prototype.forEach.call(document.querySelectorAll('.holo'), function (card) {
    if (reduceMotion || !window.matchMedia('(hover:hover)').matches) { return; }
    card.addEventListener('pointermove', function (e) {
      var r = card.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      card.style.setProperty('--mx', (x * 100) + '%'); card.style.setProperty('--my', (y * 100) + '%');
      card.style.setProperty('--ry', ((x - .5) * 6) + 'deg'); card.style.setProperty('--rx', ((.5 - y) * 6) + 'deg');
    });
    card.addEventListener('pointerleave', function () { card.style.setProperty('--rx', '0deg'); card.style.setProperty('--ry', '0deg'); });
  });
  document.addEventListener('pointerdown', function (e) {
    var b = e.target.closest('.btn'); if (!b) { return; }
    var r = b.getBoundingClientRect(), sz = Math.max(r.width, r.height), el = document.createElement('span');
    el.className = 'ripple'; el.style.width = el.style.height = sz + 'px';
    el.style.left = (e.clientX - r.left - sz / 2) + 'px'; el.style.top = (e.clientY - r.top - sz / 2) + 'px';
    b.appendChild(el); setTimeout(function () { el.remove(); }, 650);
  });
  syncToggles();

  /* ---- PWA ---- */
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () { /* offline support is optional */ });
    });
  }
})();
