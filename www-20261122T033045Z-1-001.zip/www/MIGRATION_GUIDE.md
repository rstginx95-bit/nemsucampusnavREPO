# Flexible Instructor Approval — update guide (Laragon)

## 1. Back up first
- Laragon → Menu → MySQL → phpMyAdmin → database `nemsu_campusnav` → Export → Quick → SQL → Go. Save the file.
- Or in a terminal: `mysqldump -u root nemsu_campusnav > backup-before-002.sql`
- Copy your whole `C:\laragon\www\nemsu-campusnav1` folder somewhere safe.

## 2. Copy the files
Extract the ZIP over `C:\laragon\www\nemsu-campusnav1`, allowing overwrite.
The ZIP deliberately does NOT contain `database/app.key`, `mail.log`, `codes.txt` or `error.log`, so your
existing key and logs stay untouched. Do not delete your `database/` folder.

## 3. Run migrations 002 and 003 once (in this order)
phpMyAdmin → `nemsu_campusnav` → Import → choose `database/migrations/002_flexible_instructor_approval.sql` → Go.
Then import `database/migrations/003_admin_controls_and_statistics.sql` the same way. It creates `login_events` (sign-in statistics) and activates approved instructors who were still waiting for an emailed link; nothing is deleted.
Migration 002 only creates 3 NEW tables (`application_decisions`, `application_documents`, `email_log`) and is safe to repeat.
It does not change or delete any existing row or table. Fresh installs get the same tables from `schema.sql`.

## 4. Restore (if needed)
phpMyAdmin → select `nemsu_campusnav` → Operations/Import → choose your backup `.sql`.
Or: `mysql -u root nemsu_campusnav < backup-before-002.sql`. To undo only this feature:
`DROP TABLE application_decisions, application_documents, email_log, login_events;` (decision history is lost) and restore the old PHP files.

## 5. Check
Sign in at `admin-login.php` → Verification → Applications. Enabling real email: set `transport` to `smtp` and fill the SMTP
fields in `config.local.php`; while `transport` is `log`, no email is actually sent (the page now says so).
