<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/tokens.php';
require __DIR__ . '/includes/mailer.php';
require __DIR__ . '/includes/staff_verify.php';

// Applicant documents are private. Only an authenticated, approved Admin may open one.
$admin = require_admin();
$id = (int)($_GET['id'] ?? 0);
$d = $id ? q('SELECT * FROM application_documents WHERE id = ?', [$id])->fetch() : false;
$path = $d ? app_doc_dir() . '/' . basename((string)$d['stored_name']) : '';
if (!$d || !is_file($path)) {
    http_response_code(404);
    exit('Document not found.');
}
audit('app_doc_viewed', 'user', (int)$d['user_id'], 'document ' . $id, (int)$admin['id']);
$ext = ['application/pdf' => 'pdf', 'image/jpeg' => 'jpg', 'image/png' => 'png'][$d['mime']] ?? 'bin';
header('Content-Type: ' . $d['mime']);
header('Content-Length: ' . filesize($path));
header('Content-Disposition: attachment; filename="applicant-document-' . $id . '.' . $ext . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($path);
exit;
