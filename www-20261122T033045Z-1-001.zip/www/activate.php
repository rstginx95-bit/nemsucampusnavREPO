<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/tokens.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/auth_page.php';

$token = (string)($_GET['token'] ?? $_POST['token'] ?? '');
$row = link_token_peek($token, 'activate');
$errors = [];
$done = false;

if ($row && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $uid = (int)$row['user_id'];
    $user = q('SELECT * FROM users WHERE id = ?', [$uid])->fetch();
    if (!rate_ok_for('activate', (string)$uid, 5, 900)) {
        $errors[] = 'Too many attempts. Try again in 15 minutes.';
    } elseif ($user && $user['status'] === 'approved' && in_array($user['role'], STAFF_ROLES, true)
              && password_verify((string)($_POST['password'] ?? ''), $user['password_hash'])) {
        q('UPDATE users SET activated_at = NOW() WHERE id = ? AND activated_at IS NULL', [$uid]);
        link_token_burn((int)$row['id']);
        audit('account_activated', 'user', $uid, '', $uid);
        flash('ok', 'Your instructor account is active. Sign in through the separate Instructor Login page.');
        redirect('instructor-login.php');
    } else {
        audit('activation_failed', 'user', $uid, 'wrong password or account not approved', $uid);
        $errors[] = 'That password is not correct.';
    }
}
auth_start('Activate account', true);
?>
  <section class="holo card enter" id="card" aria-labelledby="t">
    <div class="big-icon"><?= icon('shieldcheck') ?></div>
    <?php if (!$row): ?>
      <h1 id="t">This link cannot be used</h1>
      <p class="muted">It may have expired or already been used. Sign in to your application status page to request a new one.</p>
      <a class="btn btn-primary" href="instructor-login.php">Go to Instructor Login</a>
    <?php else: ?>
      <h1 id="t">Activate your account</h1>
      <p class="muted">Confirm your password to finish setting up your instructor/staff account.</p>
      <?php auth_errors($errors); ?>
      <form method="post" class="form">
        <?= csrf_field() ?><input type="hidden" name="token" value="<?= e($token) ?>">
        <label class="field">Password<input type="password" name="password" autocomplete="current-password" required autofocus></label>
        <button class="btn btn-primary" type="submit">Activate</button>
      </form>
    <?php endif; ?>
  </section>
<?php auth_end(); ?>
