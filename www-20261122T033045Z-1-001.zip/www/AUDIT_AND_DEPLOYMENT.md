# NEMSU CampusNav AI — reviewed enhancement build

## What this ZIP changes

This is a source-level enhancement package based on the uploaded project. It is not a live deployment and has not been tested against your local MySQL database, SMTP provider, Google Cloud project, or Apache/Laragon configuration.

### Unified login and role routing
- Student and Instructor sign-in are separate public pages (`student-login.php` and `instructor-login.php`). Administrator sign-in is separate at `admin-login.php` and is not linked from public pages.
- `staff-login.php` remains only as a backward-compatible redirect to `instructor-login.php`.
- Approved, activated instructors use the same login form and are routed to the existing staff workspace (`admin.php`); their first login goes to `onboarding.php` if their profile is incomplete. The Developer-issued invitation link is email-bound and single-use, so instructors do not receive the student numeric verification code.
- Students continue to verify their email during registration. The login flow does not request a new student OTP on every login.
- Staff-specific sign-in OTP is no longer used in the unified flow. Developer MFA/passkeys remain a production security recommendation, not implemented in this build.
- Public instructor/staff registration now requires a valid Developer-issued invitation.

### Developer-only access and instructor provisioning
- `developer.php`, `developer-instructors.php`, and `developer-location-photos.php` use `require_developer()`.
- To preserve compatibility with the current database schema, Developer is implemented as an allowlisted existing `admin` account, not a new database role.
- Set `CN_DEVELOPER_EMAIL` to the exact email of the Developer account. The current default is the first-admin email configured by the original installer: `smquezada@nemsu.edu.ph`.
- The Developer can add an instructor to the official roster and send a single-use invitation. The instructor creates their own password; no password is emailed or stored in plaintext. Deactivating an instructor revokes unused invitations and suspends a linked instructor account; reactivation restores only an already activated account.
- Exact roster match + valid invitation can auto-approve the instructor application, after which the instructor activates the account by email and completes first-login profile onboarding.
- If SMTP is not configured, invitations cannot be delivered. The roster entry remains and the Developer can retry after SMTP is fixed.

### Settings
- `settings.php` is the canonical Settings page. It contains the existing profile and password-change functions from `account.php`.
- `account.php` redirects to `settings.php` for backward compatibility.
- Forgot/reset password remains in the existing password recovery flow.

### Campus photos and Street View
- Added `image_path` to fresh-install `locations` schema.
- Existing installations must back up the database, then run `database/migrations/001_location_images.sql` exactly once.
- Developer can upload JPEG, PNG, or WebP location photos (max 5 MB) using `developer-location-photos.php`.
- Photos are stored under `uploads/locations/`, with script execution denied in that folder.
- Map search results and the destination route panel display the uploaded building/facility photo.
- Google Maps Street View control is enabled where Google imagery coverage exists. It does not create indoor NEMSU imagery. Your uploaded building photos are the first custom visual guide; a full 360-degree indoor tour would need separately captured panoramic images and a dedicated viewer.

### Map referrer adjustment
- Changed the Referrer-Policy from `same-origin` to `strict-origin-when-cross-origin`. This sends only the site origin to cross-origin tile providers and may resolve an OpenStreetMap tile request rejected for missing Referer.
- This does not prove the live map's 403 is fixed. If the failing URL is `map.php`, inspect Apache access rules; if it is a Google Maps or tile URL, inspect provider response, key restrictions, billing, quota, and referrer headers.

### Database protection and sample student list
- `install.php` now refuses to run if the target database contains any tables, even if `.installed` was deleted. This protects existing databases from the destructive `DROP TABLE` statements in `database/schema.sql`.
- Default `database/seed.sql` no longer inserts the three named sample student records. The former sample rows are retained separately in `database/sample-students.sql` for optional testing only.
- This does not delete any student records from your live MySQL database.
- Never run `database/schema.sql` or `database/seed.sql` against an existing populated database.

### Sensitive files excluded from this ZIP
The package excludes `database/app.key`, `database/mail.log`, `database/error.log`, and `database/.installed`, plus one-off password/debug scripts. These files should not be distributed.
- When updating an existing installation, do not overwrite or delete its `database/` directory. Keep its existing `app.key` and `.installed` marker.
- If a copy of this ZIP has already been shared outside your trusted team, rotate any SMTP, Gemini, or Google API credentials that may have been exposed elsewhere.

## Findings about the existing system

| Area | Source-level finding | Rating (importance) |
|---|---|---:|
| Role routing | Two separate login pages existed; staff OTP on every login | 9/10 |
| Developer isolation | `developer.php` used `require_admin()` only | 10/10 |
| Instructor onboarding | Invitation, roster, email verification and activation primitives already existed | 9/10 |
| Schedule | Student/instructor views and conflict-check logic exist | 8/10 |
| Schedule correctness | No live DB or concurrency testing performed; no academic term model found in schema | 8/10 |
| Student data safety | Seed script included named sample students; live DB contents are unknown | 10/10 |
| Database installer | Schema includes destructive DROP TABLE statements | 10/10 |
| Map provider | Google if key configured; otherwise OSM/Leaflet fallback | 8/10 |
| Map 403 | Cannot diagnose without exact failed request and Apache log | 9/10 |
| Building photos | No existing location image field or upload workflow | 7/10 |
| Street View | Google Street View control was disabled; indoor imagery is not supplied by Google automatically | 6/10 |
| Email | SMTP implementation exists, but delivery is untested | 10/10 |

These ratings represent the importance of the improvement or risk, not a claim that the feature is already perfect.

## Tests performed in this build
- PHP syntax lint: run on all PHP files in the packaged project before delivery.
- JavaScript syntax check: run on `assets/js/map.js` if Node.js is available in the build environment.
- Static review: login routing, role gate, invitation workflow, photo upload validation, SQL schema changes and installer guard.\n- Runtime limitation: this build environment has PHP 8.4 but no `pdo_mysql` extension or MySQL client/server, so database-backed execution tests could not be run.
- Not tested: real login against MySQL, actual invitation/OTP email delivery, instructor activation, database migrations, photo upload in Apache, Google Maps API key/billing, OSM tile 403, real route accuracy, schedule conflict behavior under concurrent writes, mobile browser behavior, and backup restore.

## Safe update procedure for an existing Laragon project
1. Export a MySQL backup of `nemsu_campusnav` and copy the whole existing project folder.
2. Stop Apache in Laragon.
3. Copy the updated PHP, JS, CSS and new files into the project. Do not overwrite the existing `database/` directory.
4. Preserve the existing `database/app.key`, `database/.installed`, and existing database records.
5. Set the `CN_DEVELOPER_EMAIL` environment variable to the Developer's exact existing admin email. The PHP configuration reads environment variables; `.env.example` is documentation and is not auto-loaded.
6. Run `database/migrations/001_location_images.sql` once using phpMyAdmin after backup.
7. Configure SMTP using a private `config.local.php` copied from `config.local.php.example` (or environment variables), and configure the Google Maps browser key through environment variables. Restrict the Google key to the production/local test referrers and only the required APIs.
8. Restart Apache and test student login, instructor invitation, email verification, activation, first-login onboarding, Settings, schedule display/edit, location photos, and map.
9. Keep `install.php` and all setup/debug scripts inaccessible or remove them after initial installation.

## Important remaining limitations
- Developer is still stored as `role='admin'` internally for compatibility. A true `developer` role requires a reviewed role-enum/database migration and account conversion.
- This build does not implement a new device-trust OTP process, passkeys, or Developer MFA. SMTP credentials must be supplied locally; this ZIP cannot send mail until an authorized sender account and App Password are configured.
- No new academic semester/term support or timetable CSV import has been implemented.
- The route graph in `seed.sql` contains estimated campus walkways. Verify every path and entrance on site.
- Uploaded building photos are static photos, not an interactive 360-degree indoor Street View.
- Schedule conflict checks are application-level checks; concurrent writes can still race without database-level locking/constraints.
- The exact HTTP 403 root cause remains unverified.
