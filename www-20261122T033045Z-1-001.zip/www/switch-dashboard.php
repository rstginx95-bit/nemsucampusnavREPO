<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';

// Administrator-only. require_admin() answers 403 for everyone else and records the attempt.
// This feature never touches users.role: it only stores a display preference in the admin's own session.
$admin = require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $target = (string)($_POST['target'] ?? '');
    if ($target === 'student' || $target === 'instructor') {
        $_SESSION['preview_role'] = $target;
        audit('preview_started', 'user', (int)$admin['id'], $target . ' dashboard', (int)$admin['id']);
        redirect($target === 'student' ? 'home.php' : 'admin.php');
    }
    unset($_SESSION['preview_role']);
    audit('preview_ended', 'user', (int)$admin['id'], 'returned to admin dashboard', (int)$admin['id']);
    redirect('admin.php');
}

$current = (string)($admin['preview'] ?? '');
render_head('Switch dashboard', 'switch');
?>
<div class="page-head"><div><h1>Switch dashboard</h1><p class="muted">Preview what students and instructors see. Your account stays Administrator the whole time.</p></div></div>
<?php if ($current): ?>
  <div class="notice notice-warn"><?= icon('eye') ?><div>You are currently previewing the <strong><?= e(ucfirst($current)) ?> dashboard</strong>.</div></div>
<?php endif; ?>
<div class="switch-grid">
  <?php foreach ([
      ['student', 'Student Dashboard', 'Home, schedule, calendar, map and the AI assistant exactly as a student sees them.', 'Open Student Dashboard', 'user'],
      ['instructor', 'Instructor Dashboard', 'The instructor view of Manage, schedules and the AI assistant. Read-only.', 'Open Instructor Dashboard', 'idcard'],
      ['admin', 'Admin Dashboard', 'Statistics, account approvals, the roster, the audit log and every management page.', 'Return to Admin Dashboard', 'shield'],
  ] as [$key, $title, $desc, $btn, $ic]): $on = $key === 'admin' ? $current === '' : $current === $key; ?>
    <article class="card switch-card <?= $on ? 'is-current' : '' ?>">
      <span class="switch-ic"><?= icon($ic) ?></span>
      <h2><?= e($title) ?></h2>
      <p class="muted"><?= e($desc) ?></p>
      <?php if ($on): ?><span class="pill pill-live">Currently viewing</span><?php endif; ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="target" value="<?= e($key) ?>">
        <button class="btn <?= $key === 'admin' ? 'btn-primary' : 'btn-ghost' ?>" type="submit"><?= e($btn) ?></button></form>
    </article>
  <?php endforeach; ?>
</div>
<p class="help">Preview is read-only and for your eyes only. Students and instructors cannot see this page, and typing its address as them is refused.</p>
<?php render_foot('switch'); ?>
