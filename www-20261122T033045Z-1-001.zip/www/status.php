<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/tokens.php';
require __DIR__ . '/includes/mailer.php';
require __DIR__ . '/includes/staff_verify.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/auth_page.php';

$u = require_login();
if ($u['mode'] !== 'blocked') {
    redirect(is_staff($u) ? 'admin.php' : 'home.php');
}
if (empty($u['email_verified_at'])) {
    redirect('verify-email.php');
}
$errors = [];
$awaitingActivation = in_array($u['role'], STAFF_ROLES, true) && $u['status'] === 'approved' && empty($u['activated_at']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'resend_activation' && $awaitingActivation) {
    require_post_csrf();
    if (rate_ok_for('activation', (string)$u['id'], 3, 3600)) {
        activation_send((int)$u['id']);
        flash('ok', 'We sent a new activation link to your email.');
    } else {
        flash('error', 'Too many requests. Try again later.');
    }
    redirect('status.php');
}

$app = q('SELECT * FROM staff_applications WHERE user_id = ?', [$u['id']])->fetch();

if ($awaitingActivation) {
    [$icon, $head, $body] = ['mail', 'Activate your account', 'Your application was approved. We emailed you a one-time activation link. Open it to finish, then sign in through the separate Instructor Login page.'];
} elseif ($u['status'] === 'pending_admin') {
    [$icon, $head, $body] = ['clock', 'Waiting for approval', 'Your details were received and are waiting for an administrator to review them. You will get an email when there is a decision.'];
} else {
    [$icon, $head, $body] = ['shieldcheck', 'We are verifying your details', 'Your email is confirmed. We are checking your application. An administrator may contact you if more information is needed. You will get an email when there is a decision.'];
}
auth_start('Application status', true);
?>
  <section class="holo card enter" id="card" aria-labelledby="t">
    <div class="big-icon"><?= icon($icon) ?></div>
    <h1 id="t"><?= e($head) ?></h1>
    <p class="muted"><?= e($body) ?></p>
    <?php auth_errors($errors); ?>
    <ol class="stepper" aria-label="Progress">
      <li class="done"><?= icon('check') ?> Email confirmed</li>
      <li class="<?= $awaitingActivation || $u['status'] === 'pending_admin' ? 'done' : 'now' ?>"><?= $awaitingActivation || $u['status'] === 'pending_admin' ? icon('check') : icon('clock') ?> Details checked</li>
      <li class="<?= $awaitingActivation ? 'done' : ($u['status'] === 'pending_admin' ? 'now' : '') ?>"><?= icon($awaitingActivation ? 'check' : 'clock') ?> Administrator approval</li>
      <li class="<?= $awaitingActivation ? 'now' : '' ?>"><?= icon('mail') ?> Activate and sign in</li>
    </ol>
    <?php if ($awaitingActivation): ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="resend_activation"><button class="btn btn-ghost" type="submit">Send the activation link again</button></form>
    <?php endif; ?>
    <a class="btn btn-ghost" href="status.php">Check again</a>
    <form method="post" action="logout.php" class="inline-form"><?= csrf_field() ?><button class="link-btn" type="submit">Log out</button></form>
    <p class="note">Until your account is approved and activated, you cannot use any instructor or staff feature.</p>
  </section>
<?php auth_end(); ?>
