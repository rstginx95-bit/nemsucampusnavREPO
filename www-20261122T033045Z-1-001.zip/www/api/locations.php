<?php
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';
require __DIR__ . '/../includes/layout.php';
require __DIR__ . '/../includes/locations.php';

api_user();
if (isset($_GET['all'])) {
    $items = array_values(array_filter(all_locations(), fn($l) => $l['lat'] !== null && in_array($l['type'], ['building', 'facility'], true)));
    json_out(['items' => array_map('location_public', $items)]);
}
if (isset($_GET['id'])) {
    $l = location_by_id((int)$_GET['id']);
    $l ? json_out(['item' => location_public($l)]) : json_out(['error' => 'Place not found.'], 404);
}
$query = mb_substr(trim((string)($_GET['q'] ?? '')), 0, 80);
json_out(['items' => array_map('location_public', search_locations($query, 12))]);
