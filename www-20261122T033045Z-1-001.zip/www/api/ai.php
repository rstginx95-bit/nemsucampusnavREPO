<?php
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';
require __DIR__ . '/../includes/layout.php';
require __DIR__ . '/../includes/ai.php';

$u = api_user();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $rows = q('SELECT sender, body FROM ai_messages WHERE user_id = ? ORDER BY id DESC LIMIT 30', [$u['id']])->fetchAll();
    json_out(['history' => array_reverse($rows), 'chips' => ai_default_chips($u)]);
}

require_post_csrf(true);
if (!rate_ok('ai', 40, 300)) {
    json_out(['error' => 'You are sending messages too fast. Wait a moment.'], 429);
}
$input = json_decode((string)file_get_contents('php://input'), true);
$message = mb_substr(trim((string)($input['message'] ?? '')), 0, 400);
$lat = isset($input['lat']) && is_numeric($input['lat']) ? (float)$input['lat'] : null;
$lng = isset($input['lng']) && is_numeric($input['lng']) ? (float)$input['lng'] : null;
if ($message === '') {
    json_out(['error' => 'Type a question first.'], 400);
}
$result = ai_respond($u, $message, $lat, $lng);

q('INSERT INTO ai_messages (user_id, sender, body) VALUES (?, "user", ?)', [$u['id'], $message]);
q('INSERT INTO ai_messages (user_id, sender, body) VALUES (?, "ai", ?)', [$u['id'], $result['reply']]);
$cut = q('SELECT id FROM ai_messages WHERE user_id = ? ORDER BY id DESC LIMIT 1 OFFSET 100', [$u['id']])->fetch();
if ($cut) {
    q('DELETE FROM ai_messages WHERE user_id = ? AND id <= ?', [$u['id'], $cut['id']]);
}
json_out($result);
