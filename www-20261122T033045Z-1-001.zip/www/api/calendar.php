<?php
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';
require __DIR__ . '/../includes/layout.php';
require __DIR__ . '/../includes/locations.php';
require __DIR__ . '/../includes/schedule.php';

$u = api_user();
if (!has_basic_access($u)) {
    json_out(['error' => 'Verify your Student ID first.'], 403);
}
$m = (string)($_GET['m'] ?? date('Y-m'));
if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $m)) {
    json_out(['error' => 'Bad month.'], 400);
}
$first = new DateTimeImmutable($m . '-01');
$last  = $first->modify('last day of this month');
$events = array_map(fn($e) => [
    'id' => (int)$e['id'], 'title' => $e['title'], 'category' => $e['category'],
    'start' => $e['start_date'], 'end' => $e['end_date'], 'desc' => $e['description'],
], calendar_events_between($first->format('Y-m-d'), $last->format('Y-m-d')));

$classes = [];
if (has_schedule_access($u)) {
    foreach (user_schedule($u) as $r) {
        $classes[] = ['dow' => $r['day_of_week'], 'code' => $r['subject_code'], 'title' => $r['subject_title'],
            'start' => $r['start'], 'end' => $r['end'], 'place' => $r['place_short'], 'room_id' => $r['room_id'], 'sort' => $r['start_time']];
    }
}
json_out(['month' => $m, 'today' => date('Y-m-d'), 'events' => $events, 'classes' => $classes, 'canAdd' => is_staff($u)]);
