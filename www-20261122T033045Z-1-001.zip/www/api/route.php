<?php
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';
require __DIR__ . '/../includes/layout.php';
require __DIR__ . '/../includes/locations.php';
require __DIR__ . '/../includes/routing.php';

api_user();
$to  = (int)($_GET['to'] ?? 0);
$lat = isset($_GET['lat']) && is_numeric($_GET['lat']) ? (float)$_GET['lat'] : null;
$lng = isset($_GET['lng']) && is_numeric($_GET['lng']) ? (float)$_GET['lng'] : null;
if ($to <= 0) {
    json_out(['error' => 'Choose a destination first.'], 400);
}
$route = build_route($to, $lat, $lng);
json_out($route, isset($route['error']) ? 404 : 200);
