<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';

$developer = require_developer();
$errors = [];
$success = '';
$locations = [];

try {
    $locations = q("SELECT id, name, type, image_path FROM locations ORDER BY name")->fetchAll();
} catch (Throwable $e) {
    $errors[] = 'Location photo support is not enabled yet. Back up the database, then run database/migrations/001_location_images.sql once.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $id = (int)($_POST['location_id'] ?? 0);
    $location = null;
    foreach ($locations as $item) if ((int)$item['id'] === $id) $location = $item;

    if (!$location) {
        $errors[] = 'Choose a valid campus location.';
    } elseif (!isset($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'Choose a photo to upload.';
    } else {
        $file = $_FILES['photo'];
        if ((int)$file['size'] < 1 || (int)$file['size'] > 5 * 1024 * 1024) {
            $errors[] = 'The photo must be 5 MB or smaller.';
        } else {
            $info = @getimagesize($file['tmp_name']);
            $mime = $info['mime'] ?? '';
            $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            if (!$info || !isset($allowed[$mime])) {
                $errors[] = 'Only valid JPEG, PNG, and WebP images are accepted. SVG is not allowed.';
            } else {
                $dir = CN_ROOT . '/uploads/locations';
                if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
                    $errors[] = 'The uploads/locations folder could not be created.';
                } else {
                    $filename = bin2hex(random_bytes(18)) . '.' . $allowed[$mime];
                    $target = $dir . '/' . $filename;
                    if (!move_uploaded_file($file['tmp_name'], $target)) {
                        $errors[] = 'The server could not save the uploaded photo.';
                    } else {
                        try {
                            q('UPDATE locations SET image_path = ? WHERE id = ?', [$filename, $id]);
                            $old = basename((string)($location['image_path'] ?? ''));
                            if ($old !== '' && $old !== $filename) {
                                $oldPath = $dir . '/' . $old;
                                if (is_file($oldPath)) @unlink($oldPath);
                            }
                            audit('location_photo_updated', 'location', $id, 'Photo uploaded: ' . $filename, (int)$developer['id']);
                            $success = 'Photo saved for ' . $location['name'] . '.';
                            $locations = q("SELECT id, name, type, image_path FROM locations ORDER BY name")->fetchAll();
                        } catch (Throwable $e) {
                            @unlink($target);
                            $errors[] = 'The database could not save the photo path. Confirm the location-image migration has been applied.';
                        }
                    }
                }
            }
        }
    }
}

render_head('Location Photos', 'admin');
?>
<main class="page-shell">
  <header class="page-head">
    <div><h1>Campus Location Photos</h1><p class="muted">Upload real photos so students can recognize buildings and facilities.</p></div>
    <a class="btn btn-ghost" href="developer.php">Back to Developer Center</a>
  </header>
  <?php if ($success): ?><div class="notice notice-ok" role="status"><?= e($success) ?></div><?php endif; ?>
  <?php foreach ($errors as $error): ?><div class="notice notice-error" role="alert"><?= e($error) ?></div><?php endforeach; ?>
  <section class="card">
    <h2>Add or replace a location photo</h2>
    <p class="muted">Use a clear, landscape or portrait photograph of the actual NEMSU building. Maximum 5 MB. JPEG, PNG, or WebP only.</p>
    <form method="post" enctype="multipart/form-data" class="form">
      <?= csrf_field() ?>
      <label class="field">Campus location
        <select name="location_id" required>
          <option value="">Choose a building or facility</option>
          <?php foreach ($locations as $location): ?>
            <option value="<?= (int)$location['id'] ?>"><?= e($location['name'] . ' · ' . $location['type']) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="field">Photo<input type="file" name="photo" accept="image/jpeg,image/png,image/webp" required></label>
      <button class="btn btn-primary" type="submit">Upload photo</button>
    </form>
  </section>
  <section class="card">
    <h2>Current photos</h2>
    <div class="location-photo-grid">
      <?php foreach ($locations as $location): ?>
        <article class="location-photo-card">
          <?php if (!empty($location['image_path'])): ?>
            <img src="uploads/locations/<?= e(rawurlencode(basename($location['image_path']))) ?>" alt="<?= e($location['name']) ?>" loading="lazy">
          <?php else: ?>
            <div class="location-photo-empty">No photo uploaded</div>
          <?php endif; ?>
          <strong><?= e($location['name']) ?></strong>
          <small><?= e($location['type']) ?></small>
        </article>
      <?php endforeach; ?>
    </div>
  </section>
</main>
<style>
.location-photo-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:14px}
.location-photo-card{display:grid;gap:6px;min-width:0}
.location-photo-card img,.location-photo-empty{width:100%;height:130px;object-fit:cover;border-radius:12px;background:#eef2ef}
.location-photo-empty{display:grid;place-items:center;color:#64756b;font-size:13px}
.location-photo-card small{color:#68766f}
</style>
<?php render_foot('admin'); ?>
