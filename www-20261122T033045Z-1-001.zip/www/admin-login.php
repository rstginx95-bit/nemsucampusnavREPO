<?php
declare(strict_types=1);
header('Cache-Control: no-store, private');
header('X-Robots-Tag: noindex, nofollow', true);
$login_role = 'admin';
require __DIR__ . '/includes/role_login.php';
