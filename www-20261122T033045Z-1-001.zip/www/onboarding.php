<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/auth_page.php';
require __DIR__ . '/includes/verify.php';

$u = require_login();
if ($u['mode'] === 'blocked') {
    redirect(empty($u['email_verified_at']) ? 'verify-email.php' : 'status.php');
}
$staff = is_staff($u);
$errors = [];
$stepId = ($_GET['step'] ?? '') === 'id';

/* ---------------- POST ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'profile') {
        $p = collect_profile($_POST, $errors);
        if ($p['mobile'] && q('SELECT 1 FROM users WHERE mobile = ? AND id <> ?', [$p['mobile'], $u['id']])->fetch()) {
            $errors[] = 'That mobile number is already used by another account.';
        }
        if (!$errors) {
            // Roles, status and student type are never taken from this form.
            q('UPDATE users SET full_name = ?, birthday = ?, address = ?, mobile = ?, profile_done = 1 WHERE id = ?',
                [$p['full_name'], $p['birthday'], $p['address'], $p['mobile'], $u['id']]);
            flash('ok', 'Your information is saved.');
            if ($staff) redirect('admin.php');
            redirect($u['mode'] === 'pending' ? 'onboarding.php?step=id' : 'home.php');
        }
    }

    if ($action === 'verify' && !$staff && $u['profile_done']) {
        if (verify_student_id($u, (string)($_POST['student_no'] ?? ''), $errors)) {
            flash('ok', 'Student ID verified. Your schedule is ready.');
            redirect('schedule.php');
        }
        $stepId = true;
    }

}

// Nothing left to do here?
$u = current_user();
if ($u['profile_done'] && !$stepId && $_SERVER['REQUEST_METHOD'] === 'GET') {
    redirect(is_staff($u) ? 'admin.php' : 'home.php');
}
if ($u['mode'] === 'student' && $u['profile_done']) {
    redirect('home.php');
}
if ($stepId && (!$u['profile_done'] || $staff || $u['mode'] !== 'pending')) {
    $stepId = false;   // freshmen verify later from Account
    if ($u['profile_done']) redirect(is_staff($u) ? 'admin.php' : 'home.php');
}

$v = fn(string $k, $d = '') => e($_POST[$k] ?? ($u[$k] ?? $d));
$today = (new DateTimeImmutable('today'))->format('Y-m-d');

page_open($stepId ? 'Verify your Student ID' : 'Set up your profile', 'page-onboarding', ['fx' => true]);
?>
<div class="onb">
  <header class="onb-top">
    <span class="topbar-brand"><span class="brand-mark" aria-hidden="true"><?= icon('nav') ?></span>NEMSU CampusNav AI</span>
    <div class="topbar-actions"><?= theme_toggle() ?></div>
    <form method="post" action="logout.php"><?= csrf_field() ?><button class="link-btn" type="submit">Log out</button></form>
  </header>

  <?php if ($stepId): ?>
  <!-- ======== Student ID step ======== -->
  <main class="onb-card">
    <div class="onb-icon"><?= icon('idcard') ?></div>
    <h1>Verify your Student ID</h1>
    <?php if ($u['student_type'] === 'transferee'): ?>
      <p class="muted">Transferees use the <strong>NEMSU Student ID</strong> issued by the Registrar when you enroll. It has the same format as every other student's ID. Your previous school's ID is not used here.</p>
    <?php else: ?>
      <p class="muted">Enter the Student ID on your NEMSU records. We match it with your name (<strong><?= e($u['full_name']) ?></strong>) to confirm you are a NEMSU student.</p>
    <?php endif; ?>

    <?php foreach ($errors as $err): ?>
      <div class="notice notice-error" role="alert"><?= icon('alert') ?><div><?= e($err) ?></div></div>
    <?php endforeach; ?>

    <form method="post" class="form">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="verify">
      <label class="field"><span>Student ID number</span>
        <input type="text" name="student_no" value="<?= e($_POST['student_no'] ?? '') ?>" placeholder="24-00000" autocomplete="off" autocapitalize="characters" maxlength="30" required autofocus></label>
      <button class="btn btn-primary btn-block" type="submit"><?= icon('user-check') ?> Verify and open my schedule</button>
    </form>

    <p class="help center">Old students need a verified ID before the app opens. If your ID is not found, ask your instructor or the Registrar to add you to the student list.</p>
  </main>

  <?php else: ?>
  <!-- ======== Profile wizard ======== -->
  <main class="onb-card" id="wizard" data-staff="<?= $staff ? '1' : '0' ?>">
    <div class="progress" aria-hidden="true"><span id="progress-bar"></span></div>
    <p class="step-count" id="step-count" aria-live="polite"></p>

    <?php foreach ($errors as $err): ?>
      <div class="notice notice-error" role="alert"><?= icon('alert') ?><div><?= e($err) ?></div></div>
    <?php endforeach; ?>

    <form method="post" id="wizard-form" novalidate>
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="profile">

      <section class="step" data-step="1">
        <h1>What is your full name?</h1>
        <p class="muted">Write it the way it appears on your school records, for example <em>Cj I. Labastilla</em>.</p>
        <label class="field"><span>Full name</span>
          <input type="text" name="full_name" value="<?= $v('full_name') ?>" autocomplete="name" maxlength="120" required></label>
      </section>

      <section class="step" data-step="2" hidden>
        <h1>When were you born?</h1>
        <p class="muted">Your age is worked out from your birthday.</p>
        <div class="field-row">
          <label class="field"><span>Birthday</span>
            <input type="date" name="birthday" id="birthday" value="<?= $v('birthday') ?>" max="<?= e($today) ?>" autocomplete="bday" required></label>
          <label class="field"><span>Age</span>
            <input type="text" id="age" readonly tabindex="-1" placeholder="-" aria-live="polite"></label>
        </div>
      </section>

      <section class="step" data-step="3" hidden>
        <h1>Where do you live?</h1>
        <p class="muted">Barangay or street, city or municipality, and province.</p>
        <label class="field"><span>Address</span>
          <textarea name="address" rows="3" maxlength="250" autocomplete="street-address" placeholder="Brgy. ..., Tandag City, Surigao del Sur" required><?= $v('address') ?></textarea></label>
        <label class="field"><span>Mobile number (optional)</span>
          <input type="tel" name="mobile" value="<?= $v('mobile') ?>" inputmode="tel" autocomplete="tel" placeholder="0917 123 4567">
          <small class="help">Lets you log in with your mobile number too.</small></label>
      </section>

      <p class="notice notice-error" id="step-error" role="alert" hidden></p>

      <div class="wizard-nav">
        <button type="button" class="btn btn-ghost" id="btn-back"><?= icon('chevron-left') ?> Back</button>
        <button type="button" class="btn btn-primary" id="btn-next">Next</button>
      </div>
    </form>
  </main>
  <?php endif; ?>
</div>
<script src="assets/js/app.js?v=4"></script>
<?php if (!$stepId): ?><script src="assets/js/onboarding.js?v=4"></script><?php endif; ?>
</body>
</html>
