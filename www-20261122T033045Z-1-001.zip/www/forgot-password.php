<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/tokens.php';
require __DIR__ . '/includes/mailer.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/auth_page.php';

$sent = false;
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    if (!rate_ok_for('forgot', $email, 3, 3600)) {
        $errors[] = 'Too many requests. Please wait an hour and try again.';
    } else {
        $user = filter_var($email, FILTER_VALIDATE_EMAIL) ? q('SELECT * FROM users WHERE email = ?', [$email])->fetch() : false;
        // Same screen whether or not the account exists, so nobody can test which emails are registered.
        if ($user && !in_array($user['status'], ['suspended', 'rejected', 'pending_email'], true)) {
            $tok = link_token_issue((int)$user['id'], 'reset', (int)cfg('security.reset_ttl_minutes', 30) * 60);
            send_mail($user['email'], 'Reset your NEMSU CampusNav AI password',
                "Someone asked to reset the password for this account.\nOpen this link within " . (int)cfg('security.reset_ttl_minutes', 30)
                . " minutes (it works once):\n\n" . app_url('reset-password.php?token=' . $tok)
                . "\n\nIf this was not you, ignore this email. Your password stays the same.\n");
            audit('reset_requested', 'user', (int)$user['id'], '', (int)$user['id']);
        }
        $sent = true;
    }
}
auth_start('Forgot password');
?>
  <section class="holo card enter" id="card" aria-labelledby="t">
    <div class="big-icon"><?= icon('lock') ?></div>
    <h1 id="t">Forgot your password?</h1>
    <?php if ($sent): ?>
      <div class="notice notice-ok"><?= icon('check') ?><div>If that email has an account, a reset link is on its way. It works once and expires soon.</div></div>
      <?php if (cfg('mail.transport') === 'log'): ?><p class="note">Local testing mode: the link is in <code>database/mail.log</code>.</p><?php endif; ?>
    <?php else: ?>
      <p class="muted">Enter the email address registered to your account and we will send you a reset link.</p>
      <?php auth_errors($errors); ?>
      <form method="post" class="form"><?= csrf_field() ?>
        <label class="field">Registered email address<input type="email" name="email" autocomplete="email" required autofocus></label>
        <button class="btn btn-primary" type="submit">Send reset link</button>
      </form>
    <?php endif; ?>
    <p class="foot"><a class="hu" href="login.php">Back to log in</a></p>
  </section>
<?php auth_end(); ?>
