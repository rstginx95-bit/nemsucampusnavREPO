<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/tokens.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/auth_page.php';

$token = (string)($_GET['token'] ?? $_POST['token'] ?? '');
$row = link_token_peek($token, 'reset');
$errors = [];

if ($row && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $user = q('SELECT * FROM users WHERE id = ?', [$row['user_id']])->fetch();
    $new = (string)($_POST['password'] ?? '');
    if (!$user) {
        link_token_burn((int)$row['id']);
        $row = null;
    }
    $isStaff = $user && ($user['requested_role'] !== 'student' || in_array($user['role'], STAFF_ROLES, true));
    if (!$user) {
        $errors[] = 'This reset link is no longer valid. Request a new one.';
    } elseif (!rate_ok_for('reset', (string)$row['user_id'], 6, 900)) {
        $errors[] = 'Too many attempts. Try again in 15 minutes.';
    } elseif ($pw = password_problem($new, (string)$user['email'], $isStaff)) {
        $errors[] = $pw;
    } elseif ($new !== (string)($_POST['confirm'] ?? '')) {
        $errors[] = 'The two passwords do not match.';
    } else {
        q('UPDATE users SET password_hash = ?, password_changed_at = NOW() WHERE id = ?', [hash_password($new), $user['id']]);
        link_token_burn((int)$row['id']);
        q("UPDATE auth_tokens SET used_at = NOW() WHERE user_id = ? AND purpose = 'reset' AND used_at IS NULL", [$user['id']]);
        audit('password_reset', 'user', (int)$user['id'], '', (int)$user['id']);       // every other session is signed out
        flash('ok', 'Your password was changed. You can log in now.');
        redirect('login.php');
    }
}
auth_start('Reset password');
?>
  <section class="holo card enter" id="card" aria-labelledby="t">
    <div class="big-icon"><?= icon('lock') ?></div>
    <?php if (!$row): ?>
      <h1 id="t">This link cannot be used</h1>
      <p class="muted">It may have expired or been used already. Ask for a new one.</p>
      <a class="btn btn-primary" href="forgot-password.php">Send a new link</a>
    <?php else: ?>
      <h1 id="t">Choose a new password</h1>
      <?php auth_errors($errors); ?>
      <form method="post" class="form"><?= csrf_field() ?><input type="hidden" name="token" value="<?= e($token) ?>">
        <label class="field">New password<input type="password" name="password" autocomplete="new-password" minlength="12" required autofocus></label>
        <label class="field">Confirm new password<input type="password" name="confirm" autocomplete="new-password" required></label>
        <button class="btn btn-primary" type="submit">Save password</button>
      </form>
    <?php endif; ?>
  </section>
<?php auth_end(); ?>
