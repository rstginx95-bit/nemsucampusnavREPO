<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/locations.php';
require __DIR__ . '/includes/schedule.php';

$u = require_login();

$now = new DateTimeImmutable('now');

$access = has_schedule_access($u);

$rows = $access ? user_schedule($u) : [];

$today = classes_on_day(
    $rows,
    (int)$now->format('N')
);

$next = $access ? next_class($rows, $now) : null;

$gkey = trim((string)cfg('maps.google_key', ''));

$boot = [
    'campus' => [
        'lat' => (float)cfg('campus.lat'),
        'lng' => (float)cfg('campus.lng')
    ],
    'to' => isset($_GET['to'])
        ? (int)$_GET['to']
        : null,
    'provider' => $gkey !== '' ? 'google' : 'osm'
];

render_head('Map', 'map', [
    'bleed' => true,
    'leaflet' => $gkey === ''
]);
?>

<div class="map-layout">

    <div class="map-stage">

        <div
            id="map"
            role="application"
            aria-label="NEMSU campus map"
        ></div>

        <div
            class="map-fallback"
            id="map-fallback"
            hidden
        >
            <p>
                The map could not load.
                Check your internet connection
                and Google Maps configuration.
            </p>
        </div>

        <button
            type="button"
            class="fab"
            id="locate-btn"
            aria-label="Show my location"
        >
            <?= icon('target') ?>
        </button>

        <div
            class="loc-prompt"
            id="loc-prompt"
            hidden
        >

            <?= icon('pin') ?>

            <div>
                <strong>Turn on your location</strong>

                <small>
                    Allow location access so directions
                    start from your current position.
                </small>
            </div>

            <button
                type="button"
                class="btn btn-sign btn-small"
                id="loc-allow"
            >
                Allow
            </button>

            <button
                type="button"
                class="icon-btn icon-btn-quiet"
                id="loc-dismiss"
                aria-label="Dismiss"
            >
                <?= icon('x') ?>
            </button>

        </div>

    </div>

    <section
        class="map-panel sheet-peek"
        id="panel"
        aria-label="Search and directions"
    >

        <button
            type="button"
            class="sheet-handle"
            id="sheet-handle"
            aria-label="Expand or collapse panel"
        >
            <span></span>
        </button>

        <form
            class="search"
            id="search-form"
            role="search"
            autocomplete="off"
        >

            <?= icon('search') ?>

            <label
                class="sr-only"
                for="q"
            >
                Search the campus
            </label>

            <input
                id="q"
                type="search"
                placeholder="Search buildings, rooms, offices"
                enterkeyhint="search"
            >

        </form>

        <div
            id="results"
            class="results"
            aria-live="polite"
        ></div>

        <div
            id="route"
            class="route"
            hidden
        >

            <img id="route-photo" class="route-photo" alt="" hidden>

            <div class="route-head">

                <div>
                    <h2 id="route-title"></h2>

                    <p
                        class="muted"
                        id="route-meta"
                    ></p>
                </div>

                <button
                    type="button"
                    class="icon-btn"
                    id="route-clear"
                    aria-label="Clear route"
                >
                    <?= icon('x') ?>
                </button>

            </div>

            <ol
                class="crumbs crumbs-light"
                id="route-crumbs"
                aria-label="Route"
            ></ol>

            <a
                class="btn btn-ghost btn-block"
                id="gmaps-link"
                href="#"
                target="_blank"
                rel="noopener"
            >
                <?= icon('external') ?>
                Open in Google Maps
            </a>

            <ol
                class="steps"
                id="route-steps"
            ></ol>

            <p
                class="muted route-note"
                id="route-note"
                hidden
            ></p>

        </div>

        <?php if ($access && $today): ?>

            <div
                class="panel-block"
                id="today-block"
            >

                <h3>Today's classes</h3>

                <ul class="mini-list">

                    <?php foreach ($today as $r): ?>

                        <?php
                        if (!$r['room_id']) {
                            continue;
                        }
                        ?>

                        <li>

                            <button
                                type="button"
                                data-nav-to="<?= (int)$r['room_id'] ?>"
                            >

                                <time>
                                    <?= e($r['start']) ?>
                                </time>

                                <span>
                                    <strong>
                                        <?= e($r['subject_code']) ?>
                                    </strong>

                                    <?= e($r['place_short']) ?>
                                </span>

                                <?= icon('chevron') ?>

                            </button>

                        </li>

                    <?php endforeach; ?>

                </ul>

            </div>

        <?php elseif ($next && $next['row']['room_id']): ?>

            <div class="panel-block">

                <h3>Next class</h3>

                <ul class="mini-list">

                    <li>

                        <button
                            type="button"
                            data-nav-to="<?= (int)$next['row']['room_id'] ?>"
                        >

                            <time>
                                <?= e($next['row']['start']) ?>
                            </time>

                            <span>
                                <strong>
                                    <?= e($next['row']['subject_code']) ?>
                                </strong>

                                <?= e($next['row']['place_short']) ?>
                            </span>

                            <?= icon('chevron') ?>

                        </button>

                    </li>

                </ul>

            </div>

        <?php endif; ?>

    </section>

</div>

<script>
window.CN_MAP = <?= json_encode(
    $boot,
    JSON_HEX_TAG |
    JSON_HEX_AMP |
    JSON_HEX_APOS |
    JSON_HEX_QUOT
) ?>;
</script>

<?php

if ($gkey === '') {

    $scripts = [
        'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js',
        'assets/js/map.js?v=7'
    ];

} else {

    $scripts = [
        'assets/js/map.js?v=7',
        'https://maps.googleapis.com/maps/api/js?key=' .
        rawurlencode($gkey) .
        '&callback=cnGoogleReady&loading=async'
    ];

}

render_foot('map', $scripts);
?>
