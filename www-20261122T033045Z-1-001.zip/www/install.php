<?php
/**
 * One-time installer: creates the database, tables, campus map starter data and the FIRST Developer/admin account.
 *   Command line (best):  php install.php          Browser (localhost only):  http://localhost/nemsu-campusnav/install.php
 * It prints the administrator's one-time password ONCE. Delete this file afterwards.
 */
declare(strict_types=1);

$config = require __DIR__ . '/config.php';
$cli    = PHP_SAPI === 'cli';
$lock   = __DIR__ . '/database/.installed';

function say(string $s): void
{
    global $cli;
    echo $cli ? $s . PHP_EOL : htmlspecialchars($s) . "\n";
}

function run_sql_file(PDO $pdo, string $path): int
{
    $sql = preg_replace('/^\s*--.*$/m', '', (string)file_get_contents($path));
    $count = 0;
    foreach (preg_split('/;\s*\n/', (string)$sql) as $stmt) {
        $stmt = trim($stmt);
        if ($stmt === '') continue;
        try {
            $pdo->exec($stmt);
        } catch (PDOException $e) {
            throw new RuntimeException($e->getMessage() . "\n  in " . basename($path) . ': ' . substr(preg_replace('/\s+/', ' ', $stmt), 0, 110) . '...');
        }
        $count++;
    }
    return $count;
}

if (!$cli) {
    header('Content-Type: text/plain; charset=utf-8');
    $remote = $_SERVER['REMOTE_ADDR'] ?? '';
    if (!in_array($remote, ['127.0.0.1', '::1'], true) && !getenv('CN_ALLOW_REMOTE_INSTALL')) {
        http_response_code(403);
        exit("The installer only runs from localhost. Run `php install.php` on the server.\n");
    }
}

try {
    $c = $config['db'];
    $pdo = new PDO("mysql:host={$c['host']};charset={$c['charset']}", $c['user'], $c['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => true,
    ]);
    $db = str_replace('`', '', $c['name']);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$db`");
    say("Database `$db` ready.");

    $existingTables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    if (count($existingTables) > 0) {
        exit("This database already contains tables. The installer has stopped to protect existing data. Use a new empty database for a fresh install, or reviewed non-destructive migrations for updates.\n");
    }
    if (file_exists($lock)) {
        exit("An installation marker already exists. The installer will not run again.\n");
    }

    $n = run_sql_file($pdo, __DIR__ . '/database/schema.sql');
    say("Tables created ($n statements).");
    run_sql_file($pdo, __DIR__ . '/database/seed.sql');
    say('Campus map starter data loaded. No students, instructors, subjects, sections, schedules, or staff roster were preloaded.');

    // First administrator: use the credentials requested for this deployment.
    // The password is stored only as a strong one-way hash in the database.
    $pw = getenv('CN_ADMIN_PASSWORD') !== false ? (string)getenv('CN_ADMIN_PASSWORD') : '123!@#simon';
    $adminEmail = strtolower((string)$config['security']['developer_email']);
    if ($pw === '' || strlen($pw) < 10) {
        throw new RuntimeException('CN_ADMIN_PASSWORD must contain at least 10 characters.');
    }
    $hash = defined('PASSWORD_ARGON2ID') ? password_hash($pw, PASSWORD_ARGON2ID) : password_hash($pw, PASSWORD_BCRYPT, ['cost' => 12]);
    $pdo->prepare("INSERT INTO users (email, password_hash, full_name, role, requested_role, status, instructor_id, email_verified_at, activated_at, approved_at, profile_done)
                   VALUES (?,?,?, 'admin', 'instructor', 'approved', NULL, NOW(), NOW(), NOW(), 1)")
        ->execute([$adminEmail, $hash, 'CampusNav Administrator']);
    file_put_contents(__DIR__ . '/database/app.key', bin2hex(random_bytes(32)));
    @chmod(__DIR__ . '/database/app.key', 0600);

    say('');
    say('First administrator / Developer (sign in at admin-login.php):');
    say('  email:    ' . $adminEmail);
    say('  password: ' . $pw . '   <- configured for this fresh installation. Change it after first sign-in.');
    say('  Use the separate administrator login page. Change the one-time password after signing in.');
    say('  Configure real SMTP delivery in config.local.php before testing email.');
    file_put_contents($lock, date('c'));
    say('');
    say('Next: 1) DELETE install.php   2) configure SMTP in config.local.php   3) open check.php');
} catch (Throwable $e) {
    http_response_code(500);
    say('Install failed: ' . $e->getMessage());
    say('Check the database settings in config.php, then open check.php.');
}
