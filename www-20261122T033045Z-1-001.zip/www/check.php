<?php
/**
 * Setup checker. Open http://localhost/nemsu-campusnav/check.php
 * It tests PHP, the database and the tables, and shows the last errors. Works only from localhost.
 * Delete it when the app is live.
 */
declare(strict_types=1);

$remote = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
if (!in_array($remote, ['127.0.0.1', '::1'], true) && !getenv('CN_ALLOW_REMOTE_INSTALL')) {
    http_response_code(403);
    exit('check.php only runs on the same computer as the server (localhost).');
}

$rows = [];
function row(string $label, bool $ok, string $detail = '', string $fix = ''): void
{
    global $rows;
    $rows[] = [$label, $ok, $detail, $fix];
}

row('PHP version', version_compare(PHP_VERSION, '7.4.0', '>='), PHP_VERSION,
    'Use PHP 7.4 or newer (8.x recommended). In XAMPP, install a recent version.');
foreach (['pdo_mysql' => true, 'mbstring' => true, 'json' => true, 'openssl' => true, 'curl' => false, 'zip' => false] as $ext => $required) {
    $has = extension_loaded($ext);
    row("PHP extension: $ext" . ($required ? '' : ' (optional, needed for Gemini)'), $has || !$required, $has ? 'loaded' : 'missing',
        "Enable extension=$ext in php.ini, then restart Apache.");
}

$config = null;
try {
    $config = require __DIR__ . '/config.php';
    row('config.php', is_array($config), 'loaded');
} catch (Throwable $e) {
    row('config.php', false, $e->getMessage(), 'Fix the syntax error in config.php.');
}

$pdo = null;
if ($config) {
    $c = $config['db'];
    try {
        $pdo = new PDO("mysql:host={$c['host']};charset={$c['charset']}", $c['user'], $c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        row('MySQL server', true, "connected as {$c['user']}@{$c['host']}");
    } catch (Throwable $e) {
        row('MySQL server', false, $e->getMessage(), 'Start MySQL in XAMPP, and check the host, user and password in config.php.');
    }
}

if ($pdo) {
    $db = $config['db']['name'];
    $exists = (bool)$pdo->query('SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ' . $pdo->quote($db))->fetchColumn();
    row("Database `$db`", $exists, $exists ? 'exists' : 'not found', 'Run the installer: open a terminal in this folder and run  php install.php');

    if ($exists) {
        $pdo->exec('USE `' . str_replace('`', '', $db) . '`');
        $have = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        $need = ['path_nodes', 'path_edges', 'locations', 'instructors', 'subjects', 'sections', 'student_records', 'users',
                 'schedules', 'schedule_changes', 'ai_messages', 'student_classes', 'calendar_events',
                 'otp_codes', 'auth_tokens', 'staff_roster', 'staff_applications', 'audit_log', 'rate_limits'];
        $missing = array_values(array_diff($need, $have));
        row('Tables', !$missing, $missing ? 'missing: ' . implode(', ', $missing) : 'all ' . count($need) . ' present',
            'For a brand-new empty database, run php install.php. For an existing database, back up first and apply a reviewed non-destructive migration; do not delete .installed or rerun schema.sql.');

        if (in_array('users', $have, true)) {
            $cols = $pdo->query('SHOW COLUMNS FROM users')->fetchAll(PDO::FETCH_COLUMN);
            $needCols = ['mobile', 'birthday', 'address', 'student_type', 'profile_done', 'status', 'requested_role', 'email_verified_at', 'activated_at'];
            $miss = array_values(array_diff($needCols, $cols));
            row('users table is the current version', !$miss, $miss ? 'missing columns: ' . implode(', ', $miss) : 'ok',
                'The database schema is older. Back up the database and apply a reviewed non-destructive migration; do not rerun install.php or schema.sql over existing data.');
            $n = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
            $admins = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
            row('Accounts', $n > 0, "$n account(s), $admins admin(s)", 'Run the installer to create the admin account.');
        }
        if (in_array('student_records', $have, true)) {
            row('Student records', true, (int)$pdo->query('SELECT COUNT(*) FROM student_records')->fetchColumn() . ' record(s)');
        }
    }
}

$logDir = __DIR__ . '/database';
row('database/ folder is writable (for error.log)', is_writable($logDir), $logDir, 'Make the database folder writable.');
$mail = $config['mail'] ?? [];
$mailReady = ($mail['transport'] ?? 'log') === 'smtp'
    && !empty($mail['host']) && !empty($mail['port']) && !empty($mail['user'])
    && !empty($mail['pass']) && !empty($mail['from'])
    && filter_var((string)$mail['from'], FILTER_VALIDATE_EMAIL)
    && extension_loaded('openssl');
$mailDetail = ($mail['transport'] ?? 'log') === 'log'
    ? 'LOG mode only: messages are written to database/mail.log, not delivered.'
    : ($mailReady ? 'SMTP settings are present. Live delivery still needs a test message.' : 'SMTP is selected but settings are incomplete or OpenSSL is missing.');
row('Email sending configuration', $mailReady, $mailDetail, 'Create config.local.php from config.local.php.example and enter your Gmail address and Google App Password.');
row('Gemini AI key', true, !empty($config['ai']['gemini_api_key']) ? 'set' : 'not set (built-in assistant only)');
row('Argon2id password hashing', true, defined('PASSWORD_ARGON2ID') ? 'available' : 'not available, using bcrypt (also secure)');
row('Zip extension (needed for Excel/Word import)', class_exists('ZipArchive'), class_exists('ZipArchive') ? 'loaded' : 'missing', 'Enable extension=zip in php.ini, then restart Apache.');
row('install.php lock', true, file_exists($logDir . '/.installed') ? 'installed (delete install.php now)' : 'not installed yet');

$log = $logDir . '/error.log';
$tail = is_file($log) ? implode("\n", array_slice(file($log, FILE_IGNORE_NEW_LINES) ?: [], -8)) : '';
$bad = count(array_filter($rows, fn($r) => !$r[1]));
?>
<!doctype html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Setup check - NEMSU CampusNav AI</title>
<style>
  body { font: 16px/1.5 system-ui, sans-serif; max-width: 760px; margin: 5vh auto; padding: 0 16px; color: #14201a; }
  h1 { margin-bottom: 4px; }
  .sum { padding: 12px 16px; border-radius: 12px; margin: 14px 0; font-weight: 600; }
  .sum.ok { background: #dcefe6; } .sum.bad { background: #fde8e6; color: #8c1d18; }
  table { width: 100%; border-collapse: collapse; }
  td { padding: 10px 8px; border-bottom: 1px solid #ddd; vertical-align: top; }
  .ok-t { color: #1c7a58; font-weight: 700; } .bad-t { color: #b3261e; font-weight: 700; }
  small { display: block; color: #555; } pre { background: #f3f3f3; padding: 12px; border-radius: 8px; white-space: pre-wrap; }
</style>
<h1>Setup check</h1>
<p>NEMSU CampusNav AI</p>
<div class="sum <?= $bad ? 'bad' : 'ok' ?>"><?= $bad ? $bad . ' problem(s) found. Fix the red items, then reload this page.' : 'Everything looks good. You can open the app and log in.' ?></div>
<table>
<?php foreach ($rows as [$label, $ok, $detail, $fix]): ?>
  <tr>
    <td class="<?= $ok ? 'ok-t' : 'bad-t' ?>"><?= $ok ? 'OK' : 'FIX' ?></td>
    <td><?= htmlspecialchars($label) ?><small><?= htmlspecialchars($detail) ?></small>
      <?php if (!$ok && $fix): ?><small><strong>How to fix:</strong> <?= htmlspecialchars($fix) ?></small><?php endif; ?></td>
  </tr>
<?php endforeach; ?>
</table>
<?php if ($tail !== ''): ?>
  <h2>Latest errors from the app</h2>
  <pre><?= htmlspecialchars($tail) ?></pre>
<?php endif; ?>
