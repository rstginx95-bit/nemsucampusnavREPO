# NEMSU CampusNav AI (Enhanced Build)

Mobile-first PHP + MySQL campus navigation application with student/instructor accounts, schedules, campus map, calendar and AI assistant.

## Clean installation (Laragon / XAMPP)

1. Back up any existing project folder and database.
2. Copy this folder to `C:\laragon\www\nemsu-campusnav` (or your web root).
3. Configure database credentials in `config.php`.
4. Start Apache and MySQL.
5. Run `php install.php` from this project folder, or open the installer on localhost.
6. Save the one-time Developer/admin password displayed by the installer. Change it immediately after signing in through `admin-login.php`.
7. Delete or disable `install.php` after successful installation.
8. Copy `config.local.php.example` to `config.local.php` and configure mail credentials.
9. Open `check.php` and resolve any reported configuration problems.

The installer refuses to run when the configured database already contains tables. It does not reset an existing database. For an existing installation, use reviewed migrations and a backup; do not re-run `schema.sql`.

## Database files

- `database/schema.sql` creates the database tables. **It contains DROP TABLE statements and is only for a brand-new empty database.** Never import it over a live database.
- `database/seed.sql` inserts only the existing campus map starter records (path nodes, path edges and locations). It does not preload students, instructors, subjects, sections, class schedules, calendar events or staff roster records.
- `database/sample-data.sql` contains optional demonstration academic records. Import it only into a disposable test database after the schema and clean seed. It contains fictitious/example academic records and must not be used as official NEMSU data.
- `database/migrations/` contains incremental changes for existing installations. Review and back up before applying. Keep the existing `database/app.key` when updating an installation; it is intentionally not included in this distributable ZIP.

The campus coordinates and walkway graph carried over from the prototype are **not independently verified**. Survey and correct them on campus before relying on turn-by-turn pedestrian navigation.

## First account

The installer creates the initial privileged account and displays a random one-time password. The configured Developer email is set in `config.php`; verify that it matches the actual authorized administrator account before use. The account is stored with the existing `admin` database role for compatibility; access to Developer-only pages is additionally restricted by the configured Developer email.

## Login and accounts

Students and instructors have separate public sign-in pages: `student-login.php` (legacy `login.php` remains supported) and `instructor-login.php`. The public pages do not expose an Administrator option. Administrator access is separate at `admin-login.php` and is not linked from public login screens. Student sign-in accepts a registered email or Student ID; instructor sign-in accepts a registered email or Employee ID. Any valid personal email provider is accepted. Instructor applications are independently submitted, email-verified, reviewed by an administrator, and activated before instructor privileges are granted. The legacy `staff-login.php` endpoint redirects to the instructor login.

## Email

`config.php` contains safe defaults and can load a private `config.local.php` override. Copy `config.local.php.example` to `config.local.php`, set the correct `base_url` for your Laragon folder, and enter your Gmail address plus a Google App Password in the SMTP fields. Keep `transport` set to `smtp` for real delivery. The explicit `log` transport writes messages to `database/mail.log` and does not deliver email. The Developer account also uses SMTP when SMTP is selected. Use `check.php` to confirm that settings are present, then test password reset and student verification with a real inbox. SMTP credentials are not included in this ZIP and must be supplied by the project owner.

## Google Maps and AI

Configure a restricted Google Maps API key and Gemini API key using the supported configuration in `config.php` / environment. Google Maps availability, billing, enabled APIs and referrer restrictions must be checked in the Google Cloud project. The application may use its configured map fallback when Google Maps is unavailable. Google Street View imagery is only available where Google provides coverage; indoor campus imagery requires your own photographs or panoramas.

## Before real deployment

- Set production debug settings and HTTPS.
- Restrict Google API keys by website referrer and required API.
- Configure and verify SMTP.
- Change the initial Developer password and enable stronger authentication.
- Back up the database and test restoration.
- Verify campus buildings, coordinates, walkway edges and accessible routes in person.
- Populate official students, instructors, subjects, sections and schedules through authorized workflows.
- Review privacy notices, retention rules and institutional data-protection requirements.

## Account access changes

- Student, instructor and administrator sign-in screens are separate while sharing the same server-side session and password verification code.
- Students may sign in using their registered email or Student ID. Instructors may sign in using their registered email or Employee ID.
- Student and instructor registration accepts any syntactically valid email address. The mailbox must be accessible for verification and password recovery.
- Instructor role access is not self-selected: the administrator-maintained roster, invitation, approval and activation checks remain in force.
- New and changed passwords require at least 12 characters with uppercase and lowercase letters, a number and a symbol. Existing password hashes are not changed by this policy until a user changes their password.
- The Developer email allowlist defaults to the authorized address configured in `config.php`; set `CN_DEVELOPER_EMAIL` or a private local override if the actual account differs. The password is never stored in source code.

## Updating an existing installation

Back up the project and database first. Copy updated application files without replacing the live `database/` directory. Preserve the existing `database/app.key`, `.installed` marker, uploaded campus photos and database records. The distributable archive intentionally excludes runtime keys, OTP/mail logs and one-off password reset scripts. Do not run `schema.sql` or `install.php` against an existing installation.
