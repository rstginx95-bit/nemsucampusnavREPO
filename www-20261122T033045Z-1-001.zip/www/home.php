<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/locations.php';
require __DIR__ . '/includes/schedule.php';

$u      = require_login();
$now    = new DateTimeImmutable('now');
$access = has_schedule_access($u);
$rows   = $access ? user_schedule($u) : [];
$today  = classes_on_day($rows, (int)$now->format('N'));
$next   = $access ? next_class($rows, $now) : null;
$changes = $access ? recent_changes($u) : [];
$events  = upcoming_events(4);

$quick = array_slice(array_values(array_filter(all_locations(), fn($l) => in_array($l['type'], ['building', 'facility', 'office'], true))), 0, 8);

$isAdminHome = is_admin($u) && empty($u['preview']);
$isInstructor = $u['mode'] === 'instructor';
$adminStats = null;
if ($isAdminHome) {
    $one = function (string $sql, array $p = []): int { try { return (int)q($sql, $p)->fetchColumn(); } catch (Throwable $e) { return 0; } };
    $adminStats = [
        'pending' => function_exists('pending_application_count') ? pending_application_count() : 0,
        'students' => $one("SELECT COUNT(*) FROM users WHERE role='student' AND requested_role='student' AND status='approved'"),
        'instructors' => $one("SELECT COUNT(*) FROM users WHERE role IN ('instructor','staff') AND status='approved'"),
        'schedules' => $one('SELECT COUNT(*) FROM schedules'),
        'locations' => $one('SELECT COUNT(*) FROM locations'),
        'events' => $one('SELECT COUNT(*) FROM calendar_events WHERE end_date >= CURDATE()'),
    ];
}
$instructorStats = null;
if ($isInstructor) {
    $instructorStats = [
        'classes' => count($rows),
        'today' => count($today),
        'sections' => count(array_unique(array_filter(array_map(fn($r) => (string)($r['section_code'] ?? ''), $rows)))),
    ];
}

function big_room(?string $name): string
{
    if ($name && preg_match('/^Room\s+(\S+)$/i', $name, $m)) {
        return $m[1];
    }
    return '';
}

render_head('Home', 'home');
?>
<div class="page-head">
  <div>
    <h1><?= e(greeting()) ?>, <?= e(first_name($u)) ?></h1>
    <p class="muted"><?= e($now->format('l, F j')) ?><?= $isAdminHome ? ' · Administrator dashboard' : ($isInstructor ? ' · Instructor dashboard' : '') ?></p>
  </div>
</div>

<div class="home-grid">

  <div class="home-main">

    <?php if ($changes): ?>
      <section class="notice notice-warn" aria-label="Schedule updates">
        <?= icon('alert') ?>
        <div>
          <strong>Your schedule was updated</strong>
          <?php foreach ($changes as $c): ?>
            <p><?= e($c['summary']) ?></p>
          <?php endforeach; ?>
        </div>
      </section>
    <?php endif; ?>

    <?php if ($isAdminHome && $adminStats): ?>
      <section class="card">
        <div class="card-head">
          <div>
            <h2>Administrator overview</h2>
            <p class="muted">Live campus and account summary.</p>
          </div>
          <span class="pill pill-live">Live</span>
        </div>
        <div class="stat-grid">
          <a class="stat-card stat-link" href="verification.php?tab=pending"><span class="stat-ic"><?= icon('file') ?></span><span class="muted">Pending applications</span><strong><?= number_format($adminStats['pending']) ?></strong><small>Awaiting review</small></a>
          <a class="stat-card stat-link" href="verification.php?tab=students&f=approved"><span class="stat-ic"><?= icon('user') ?></span><span class="muted">Approved students</span><strong><?= number_format($adminStats['students']) ?></strong><small>Student accounts</small></a>
          <a class="stat-card stat-link" href="verification.php?tab=staff&role=instructor&f=approved"><span class="stat-ic"><?= icon('idcard') ?></span><span class="muted">Approved instructors</span><strong><?= number_format($adminStats['instructors']) ?></strong><small>Instructor accounts</small></a>
          <a class="stat-card stat-link" href="admin.php?t=schedules"><span class="stat-ic"><?= icon('calendar') ?></span><span class="muted">Class schedules</span><strong><?= number_format($adminStats['schedules']) ?></strong><small>Configured entries</small></a>
          <a class="stat-card stat-link" href="admin.php?t=locations"><span class="stat-ic"><?= icon('pin') ?></span><span class="muted">Campus locations</span><strong><?= number_format($adminStats['locations']) ?></strong><small>Mapped places</small></a>
          <a class="stat-card stat-link" href="calendar.php"><span class="stat-ic"><?= icon('cal') ?></span><span class="muted">Upcoming events</span><strong><?= number_format($adminStats['events']) ?></strong><small>NEMSU calendar</small></a>
        </div>
        <div class="btn-row">
          <a class="btn btn-primary btn-small" href="admin.php"><?= icon('shield') ?> Open Manage</a>
          <a class="btn btn-ghost btn-small" href="verification.php">Verification</a>
          <a class="btn btn-ghost btn-small" href="map.php">Campus map</a>
        </div>
      </section>

    <?php elseif ($access): ?>
      <?php if ($isInstructor && $instructorStats): ?>
        <section class="card">
          <div class="card-head">
            <div>
              <h2>Teaching overview</h2>
              <p class="muted">Your assigned classes and schedule at a glance.</p>
            </div>
            <a class="link" href="admin.php?t=schedules">Manage schedules</a>
          </div>
          <div class="stat-grid">
            <div class="stat-card"><span class="stat-ic"><?= icon('calendar') ?></span><span class="muted">Assigned classes</span><strong><?= number_format($instructorStats['classes']) ?></strong><small>Total schedule entries</small></div>
            <div class="stat-card"><span class="stat-ic"><?= icon('clock') ?></span><span class="muted">Classes today</span><strong><?= number_format($instructorStats['today']) ?></strong><small><?= e($now->format('l')) ?></small></div>
            <div class="stat-card"><span class="stat-ic"><?= icon('users') ?></span><span class="muted">Blocks/sections</span><strong><?= number_format($instructorStats['sections']) ?></strong><small>Handled by you</small></div>
          </div>
        </section>
      <?php endif; ?>

      <?php if ($next): $r = $next['row']; $big = big_room($r['room_name']); ?>
        <section class="sign sign-next" aria-labelledby="next-title">
          <div class="sign-top">
            <span class="sign-label"><?= $next['status'] === 'ongoing' ? 'Class in progress' : 'Next class' ?></span>
            <span class="sign-when"><?= e(when_phrase($next)) ?></span>
          </div>
          <div class="sign-main">
            <div class="sign-room" aria-hidden="true">
              <?php if ($big !== ''): ?><span><?= e($big) ?></span><?php else: ?><?= icon('pin') ?><?php endif; ?>
            </div>
            <div class="sign-info">
              <h2 id="next-title"><?= e($r['subject_code']) ?></h2>
              <p><?= e($r['subject_title']) ?></p>
              <p class="sign-meta"><?= e($r['start']) ?> to <?= e($r['end']) ?>
                <?= $u['mode'] === 'instructor' ? ' with ' . e($r['section_code']) : ($r['instructor_name'] ? ' with ' . e($r['instructor_name']) : '') ?></p>
            </div>
          </div>
          <?php if ($r['room_id']): ?>
            <ol class="crumbs" aria-label="Route">
              <li>You</li>
              <?php if ($r['building_name']): ?><li><?= e($r['building_name']) ?></li><?php endif; ?>
              <?php if ($r['room_floor'] !== null && $r['building_name']): ?><li><?= e(ordinal((int)$r['room_floor'])) ?> floor</li><?php endif; ?>
              <li><?= e($r['room_name']) ?></li>
            </ol>
            <a class="btn btn-sign" href="map.php?to=<?= (int)$r['room_id'] ?>"><?= icon('nav') ?> Navigate</a>
          <?php else: ?>
            <p class="sign-meta">Room to be announced.</p>
          <?php endif; ?>
        </section>
      <?php else: ?>
        <section class="card empty">
          <h2>No classes this week</h2>
          <p class="muted"><?= $isInstructor ? 'No assigned classes yet. Your schedule will appear here once the administrator assigns it.' : 'Nothing is scheduled for you yet. Check again after your block is assigned.' ?></p>
        </section>
      <?php endif; ?>

      <section class="card" aria-labelledby="today-title">
        <div class="card-head">
          <h2 id="today-title">Today's schedule</h2>
          <a class="link" href="schedule.php">Full week</a>
        </div>
        <?php if (!$today): ?>
          <p class="muted">No classes today.</p>
        <?php else: ?>
          <ul class="timeline">
            <?php foreach ($today as $r): $state = class_state($r, $now); ?>
              <li class="tl-item tl-<?= e($state) ?>">
                <time><?= e($r['start']) ?></time>
                <a class="tl-body" href="<?= $r['room_id'] ? 'map.php?to=' . (int)$r['room_id'] : 'schedule.php' ?>">
                  <strong><?= e($r['subject_code']) ?></strong>
                  <span><?= e($r['place_short']) ?></span>
                </a>
                <?php if ($state === 'now'): ?><span class="pill pill-live">Now</span><?php elseif ($state === 'done'): ?><span class="pill">Done</span><?php endif; ?>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </section>

    <?php elseif ($u['mode'] === 'guest'): ?>
      <section class="card welcome">
        <h2><?= ($u['student_type'] ?? '') === 'transferee' ? 'Welcome, transferee' : 'Find your way around NEMSU' ?></h2>
        <p>You can use the map and the AI assistant right now. Ask where the Registrar, the Cashier or the Library is, and you will get a route.</p>
        <div class="btn-row">
          <a class="btn btn-primary" href="map.php"><?= icon('map') ?> Open the map</a>
          <a class="btn btn-ghost" href="ai.php"><?= icon('ai') ?> Ask the AI</a>
        </div>
      </section>
      <section class="card unlock" id="enrolled">
        <div class="unlock-icon"><?= icon('lock') ?></div>
        <div>
          <h2>Already enrolled?</h2>
          <p class="muted">Add your Student ID to confirm you are a NEMSU student. This unlocks your subjects, instructors, rooms and class schedule.</p>
          <a class="btn btn-primary" href="settings.php#verify"><?= icon('idcard') ?> Add my Student ID</a>
        </div>
      </section>

    <?php else: ?>
      <section class="card welcome">
        <h2>Administrator</h2>
        <p>Manage schedules, student records, the calendar and the campus map.</p>
        <div class="btn-row">
          <a class="btn btn-primary" href="admin.php"><?= icon('shield') ?> Open Manage</a>
          <a class="btn btn-ghost" href="map.php"><?= icon('map') ?> View the map</a>
        </div>
      </section>
    <?php endif; ?>
  </div>
  <div class="home-side">
    <section class="card" aria-labelledby="quick-title">
      <div class="card-head"><h2 id="quick-title">Quick navigation</h2><a class="link" href="map.php">Map</a></div>
      <div class="chips">
        <?php foreach ($quick as $l): ?>
          <a class="chip" href="map.php?to=<?= (int)$l['id'] ?>"><?= icon('pin') ?> <?= e($l['name']) ?></a>
        <?php endforeach; ?>
      </div>
    </section>

    <?php if (is_staff($u)): ?>
      <section class="card">
        <div class="card-head"><h2><?= $isAdminHome ? 'Quick actions' : 'Instructor tools' ?></h2></div>
        <p class="muted"><?= $isAdminHome ? 'Jump to the most common administrator tasks.' : 'View your assigned schedules and class rosters. Records are managed by the administrator.' ?></p>
        <div class="btn-row">
          <a class="btn btn-primary btn-small" href="admin.php"><?= icon('shield') ?> <?= $isAdminHome ? 'Open Manage' : 'My Schedules' ?></a>
          <?php if ($isAdminHome): ?><a class="btn btn-ghost btn-small" href="verification.php">Verification</a><?php endif; ?>
          <a class="btn btn-ghost btn-small" href="calendar.php">Calendar</a>
        </div>
      </section>
    <?php endif; ?>

    <section class="card" aria-labelledby="events-title">
      <div class="card-head"><h2 id="events-title">NEMSU calendar</h2><a class="link" href="calendar.php">Open</a></div>
      <?php if (!$events): ?>
        <p class="muted">No upcoming dates yet.</p>
      <?php else: ?>
        <ul class="event-list">
          <?php foreach ($events as $ev): ?>
            <li class="cat-<?= e($ev['category']) ?>"><strong><?= e($ev['title']) ?></strong><span><?= e(event_range_label($ev)) ?></span></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </section>

    <section class="card ask" aria-labelledby="ask-title">
      <div class="card-head"><h2 id="ask-title">AI assistant</h2></div>
      <p class="muted">Ask me about your schedule or campus location.</p>
      <form action="ai.php" method="get" class="ask-form">
        <label class="sr-only" for="home-q">Your question</label>
        <input id="home-q" type="text" name="q" placeholder="<?= $access ? 'Where is my next class?' : 'Where is the Registrar?' ?>" autocomplete="off">
        <button class="btn btn-primary" type="submit">Ask AI</button>
      </form>
    </section>
  </div>
</div>
<?php render_foot('home'); ?>
