<?php

$config = [
    'db' => [
        'host' => getenv('CN_DB_HOST') ?: '127.0.0.1',
        'name' => getenv('CN_DB_NAME') ?: 'nemsu_campusnav',
        'user' => getenv('CN_DB_USER') ?: 'root',
        'pass' => getenv('CN_DB_PASS') ?: '',
        'charset' => 'utf8mb4'
    ],

    'app' => [
        'name' => 'NEMSU CampusNav AI',
        'timezone' => 'Asia/Manila',
        'debug' => getenv('CN_ENV') !== 'production',
        'email_domain' => 'nemsu.edu.ph',
        'base_url' => getenv('CN_BASE_URL') ?: ''
    ],

    'security' => [
        'otp_ttl' => 600,
        'otp_max_attempts' => 5,
        'activation_ttl_hours' => 48,
        'reset_ttl_minutes' => 30,
        'staff_idle_minutes' => 30,
        'reauth_minutes' => 10,
        'staff_auto_approve' => false, // every instructor application requires explicit administrator approval
        // The existing first-admin account is the designated Developer until a dedicated role migration is approved.
        'developer_email' => strtolower(getenv('CN_DEVELOPER_EMAIL') ?: 'smquezada@nemsu.edu.ph'),
        'require_https' => getenv('CN_ENV') === 'production'
    ],

    'mail' => [
        'transport' => 'log',

        // SMTP is used for all recipients, including the Developer account.
        'host' => getenv('CN_SMTP_HOST') ?: 'smtp.gmail.com',
        'port' => (int)(getenv('CN_SMTP_PORT') ?: 587),
        'secure' => getenv('CN_SMTP_SECURE') ?: 'tls',

        'user' => getenv('CN_SMTP_USER') ?: '',
        'pass' => getenv('CN_SMTP_PASS') ?: '',

        'from' => getenv('CN_MAIL_FROM') ?: '',
        'from_name' => 'NEMSU CampusNav AI'
    ],

    'campus' => [
        'lat' => 8.5389,
        'lng' => 126.1118,
        'max_gps_distance' => 1500,
        'walking_speed' => 80
    ],

    'maps' => [
        'google_key' => getenv('GOOGLE_MAPS_KEY') ?: ''
    ],

    'ai' => [
        'gemini_api_key' => getenv('GEMINI_API_KEY') ?: '',
        'model' => 'gemini-2.5-flash'
    ]
];

// Optional private settings for Laragon/XAMPP. Never place real credentials in the ZIP.
$localConfig = __DIR__ . '/config.local.php';
if (is_file($localConfig)) {
    $overrides = require $localConfig;
    if (is_array($overrides)) {
        $config = array_replace_recursive($config, $overrides);
    }
}

return $config;
