<?php
declare(strict_types=1);
$login_role = 'instructor';
require __DIR__ . '/includes/role_login.php';
