# NEMSU CampusNav AI — authentication and access notes

## Public login experience
- Student login is a dedicated page: `student-login.php` (legacy `login.php` remains supported).
- Instructor login is a separate page: `instructor-login.php`.
- Student and instructor login pages have no account-type switching controls. Each page is dedicated to its own role.
- Administrator login remains a separate direct URL: `admin-login.php`; it is not linked from public login screens.
- Instructor application has a dedicated route: `instructor-register.php`, which opens the instructor-only application form.

## Account rules
- Student registration accepts any syntactically valid email address (including Gmail, Yahoo and Outlook); no NEMSU email domain is enforced.
- Student login accepts registered email or Student ID.
- Instructor application accepts any valid personal email address and requires email OTP verification.
- Instructor applicants begin with no instructor privileges. Applications remain pending for administrator review; only an administrator approval and subsequent activation grants instructor access.
- Instructor login accepts registered email or Employee ID and only approved, activated instructors can enter instructor features.
- Successful instructor sign-ins are audited and trigger an administrator notification. Student sign-ins do not trigger these notifications. Actual delivery requires working SMTP settings.
- New and changed passwords require 12+ characters with uppercase, lowercase, number and symbol.

## Administrator account
- The configured Developer email defaults to `smquezada@nemsu.edu.ph`.
- The administrator password is deliberately not embedded in source code or this ZIP. The existing MySQL account must have a matching email and a valid password hash.
- A fresh installation generates a random one-time administrator password and displays it once in the installer output. Existing databases must not be reinstalled or overwritten.

## Preserved UI
- Existing CSS, JavaScript interactions, dashboard pages, map implementation and theme are retained. The authentication footer and links were adjusted to remove the public Administrator choice and distinguish Student and Instructor destinations.

## Admin account setup update
- Added `create-admin.php` with exactly three fields: email, password, and confirm password.
- The setup page creates only the first administrator and automatically disables itself once any admin account exists.
- Admin login remains a separate email-and-password page; student and instructor login/registration paths remain separate.
- The existing admin password repair script now accepts `CN_ADMIN_EMAIL` to target an existing admin whose email differs from `security.developer_email`.
- To reset the existing admin shown in phpMyAdmin, run from the project directory in Laragon Terminal:
  `set CN_ADMIN_EMAIL=squezada@nemsu.edu.ph`
  `php reset-admin-password.php`
  Then sign in at `admin-login.php`. Change the password in the script/environment before running if you do not want the default.


## Local Admin recovery update
- `create-admin.php` now permits creation of an additional Admin only when accessed from the local computer (loopback request: `127.0.0.1` or `::1`) if an Admin already exists.
- This supports creating a replacement Admin in a local Laragon development environment when the previous Admin password is unavailable.
- The form still requests only email, password, and confirm password. Existing users and records are not deleted or modified.
- Public/non-local requests remain blocked when an Admin already exists. Do not expose this local recovery setup page on a public production server.
