<?php
declare(strict_types=1);

function name_words(string $s): string
{
    $s = mb_strtolower($s, 'UTF-8');
    $s = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $s) ?? '';
    return ' ' . trim($s) . ' ';
}

/**
 * Links a student account to an official student record.
 * The Student ID must exist, must not belong to another account, and the record's
 * first and last name must appear in the name the person entered. Returns true on success.
 */
function verify_student_id(array $u, string $studentNo, array &$errors): bool
{
    $studentNo = strtoupper(trim($studentNo));
    if (!rate_ok('verify', 6)) {
        $errors[] = 'Too many attempts. Wait a few minutes, then try again.';
        return false;
    }
    if ($studentNo === '' || !preg_match('/^[A-Z0-9\-]{4,30}$/', $studentNo)) {
        $errors[] = 'Enter your Student ID, for example 24-00453.';
        return false;
    }
    $rec = q('SELECT id, last_name, first_name FROM student_records WHERE student_no = ?', [$studentNo])->fetch();
    $generic = 'We could not match that Student ID to your name. Check the ID and the name in your profile, or ask the Registrar or your instructor to add you.';
    if (!$rec) {
        $errors[] = $generic;
        return false;
    }
    $full  = name_words($u['full_name']);
    $last  = trim(name_words($rec['last_name']));
    $first = explode(' ', trim(name_words($rec['first_name'])))[0] ?? '';
    if ($last === '' || !str_contains($full, ' ' . $last . ' ') || ($first !== '' && !str_contains($full, ' ' . $first . ' '))) {
        $errors[] = $generic;
        return false;
    }
    if (q('SELECT 1 FROM users WHERE student_record_id = ? AND id <> ?', [$rec['id'], $u['id']])->fetch()) {
        $errors[] = 'That Student ID is already linked to another account. Contact the Registrar if this is a mistake.';
        return false;
    }
    q("UPDATE users SET student_record_id = ?, status = IF(email_verified_at IS NOT NULL AND role = 'student', 'approved', status) WHERE id = ? AND role = 'student'",
        [$rec['id'], $u['id']]);
    audit('student_verified', 'user', (int)$u['id'], 'student record linked', (int)$u['id']);
    return true;
}

/**
 * Runs right after a student's email code is accepted.
 * Freshmen and transferees without an ID get map + AI. Old students must match an official record first.
 */
function student_finish_registration(int $userId): string
{
    $u = q('SELECT * FROM users WHERE id = ?', [$userId])->fetch();
    if (!$u || $u['role'] !== 'student' || $u['requested_role'] !== 'student') {
        return 'pending_email';
    }
    $claimed = (string)($u['claimed_student_no'] ?? '');
    if ($claimed !== '' && $u['student_type'] !== 'freshman') {
        $errors = [];
        if (verify_student_id($u, $claimed, $errors)) {
            return 'approved';
        }
    }
    $status = $u['student_type'] === 'old' ? 'pending_identity' : 'approved';
    q('UPDATE users SET status = ? WHERE id = ?', [$status, $userId]);
    return $status;
}

/** Validates the personal-information fields shared by onboarding and the account page. */
function collect_profile(array $post, array &$errors): array
{
    $name = trim(preg_replace('/\s+/', ' ', (string)($post['full_name'] ?? '')));
    $birthday = trim((string)($post['birthday'] ?? ''));
    $mobileRaw = trim((string)($post['mobile'] ?? ''));
    $address = trim(preg_replace('/\s+/', ' ', (string)($post['address'] ?? '')));

    if (mb_strlen($name) < 3 || mb_strlen($name) > 120 || !str_contains($name, ' ')) {
        $errors[] = 'Enter your full name (first name and last name).';
    }
    $age = null;
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $birthday);
    if (!$d || $d->format('Y-m-d') !== $birthday) {
        $errors[] = 'Enter your birthday.';
    } else {
        $age = age_from_birthday($birthday);
        if ($age === null || $age < 14 || $age > 100) {
            $errors[] = 'Check your birthday. It does not look right.';
        }
    }
    if (mb_strlen($address) < 8 || mb_strlen($address) > 250) {
        $errors[] = 'Enter your address (barangay, city or municipality, and province).';
    }
    $mobile = null;
    if ($mobileRaw !== '') {
        $mobile = normalize_mobile($mobileRaw);
        if (!$mobile) {
            $errors[] = 'Enter a Philippine mobile number like 0917 123 4567.';
        }
    }
    return ['full_name' => $name, 'birthday' => $birthday, 'address' => $address, 'mobile' => $mobile];
}
