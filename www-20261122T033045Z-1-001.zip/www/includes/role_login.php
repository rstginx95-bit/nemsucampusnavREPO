<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';
require __DIR__ . '/layout.php';
require __DIR__ . '/auth_page.php';
require __DIR__ . '/mailer.php';

$role = $login_role ?? 'student';
$labels = [
    'student' => ['title' => 'Student log in', 'heading' => 'Student Login', 'hint' => 'Sign in with your registered email or Student ID.', 'placeholder' => 'Email address or Student ID', 'fallback' => 'home.php'],
    'instructor' => ['title' => 'Instructor log in', 'heading' => 'Instructor Login', 'hint' => 'Sign in with your registered email or Employee ID.', 'placeholder' => 'Email address or Employee ID', 'fallback' => 'admin.php'],
    'admin' => ['title' => 'Administrator log in', 'heading' => 'Administrator Login', 'hint' => 'Authorized administrator accounts only.', 'placeholder' => 'Administrator email', 'fallback' => 'developer.php'],
];
if (!isset($labels[$role])) { http_response_code(404); exit('Login page not found.'); }
$meta = $labels[$role];

function role_login_find_user(string $role, string $identifier): ?array
{
    $identifier = trim($identifier);
    if ($role === 'admin') {
        $row = q("SELECT * FROM users WHERE LOWER(email) = LOWER(?) AND role = 'admin' LIMIT 1", [$identifier])->fetch();
        return $row ?: null;
    }
    if (str_contains($identifier, '@')) {
        $row = q('SELECT * FROM users WHERE LOWER(email) = LOWER(?) LIMIT 1', [$identifier])->fetch();
        if ($row && (($role === 'student' && $row['requested_role'] === 'student') || ($role === 'instructor' && in_array($row['requested_role'], ['instructor','staff'], true)))) return $row;
        return null;
    }
    if ($role === 'student') {
        $row = q('SELECT u.* FROM users u LEFT JOIN student_records sr ON sr.id = u.student_record_id WHERE u.claimed_student_no = ? OR sr.student_no = ? LIMIT 1', [strtoupper($identifier), strtoupper($identifier)])->fetch();
        return $row && $row['requested_role'] === 'student' ? $row : null;
    }
    $row = q("SELECT DISTINCT u.* FROM users u LEFT JOIN instructors i ON i.id = u.instructor_id LEFT JOIN staff_applications sa ON sa.user_id = u.id WHERE i.employee_no = ? OR sa.employee_no = ? LIMIT 1", [strtoupper($identifier), strtoupper($identifier)])->fetch();
    return $row && in_array($row['requested_role'], ['instructor','staff'], true) ? $row : null;
}

function role_login_destination(array $user, string $role): string
{
    if ($role === 'admin') {
        return 'admin.php';
    }
    if ($role === 'instructor') {
        if (empty($user['email_verified_at'])) return 'verify-email.php';
        if (in_array($user['status'], ['pending_admin','pending_identity','pending_email'], true) || !empty($user['requested_role']) && $user['requested_role'] === 'instructor' && ($user['role'] ?? '') !== 'instructor') return 'status.php';
        if (($user['role'] ?? '') !== 'instructor' || $user['status'] !== 'approved' || empty($user['activated_at'])) return 'status.php';
        return empty($user['profile_done']) ? 'onboarding.php' : 'admin.php';
    }
    if (($user['role'] ?? '') !== 'student') return 'status.php';
    if (empty($user['email_verified_at'])) return 'verify-email.php';
    if (empty($user['profile_done'])) return 'onboarding.php';
    if (in_array($user['status'], ['pending_admin','pending_identity','pending_email'], true)) return 'status.php';
    return 'home.php';
}

if ($u = current_user()) {
    redirect(role_login_destination($u, $role));
}
$errors = [];
$oldId = '';
$generic = 'The email or ID and password do not match this login type, or the account is not active.';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $oldId = trim((string)($_POST['identifier'] ?? ''));
    $pass = (string)($_POST['password'] ?? '');
    if (!rate_ok_for('role_login_' . $role, $oldId, 8, 900)) {
        $errors[] = 'Too many attempts. Wait 15 minutes and try again.';
        audit('login_rate_limited', 'user', null, $role . ' login');
    } else {
        $user = role_login_find_user($role, $oldId);
        $passOk = $user && password_verify($pass, (string)$user['password_hash']);
        $validRole = $role === 'admin'
            ? (($user['role'] ?? '') === 'admin' && ($user['status'] ?? '') === 'approved')
            : ($role === 'student'
                ? (($user['requested_role'] ?? '') === 'student' && ($user['role'] ?? '') === 'student')
                : (in_array(($user['requested_role'] ?? ''), ['instructor','staff'], true)));
        if ($passOk && $validRole && !in_array($user['status'], ['suspended','rejected'], true)) {
            if ($role === 'instructor' && (($user['role'] ?? '') !== 'instructor' || $user['status'] !== 'approved' || empty($user['activated_at']))) {
                login_user((int)$user['id']);
                redirect('status.php');
            }
            if ($role === 'student' && empty($user['email_verified_at'])) {
                login_user((int)$user['id']);
                redirect('verify-email.php');
            }
            if (password_needs_rehash($user['password_hash'], defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT)) {
                q('UPDATE users SET password_hash = ? WHERE id = ?', [hash_password($pass), $user['id']]);
            }
            login_user((int)$user['id']);
            if ($role === 'instructor') {
                audit('instructor_login', 'user', (int)$user['id'], 'Successful instructor sign-in', (int)$user['id']);
                $staffApp = q('SELECT employee_no, department FROM staff_applications WHERE user_id = ?', [(int)$user['id']])->fetch() ?: [];
                notify_admins('Instructor signed in to NEMSU CampusNav',
                    'An instructor has signed in successfully.\n\nName: ' . ($user['full_name'] ?? 'Not provided') .
                    '\nEmail: ' . ($user['email'] ?? '') .
                    '\nEmployee ID: ' . ($staffApp['employee_no'] ?? 'Not provided') .
                    '\nDepartment: ' . ($staffApp['department'] ?? 'Not provided') .
                    '\nTime: ' . date('Y-m-d H:i:s T') .
                    '\nAdmin dashboard: ' . app_url('admin.php'));
            }
            redirect(role_login_destination($user, $role));
        }
        audit('login_failed', 'user', $user ? (int)$user['id'] : null, $role . ' bad credentials or inactive account');
        $errors[] = $generic;
    }
}

auth_start($meta['title'], $role === 'instructor');
?>
<section class="holo card enter" id="card" aria-labelledby="t">
  <h1 id="t"><?= e($meta['heading']) ?></h1>
  <p class="muted"><?= e($meta['hint']) ?></p>
  <?php auth_errors($errors); ?>
  <form method="post" class="form" autocomplete="on">
    <?= csrf_field() ?>
    <label class="field"><?= $role === 'admin' ? 'Administrator email' : 'Email or ID' ?>
      <input type="text" name="identifier" value="<?= e($oldId) ?>" autocomplete="username" placeholder="<?= e($meta['placeholder']) ?>" required>
    </label>
    <label class="field">Password
      <input type="password" name="password" autocomplete="current-password" required>
    </label>
    <button class="btn btn-primary" type="submit">Log in</button>
    <a class="hu center-link" href="<?= e(app_url('forgot-password.php')) ?>">Forgot password?</a>
  </form>
  <?php if ($role === 'student'): ?>
    <div class="or">new student?</div>
    <a class="btn btn-ghost" href="<?= e(app_url('register.php')) ?>">Create a student account</a>
  <?php elseif ($role === 'instructor'): ?>
    <div class="notice notice-warn"><div>Instructor accounts must be approved by the administrator before instructor features are available.</div></div>
    <a class="btn btn-ghost" href="<?= e(app_url('instructor-register.php')) ?>">Apply for instructor access</a>
  <?php endif; ?>
  <?php if ($role === 'admin'): ?>
    <a class="btn btn-ghost" href="<?= e(app_url('create-admin.php')) ?>">Create Admin Account</a>
    <p class="foot muted">Restricted administrator access. If an Admin already exists, account replacement is available only from the local Laragon computer.</p>
  <?php endif; ?>
  <?php render_safety_notes(false); ?>
</section>
<div class="chips enter" aria-hidden="true"><div class="chip"><?= icon('map') ?>Map</div><div class="chip"><?= icon('calendar') ?>Schedule</div><div class="chip"><?= icon('ai') ?>Ask AI</div></div>
<?php auth_end(); ?>
