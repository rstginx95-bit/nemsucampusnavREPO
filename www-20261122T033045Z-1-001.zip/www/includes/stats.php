<?php
declare(strict_types=1);

/**
 * Administrator statistics. Every number comes from a live query on the existing tables
 * (users, locations, subjects, sections, schedules, path_edges, audit_log, login_events).
 * Nothing here is cached, sampled or hardcoded. Call only from a page that ran require_admin().
 * No password hashes, tokens or codes are ever selected.
 */

function stats_ranges(): array
{
    return ['today' => 'Today', '7d' => 'Last 7 days', '30d' => 'Last 30 days', '12m' => 'Last 12 months', 'all' => 'All time'];
}

/** Query helpers: a missing table (migration not applied yet) yields empty data instead of an error page. */
function st_all(string $sql, array $p = []): array
{
    try { return q($sql, $p)->fetchAll(); } catch (Throwable $e) { return []; }
}
function st_row(string $sql, array $p = []): array
{
    try { return q($sql, $p)->fetch() ?: []; } catch (Throwable $e) { return []; }
}

function stats_range(string $key): array
{
    if (!isset(stats_ranges()[$key])) $key = '30d';
    $now = time();
    switch ($key) {
        case 'today': $from = strtotime('today', $now); $unit = 'hour'; break;
        case '7d':    $from = strtotime('today -6 days', $now); $unit = 'day'; break;
        case '30d':   $from = strtotime('today -29 days', $now); $unit = 'day'; break;
        case '12m':   $from = strtotime('first day of this month 00:00:00 -11 months', $now); $unit = 'month'; break;
        default:      $from = null; $unit = 'month';
    }
    return ['key' => $key, 'label' => stats_ranges()[$key], 'from' => $from, 'unit' => $unit, 'now' => $now];
}

/** Ordered period keys + labels between $from and now, so empty days still show as zero. */
function stats_periods(string $unit, ?int $from, int $now): array
{
    $keys = []; $labels = [];
    if ($unit === 'hour') {
        for ($t = $from; $t <= $now; $t += 3600) { $keys[] = date('Y-m-d H', $t); $labels[] = date('g A', $t); }
    } elseif ($unit === 'day') {
        for ($t = $from; $t <= $now; $t = strtotime('+1 day', $t)) { $keys[] = date('Y-m-d', $t); $labels[] = date('M j', $t); }
    } else {
        $t = strtotime(date('Y-m-01', (int)$from));
        while ($t <= $now) { $keys[] = date('Y-m', $t); $labels[] = date('M Y', $t); $t = strtotime('+1 month', $t); }
    }
    return [$keys, $labels];
}

function stats_fmt(string $unit): string
{
    return ['hour' => '%Y-%m-%d %H', 'day' => '%Y-%m-%d', 'month' => '%Y-%m'][$unit];
}

/** Turns grouped rows into one value array per series, aligned to $keys. */
function stats_fill(array $rows, array $keys, array $groups): array
{
    $out = [];
    foreach ($groups as $g) $out[$g] = array_fill(0, count($keys), 0);
    $idx = array_flip($keys);
    foreach ($rows as $r) {
        if (isset($idx[$r['p']], $out[$r['g']])) $out[$r['g']][$idx[$r['p']]] = (int)$r['c'];
    }
    return $out;
}

function stats_audit(array $actions, ?string $from, int $limit = 8): array
{
    $in = implode(',', array_fill(0, count($actions), '?'));
    $p = $actions;
    $sql = "SELECT l.created_at, l.action, l.detail, a.full_name AS actor, t.full_name AS target
              FROM audit_log l LEFT JOIN users a ON a.id = l.actor_id LEFT JOIN users t ON (l.target_type = 'user' AND t.id = l.target_id)
             WHERE l.action IN ($in)";
    if ($from) { $sql .= ' AND l.created_at >= ?'; $p[] = $from; }
    return st_all($sql . ' ORDER BY l.id DESC LIMIT ' . (int)$limit, $p);
}

function stats_collect(string $rangeKey): array
{
    $rg = stats_range($rangeKey);
    $now = $rg['now'];
    $fromSql = $rg['from'] ? date('Y-m-d H:i:s', $rg['from']) : null;
    $S = ['range' => $rg['key'], 'rangeLabel' => $rg['label'], 'unit' => $rg['unit']];

    // ---- accounts (current state) ----
    $a = st_row("SELECT COUNT(*) AS total_users,
        COALESCE(SUM(role = 'student' AND requested_role = 'student'), 0) AS students_total,
        COALESCE(SUM(role = 'student' AND requested_role = 'student' AND status = 'approved'), 0) AS students_approved,
        COALESCE(SUM(role = 'student' AND requested_role = 'student' AND status IN ('pending_email','pending_identity')), 0) AS students_pending,
        COALESCE(SUM(role = 'student' AND requested_role = 'student' AND status = 'rejected'), 0) AS students_rejected,
        COALESCE(SUM(role IN ('instructor','staff')), 0) AS instructors_total,
        COALESCE(SUM(role IN ('instructor','staff') AND status = 'approved'), 0) AS instructors_approved,
        COALESCE(SUM(requested_role IN ('instructor','staff') AND status = 'rejected'), 0) AS instructors_rejected,
        COALESCE(SUM(status = 'approved'), 0) AS active_accounts,
        COALESCE(SUM(status = 'suspended'), 0) AS deactivated_accounts
        FROM users");
    $S['acc'] = array_merge(array_fill_keys(['total_users', 'students_total', 'students_approved', 'students_pending', 'students_rejected', 'instructors_total',
        'instructors_approved', 'instructors_rejected', 'active_accounts', 'deactivated_accounts'], 0), array_map('intval', $a)) + ['instructors_pending' => pending_application_count()];

    // ---- campus ----
    $c = st_row("SELECT COUNT(*) AS total, COALESCE(SUM(type = 'building'), 0) AS buildings, COALESCE(SUM(type = 'room'), 0) AS rooms,
                        COALESCE(SUM(type = 'lab'), 0) AS labs, COALESCE(SUM(type = 'office'), 0) AS offices, COALESCE(SUM(type = 'facility'), 0) AS facilities
                   FROM locations");
    $S['campus'] = array_merge(array_fill_keys(['total', 'buildings', 'rooms', 'labs', 'offices', 'facilities'], 0), array_map('intval', $c)) + [
        'subjects'  => (int)(st_row('SELECT COUNT(*) AS n FROM subjects')['n'] ?? 0),
        'sections'  => (int)(st_row('SELECT COUNT(*) AS n FROM sections')['n'] ?? 0),
        'schedules' => (int)(st_row('SELECT COUNT(*) AS n FROM schedules')['n'] ?? 0),
        'routes'    => (int)(st_row('SELECT COUNT(*) AS n FROM path_edges')['n'] ?? 0),
        'points'    => (int)(st_row('SELECT COUNT(*) AS n FROM path_nodes')['n'] ?? 0),
    ];

    // ---- sign-ins ----
    $today = date('Y-m-d 00:00:00', $now);
    $l = st_row("SELECT COUNT(*) AS total, COALESCE(SUM(role = 'student'), 0) AS student, COALESCE(SUM(role IN ('instructor','staff')), 0) AS instructor,
                        COALESCE(SUM(role = 'admin'), 0) AS admin FROM login_events WHERE created_at >= ?", [$today]);
    $S['logins'] = array_merge(['total' => 0, 'student' => 0, 'instructor' => 0, 'admin' => 0], array_map('intval', $l)) + [
        'active7'  => (int)(st_row('SELECT COUNT(*) AS n FROM users WHERE last_login >= ?', [date('Y-m-d H:i:s', $now - 7 * 86400)])['n'] ?? 0),
        'active30' => (int)(st_row('SELECT COUNT(*) AS n FROM users WHERE last_login >= ?', [date('Y-m-d H:i:s', $now - 30 * 86400)])['n'] ?? 0),
        'inRange'  => (int)(st_row('SELECT COUNT(*) AS n FROM login_events' . ($fromSql ? ' WHERE created_at >= ?' : ''), $fromSql ? [$fromSql] : [])['n'] ?? 0),
    ];

    // ---- period-filtered figures ----
    $whereFrom = $fromSql ? ' AND created_at >= ?' : '';
    $pf = $fromSql ? [$fromSql] : [];
    $S['period'] = [
        'registrations' => (int)(st_row("SELECT COUNT(*) AS n FROM users WHERE role <> 'admin'" . $whereFrom, $pf)['n'] ?? 0),
        'approvals'     => (int)(st_row("SELECT COUNT(*) AS n FROM users WHERE role <> 'admin' AND approved_at IS NOT NULL" . ($fromSql ? ' AND approved_at >= ?' : ''), $pf)['n'] ?? 0),
    ];

    // ---- chart data ----
    $fmt = stats_fmt($rg['unit']);
    $first = st_row("SELECT MIN(created_at) AS d FROM users WHERE role <> 'admin'")['d'] ?? null;
    $from = $rg['from'] ?? ($first ? strtotime((string)$first) : strtotime('first day of this month', $now));
    if ($rg['key'] === 'all') $from = max($from, strtotime('first day of this month 00:00:00 -59 months', $now));   // cap at 60 months
    [$keys, $labels] = stats_periods($rg['unit'], $from, $now);
    $lo = ($rg['key'] === 'all') ? date('Y-m-d H:i:s', $from) : $fromSql;
    $bind = $lo ? [$lo] : [];
    $cond = $lo ? ' AND created_at >= ?' : '';

    $reg = stats_fill(st_all("SELECT DATE_FORMAT(created_at, '$fmt') AS p, IF(requested_role = 'student', 'student', 'instructor') AS g, COUNT(*) AS c
                                FROM users WHERE role <> 'admin'$cond GROUP BY p, g", $bind), $keys, ['student', 'instructor']);
    $log = stats_fill(st_all("SELECT DATE_FORMAT(created_at, '$fmt') AS p, CASE WHEN role = 'student' THEN 'student' WHEN role = 'admin' THEN 'admin' ELSE 'instructor' END AS g, COUNT(*) AS c
                                FROM login_events WHERE 1 = 1$cond GROUP BY p, g", $bind), $keys, ['student', 'instructor', 'admin']);

    // accounts created in the selected period, by type and by status
    $t = st_row("SELECT COALESCE(SUM(requested_role = 'student'), 0) AS students, COALESCE(SUM(requested_role <> 'student'), 0) AS instructors,
                        COALESCE(SUM(status = 'approved'), 0) AS approved, COALESCE(SUM(status IN ('pending_email','pending_identity','pending_admin')), 0) AS pending,
                        COALESCE(SUM(status = 'rejected'), 0) AS rejected, COALESCE(SUM(status = 'suspended'), 0) AS deactivated
                   FROM users WHERE role <> 'admin'$cond", $bind);

    // monthly growth: cumulative accounts, always by month
    $gFrom = $rg['key'] === 'all' ? $from : strtotime('first day of this month 00:00:00 -11 months', $now);
    [$gKeys, $gLabels] = stats_periods('month', $gFrom, $now);
    $gBase = (int)(st_row("SELECT COUNT(*) AS n FROM users WHERE role <> 'admin' AND created_at < ?", [date('Y-m-d H:i:s', $gFrom)])['n'] ?? 0);
    $gRows = stats_fill(st_all("SELECT DATE_FORMAT(created_at, '%Y-%m') AS p, 'all' AS g, COUNT(*) AS c FROM users WHERE role <> 'admin' AND created_at >= ? GROUP BY p", [date('Y-m-d H:i:s', $gFrom)]), $gKeys, ['all'])['all'];
    $cum = []; $run = $gBase;
    foreach ($gRows as $n) { $run += $n; $cum[] = $run; }

    $S['charts'] = [
        'labels' => $labels, 'registrations' => $reg, 'logins' => $log,
        'byType' => ['labels' => ['Students', 'Instructors'], 'values' => [(int)($t['students'] ?? 0), (int)($t['instructors'] ?? 0)]],
        'byStatus' => ['labels' => ['Approved', 'Pending', 'Rejected', 'Deactivated'],
                       'values' => [(int)($t['approved'] ?? 0), (int)($t['pending'] ?? 0), (int)($t['rejected'] ?? 0), (int)($t['deactivated'] ?? 0)]],
        'growth' => ['labels' => $gLabels, 'values' => $cum],
    ];

    // ---- recent activities (selected period, newest first) ----
    $rec = fn(string $cond2) => st_all("SELECT full_name, email, status, created_at FROM users WHERE $cond2$whereFrom ORDER BY id DESC LIMIT 8", $pf);
    $S['recent'] = [
        'students'    => $rec("role <> 'admin' AND requested_role = 'student'"),
        'instructors' => $rec("role <> 'admin' AND requested_role <> 'student'"),
        'approved'    => stats_audit(['role_granted', 'account_approved', 'account_activated'], $fromSql),
        'deactivated' => stats_audit(['account_deactivated', 'access_revoked', 'roster_deactivated'], $fromSql),
        'passwords'   => stats_audit(['password_updated', 'password_reset', 'password_changed'], $fromSql),
        'deleted'     => stats_audit(['record_deleted', 'audit_deleted'], $fromSql),
        'admin'       => st_all("SELECT l.created_at, l.action, l.detail, a.full_name AS actor, t.full_name AS target
                                   FROM audit_log l JOIN users a ON a.id = l.actor_id AND a.role = 'admin'
                                   LEFT JOIN users t ON (l.target_type = 'user' AND t.id = l.target_id)
                                  WHERE l.action NOT IN ('reauth_ok','reauth_failed','app_doc_viewed')" . ($fromSql ? ' AND l.created_at >= ?' : '') . '
                                  ORDER BY l.id DESC LIMIT 12', $pf),
    ];
    return $S;
}

function st_action_label(string $a): string
{
    static $m = ['role_granted' => 'Instructor approved', 'account_approved' => 'Account approved', 'account_activated' => 'Account activated',
        'account_deactivated' => 'Account deactivated', 'access_revoked' => 'Access revoked', 'roster_deactivated' => 'Roster record deactivated',
        'roster_activated' => 'Roster record activated', 'password_updated' => 'Password updated by admin', 'password_reset' => 'Password reset',
        'password_changed' => 'Password changed', 'record_deleted' => 'Record deleted', 'audit_deleted' => 'Audit entries deleted',
        'account_rejected' => 'Account rejected', 'staff_rejected' => 'Application rejected', 'staff_more_info' => 'More information requested',
        'roster_changed' => 'Roster changed', 'approval_exception' => 'Approved as exception', 'preview_started' => 'Dashboard preview started',
        'preview_ended' => 'Dashboard preview ended', 'role_changed' => 'Role changed', 'bulk_approve' => 'Bulk approval'];
    return $m[$a] ?? ucfirst(str_replace('_', ' ', $a));
}

function st_card(string $label, $value, string $sub, string $icon, ?string $href = null): void
{
    $inner = '<span class="stat-ic">' . icon($icon) . '</span><span class="muted">' . e($label) . '</span><strong>' . number_format((int)$value) . '</strong><small>' . e($sub) . '</small>';
    echo $href ? '<a class="stat-card stat-link" href="' . e($href) . '">' . $inner . '</a>' : '<article class="stat-card">' . $inner . '</article>';
}

function st_activity(string $title, array $rows, string $kind): void
{
    echo '<section class="card act-card"><h3>' . e($title) . '</h3>';
    if (!$rows) { echo '<p class="muted">Nothing in this period.</p></section>'; return; }
    echo '<ul class="act-list">';
    foreach ($rows as $r) {
        $when = e(date('M j, g:i A', strtotime((string)$r['created_at'])));
        if ($kind === 'user') {
            $st = $r['status'] === 'suspended' ? 'deactivated' : str_replace('_', ' ', (string)$r['status']);
            echo '<li><span><strong>' . e($r['full_name'] ?: $r['email']) . '</strong><small>Registered · ' . e($st) . '</small></span><time>' . $when . '</time></li>';
        } else {
            $who = $r['target'] ?? '';
            echo '<li><span><strong>' . e(st_action_label((string)$r['action'])) . '</strong><small>'
               . e(trim(($who !== '' ? $who . ' · ' : '') . ($kind === 'admin' && !empty($r['actor']) ? 'by ' . $r['actor'] : (!$who ? (string)$r['detail'] : '')))) . '</small></span><time>' . $when . '</time></li>';
        }
    }
    echo '</ul></section>';
}

/** The whole statistics section: filter, cards, charts, recent activity. */
function render_stats(array $S): void
{
    $a = $S['acc']; $c = $S['campus']; $l = $S['logins']; $p = $S['period'];
    $json = json_encode($S['charts'], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
    ?>
<section class="stats" aria-labelledby="stats-title">
  <div class="card-head"><div><h2 id="stats-title">Statistics</h2><p class="muted">Live from your database · period: <strong><?= e($S['rangeLabel']) ?></strong></p></div>
    <nav class="chips" aria-label="Statistics period"><?php foreach (stats_ranges() as $k => $lab): ?><a class="chip <?= $S['range'] === $k ? 'is-on' : '' ?>" href="admin.php?r=<?= e($k) ?>"<?= $S['range'] === $k ? ' aria-current="true"' : '' ?>><?= e($lab) ?></a><?php endforeach; ?></nav></div>

  <h3 class="stat-h">Accounts <small class="muted">current totals</small></h3>
  <div class="stat-grid">
    <?php st_card('Total registered users', $a['total_users'], 'Every account, all roles', 'users'); ?>
    <?php st_card('Total students', $a['students_total'], 'Registered student accounts', 'user', 'verification.php?tab=students'); ?>
    <?php st_card('Approved students', $a['students_approved'], 'Can use the app', 'user-check', 'verification.php?tab=students&f=approved'); ?>
    <?php st_card('Pending students', $a['students_pending'], 'Awaiting email or ID', 'clock', 'verification.php?tab=students&f=pending'); ?>
    <?php st_card('Rejected students', $a['students_rejected'], 'Applications rejected', 'x', 'verification.php?tab=students&f=rejected'); ?>
    <?php st_card('Total instructors', $a['instructors_total'], 'Instructor and staff accounts', 'idcard', 'verification.php?tab=staff&role=instructor'); ?>
    <?php st_card('Approved instructors', $a['instructors_approved'], 'Can sign in', 'shieldcheck', 'verification.php?tab=staff&role=instructor&f=approved'); ?>
    <?php st_card('Pending instructor applications', $a['instructors_pending'], 'Awaiting your decision', 'file', 'verification.php?tab=pending'); ?>
    <?php st_card('Rejected instructor applications', $a['instructors_rejected'], 'Applications rejected', 'x', 'verification.php?tab=accounts&role=instructor&f=rejected'); ?>
    <?php st_card('Active accounts', $a['active_accounts'], 'Status approved', 'check', 'verification.php?tab=accounts&f=approved'); ?>
    <?php st_card('Deactivated accounts', $a['deactivated_accounts'], 'Cannot sign in', 'lock', 'verification.php?tab=accounts&f=suspended'); ?>
  </div>

  <h3 class="stat-h">Campus</h3>
  <div class="stat-grid">
    <?php st_card('Buildings', $c['buildings'], 'Mapped buildings', 'map', 'admin.php?t=locations'); ?>
    <?php st_card('All locations', $c['total'], 'Buildings, rooms and facilities', 'pin', 'admin.php?t=locations'); ?>
    <?php st_card('Classrooms and labs', $c['rooms'] + $c['labs'], $c['rooms'] . ' rooms · ' . $c['labs'] . ' labs', 'home', 'admin.php?t=locations'); ?>
    <?php st_card('Facilities and offices', $c['facilities'] + $c['offices'], $c['facilities'] . ' facilities · ' . $c['offices'] . ' offices', 'target', 'admin.php?t=locations'); ?>
    <?php st_card('Subjects', $c['subjects'], 'In the catalogue', 'file', 'admin.php?t=subjects'); ?>
    <?php st_card('Blocks / sections', $c['sections'], 'Class groups', 'users', 'admin.php?t=sections'); ?>
    <?php st_card('Class schedules', $c['schedules'], 'Configured entries', 'calendar', 'admin.php?t=schedules'); ?>
    <?php st_card('Walkway routes', $c['routes'], $c['points'] . ' walkway points behind them', 'nav', 'admin.php?t=path_edges'); ?>
  </div>

  <h3 class="stat-h">Sign-ins and activity</h3>
  <div class="stat-grid">
    <?php st_card('Successful sign-ins today', $l['total'], 'All roles', 'logout', 'verification.php?tab=logins&h=24'); ?>
    <?php st_card('Student sign-ins today', $l['student'], 'Students', 'user', 'verification.php?tab=logins&role=student&h=24'); ?>
    <?php st_card('Instructor sign-ins today', $l['instructor'], 'Instructors and staff', 'idcard', 'verification.php?tab=logins&role=instructor&h=24'); ?>
    <?php st_card('Administrator sign-ins today', $l['admin'], 'Administrators', 'shield', 'verification.php?tab=logins&role=admin&h=24'); ?>
    <?php st_card('Active users · 7 days', $l['active7'], 'Signed in at least once', 'users', 'verification.php?tab=accounts&f=active7'); ?>
    <?php st_card('Active users · 30 days', $l['active30'], 'Signed in at least once', 'users'); ?>
    <?php st_card('New registrations', $p['registrations'], $S['rangeLabel'], 'user-check'); ?>
    <?php st_card('Accounts approved', $p['approvals'], $S['rangeLabel'], 'shieldcheck'); ?>
    <?php st_card('Sign-ins', $l['inRange'], $S['rangeLabel'], 'clock', 'verification.php?tab=logins' . ($S['range'] === 'today' ? '&h=24' : ($S['range'] === '7d' ? '&h=168' : ($S['range'] === '30d' ? '&h=720' : '')))); ?>
  </div>

  <h3 class="stat-h">Charts <small class="muted"><?= e($S['rangeLabel']) ?> · accounts created in the period</small></h3>
  <div class="chart-grid">
    <?php foreach ([['byType', 'Student vs instructor accounts'], ['byStatus', 'Approved, pending, rejected and deactivated'], ['registrations', 'Registrations over time'],
                    ['logins', 'Login activity over time'], ['signins', 'Student vs instructor sign-ins'], ['growth', 'Monthly account growth']] as [$id, $title]): ?>
      <figure class="card chart-card"><figcaption><?= e($title) ?></figcaption><div class="chart-box"><canvas id="ch-<?= e($id) ?>" role="img" aria-label="<?= e($title) ?>"></canvas></div><p class="chart-empty muted" hidden>No data for this period.</p></figure>
    <?php endforeach; ?>
  </div>
  <script type="application/json" id="stats-data"><?= $json ?></script>
  <p class="help">Sign-in charts start counting from when migration 003 was applied; earlier sign-ins were never recorded individually.</p>

  <h3 class="stat-h">Recent activities <small class="muted"><?= e($S['rangeLabel']) ?></small></h3>
  <div class="act-grid">
    <?php st_activity('New students', $S['recent']['students'], 'user'); ?>
    <?php st_activity('New instructors', $S['recent']['instructors'], 'user'); ?>
    <?php st_activity('Recently approved', $S['recent']['approved'], 'audit'); ?>
    <?php st_activity('Recently deactivated', $S['recent']['deactivated'], 'audit'); ?>
    <?php st_activity('Recent password updates', $S['recent']['passwords'], 'audit'); ?>
    <?php st_activity('Recently deleted records', $S['recent']['deleted'], 'audit'); ?>
    <?php st_activity('Recent administrator actions', $S['recent']['admin'], 'admin'); ?>
  </div>
</section>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script src="assets/js/stats.js?v=1"></script>
<?php
}
