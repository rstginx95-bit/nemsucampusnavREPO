<?php
declare(strict_types=1);

/**
 * Schedule logic. The schedule is always read live from the database, so when an
 * admin changes a room, instructor, block or time, every affected student and
 * instructor sees the update immediately.
 */

const SCHEDULE_SELECT =
    'SELECT s.id, s.section_id, s.subject_id, s.instructor_id, s.room_id, s.day_of_week,
            s.start_time, s.end_time, s.updated_at,
            sub.code AS subject_code, sub.title AS subject_title,
            sec.code AS section_code,
            ins.full_name AS instructor_name,
            r.name AS room_name, r.floor AS room_floor, b.name AS building_name
       FROM schedules s
       JOIN subjects sub ON sub.id = s.subject_id
       JOIN sections sec ON sec.id = s.section_id
       LEFT JOIN instructors ins ON ins.id = s.instructor_id
       LEFT JOIN locations r ON r.id = s.room_id
       LEFT JOIN locations b ON b.id = r.parent_id';

function has_schedule_access(array $u): bool
{
    return $u['mode'] === 'student' || $u['mode'] === 'instructor';
}

/** Map, AI and calendar work for everyone who is signed in and not blocked. Pending old students are blocked. */
function has_basic_access(array $u): bool
{
    return $u['mode'] !== 'pending';
}

function decorate_class(array $row): array
{
    $row['id']          = (int)$row['id'];
    $row['room_id']     = $row['room_id'] !== null ? (int)$row['room_id'] : null;
    $row['day_of_week'] = (int)$row['day_of_week'];
    $row['start']       = fmt_time($row['start_time']);
    $row['end']         = fmt_time($row['end_time']);
    $place = $row['room_name'] ?? 'Room to be announced';
    if (!empty($row['building_name'])) {
        $floor = $row['room_floor'] !== null ? ', ' . ordinal((int)$row['room_floor']) . ' floor' : '';
        $row['place']      = $row['room_name'] . ', ' . $row['building_name'] . $floor;
        $row['place_short'] = $row['room_name'] . ', ' . $row['building_name'];
    } else {
        $row['place']       = $place;
        $row['place_short'] = $place;
    }
    return $row;
}

/** All weekly classes for a student (their block) or an instructor (their assignments). */
function user_schedule(array $u): array
{
    if ($u['mode'] === 'student') {
        // The student's block, plus any classes an instructor added to this student personally.
        $st = q(SCHEDULE_SELECT . ' WHERE s.section_id = ? OR s.id IN (SELECT schedule_id FROM student_classes WHERE record_id = ?)
                                    ORDER BY s.day_of_week, s.start_time', [$u['section_id'] ?? 0, $u['student_record_id']]);
    } elseif ($u['mode'] === 'instructor' && !empty($u['instructor_id'])) {
        $st = q(SCHEDULE_SELECT . ' WHERE s.instructor_id = ? ORDER BY s.day_of_week, s.start_time', [$u['instructor_id']]);
    } else {
        return [];
    }
    return array_map('decorate_class', $st->fetchAll());
}

function classes_on_day(array $rows, int $dayOfWeek): array
{
    return array_values(array_filter($rows, fn($r) => $r['day_of_week'] === $dayOfWeek));
}

/**
 * Finds the class happening now or the next one coming up (up to 7 days ahead).
 * Returns null when there is nothing scheduled.
 *   status: 'ongoing' | 'today' | 'tomorrow' | 'later'
 */
function next_class(array $rows, ?DateTimeImmutable $now = null): ?array
{
    if (!$rows) return null;
    $now = $now ?? new DateTimeImmutable('now');
    $nowTime = $now->format('H:i:s');

    for ($offset = 0; $offset <= 7; $offset++) {
        $date = $now->modify("+{$offset} day");
        $dow  = (int)$date->format('N');
        $day  = classes_on_day($rows, $dow);
        foreach ($day as $row) {
            if ($offset === 0 && $row['end_time'] <= $nowTime) {
                continue; // already finished
            }
            $startAt = new DateTimeImmutable($date->format('Y-m-d') . ' ' . $row['start_time']);
            $minutes = (int)floor(($startAt->getTimestamp() - $now->getTimestamp()) / 60);
            if ($offset === 0 && $row['start_time'] <= $nowTime) {
                $status = 'ongoing';
            } elseif ($offset === 0) {
                $status = 'today';
            } elseif ($offset === 1) {
                $status = 'tomorrow';
            } else {
                $status = 'later';
            }
            return ['row' => $row, 'status' => $status, 'minutes' => $minutes, 'date' => $date];
        }
    }
    return null;
}

/** Human wording such as "in 20 minutes", "now", "tomorrow at 8:00 AM". */
function when_phrase(array $next): string
{
    $row = $next['row'];
    switch ($next['status']) {
        case 'ongoing':
            return 'right now (until ' . $row['end'] . ')';
        case 'today':
            $m = $next['minutes'];
            if ($m < 60) return 'in ' . max($m, 1) . ' minute' . ($m === 1 ? '' : 's') . ' (' . $row['start'] . ')';
            return 'today at ' . $row['start'];
        case 'tomorrow':
            return 'tomorrow at ' . $row['start'];
        default:
            return day_name($row['day_of_week']) . ' at ' . $row['start'];
    }
}

function class_state(array $row, ?DateTimeImmutable $now = null): string
{
    $now = $now ?? new DateTimeImmutable('now');
    if ($row['day_of_week'] !== (int)$now->format('N')) return 'other';
    $t = $now->format('H:i:s');
    if ($row['end_time'] <= $t) return 'done';
    if ($row['start_time'] <= $t) return 'now';
    return 'upcoming';
}

function recent_changes(array $u, int $days = 7, int $limit = 5): array
{
    if ($u['mode'] === 'student') {
        $st = q('SELECT summary, created_at FROM schedule_changes
                  WHERE (section_id = ? OR record_id = ?) AND created_at > (NOW() - INTERVAL ' . (int)$days . ' DAY)
                  ORDER BY created_at DESC LIMIT ' . (int)$limit, [$u['section_id'] ?? 0, $u['student_record_id']]);
    } elseif ($u['mode'] === 'instructor' && !empty($u['instructor_id'])) {
        $st = q('SELECT summary, created_at FROM schedule_changes
                  WHERE instructor_id = ? AND created_at > (NOW() - INTERVAL ' . (int)$days . ' DAY)
                  ORDER BY created_at DESC LIMIT ' . (int)$limit, [$u['instructor_id']]);
    } else {
        return [];
    }
    return $st->fetchAll();
}

/** Schedule ids touched in the last 7 days (used to show an "Updated" badge). */
function recently_changed_ids(array $u): array
{
    if ($u['mode'] === 'student') {
        $st = q('SELECT DISTINCT schedule_id FROM schedule_changes WHERE (section_id = ? OR record_id = ?) AND schedule_id IS NOT NULL
                  AND created_at > (NOW() - INTERVAL 7 DAY)', [$u['section_id'] ?? 0, $u['student_record_id']]);
    } elseif ($u['mode'] === 'instructor' && !empty($u['instructor_id'])) {
        $st = q('SELECT DISTINCT schedule_id FROM schedule_changes WHERE instructor_id = ? AND schedule_id IS NOT NULL
                  AND created_at > (NOW() - INTERVAL 7 DAY)', [$u['instructor_id']]);
    } else {
        return [];
    }
    return array_map('intval', array_column($st->fetchAll(), 'schedule_id'));
}

/** Calendar events overlapping a date range. */
function calendar_events_between(string $from, string $to): array
{
    return q('SELECT id, title, category, start_date, end_date, description FROM calendar_events
               WHERE start_date <= ? AND end_date >= ? ORDER BY start_date, title', [$to, $from])->fetchAll();
}

function upcoming_events(int $limit = 4): array
{
    return q('SELECT id, title, category, start_date, end_date, description FROM calendar_events
               WHERE end_date >= CURDATE() ORDER BY start_date, title LIMIT ' . (int)$limit)->fetchAll();
}

function event_range_label(array $e): string
{
    $a = new DateTimeImmutable($e['start_date']);
    $b = new DateTimeImmutable($e['end_date']);
    if ($a == $b) return $a->format('M j, Y');
    if ($a->format('Y-m') === $b->format('Y-m')) return $a->format('M j') . ' - ' . $b->format('j, Y');
    return $a->format('M j') . ' - ' . $b->format('M j, Y');
}

/** Students in the same block, plus students given this class individually. For instructors. */
function class_roster(int $scheduleId): array
{
    return q('SELECT r.id, r.student_no, r.last_name, r.first_name, sec.code AS section_code,
                     IF(u.id IS NULL, 0, 1) AS has_account, 0 AS individual
                FROM schedules s
                JOIN student_records r ON r.section_id = s.section_id
                LEFT JOIN sections sec ON sec.id = r.section_id
                LEFT JOIN users u ON u.student_record_id = r.id
               WHERE s.id = ?
              UNION
              SELECT r.id, r.student_no, r.last_name, r.first_name, sec.code, IF(u.id IS NULL, 0, 1), 1
                FROM student_classes sc
                JOIN student_records r ON r.id = sc.record_id
                LEFT JOIN sections sec ON sec.id = r.section_id
                LEFT JOIN users u ON u.student_record_id = r.id
               WHERE sc.schedule_id = ?
               ORDER BY last_name, first_name', [$scheduleId, $scheduleId])->fetchAll();
}
