<?php
declare(strict_types=1);

define('CN_ROOT', dirname(__DIR__));

/* PHP 7.4 compatibility */
if (!function_exists('str_contains')) {
    function str_contains(string $h, string $n): bool { return $n === '' || strpos($h, $n) !== false; }
}
if (!function_exists('str_starts_with')) {
    function str_starts_with(string $h, string $n): bool { return $n === '' || strncmp($h, $n, strlen($n)) === 0; }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with(string $h, string $n): bool { return $n === '' || substr($h, -strlen($n)) === $n; }
}

$GLOBALS['CN_CONFIG'] = require CN_ROOT . '/config.php';
date_default_timezone_set(cfg('app.timezone'));

/* Uncaught errors go to database/error.log and a readable page (details only while debug is on). */
set_exception_handler(function (Throwable $e): void {
    @file_put_contents(CN_ROOT . '/database/error.log',
        '[' . date('c') . '] ' . get_class($e) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() . "\n", FILE_APPEND);
    if (!headers_sent()) {
        http_response_code(500);
    }
    $debug = (bool)cfg('app.debug', false);
    $isApi = str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/');
    if ($e instanceof PDOException && ($e->errorInfo[0] ?? '') === '42S02' && is_file(CN_ROOT . '/install.php') && !$isApi) {
        echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
           . '<body style="font-family:system-ui,sans-serif;max-width:640px;margin:8vh auto;padding:0 20px;line-height:1.5">'
           . '<h1>One more step: set up the database</h1><p>The tables have not been created yet.</p>'
           . '<p><a href="install.php" style="display:inline-block;background:#0f3d2e;color:#fff;padding:14px 22px;border-radius:999px;text-decoration:none;font-weight:600">Set up the database now</a></p></body>';
        return;
    }
    if ($isApi) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => $debug ? $e->getMessage() : 'Something went wrong on the server.']);
        return;
    }
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<body style="font-family:system-ui,sans-serif;max-width:640px;margin:8vh auto;padding:0 20px;line-height:1.5">'
       . '<h1>Something went wrong</h1><p>NEMSU CampusNav AI could not finish this request.</p>';
    if ($debug) {
        echo '<pre style="white-space:pre-wrap;background:#f3f3f3;padding:12px;border-radius:8px">'
           . htmlspecialchars(get_class($e) . ': ' . $e->getMessage() . "\n" . basename($e->getFile()) . ':' . $e->getLine()) . '</pre>'
           . '<p>Open <a href="check.php">check.php</a> to test PHP, the database and the tables.</p>';
    }
    echo '</body>';
});

/* ---------- config ---------- */
function cfg(string $path, $default = null)
{
    $node = $GLOBALS['CN_CONFIG'];
    foreach (explode('.', $path) as $key) {
        if (!is_array($node) || !array_key_exists($key, $node)) {
            return $default;
        }
        $node = $node[$key];
    }
    return $node;
}

/* ---------- transport security + session ---------- */
function is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
}
if (cfg('security.require_https', false) && !is_https() && PHP_SAPI !== 'cli') {
    http_response_code(426);
    exit('This system must be opened over HTTPS.');
}
if (PHP_SAPI !== 'cli') {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin'); // sends only the site origin to map tile providers
    header('Permissions-Policy: geolocation=(self), camera=(), microphone=()');
    if (is_https()) {
        header('Strict-Transport-Security: max-age=31536000');
    }
}
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_set_cookie_params([
    'lifetime' => 0, 'path' => '/', 'secure' => is_https(), 'httponly' => true, 'samesite' => 'Lax',
]);
session_name('cn_session');
session_start();
// A session cookie moved to another browser is useless.
$uaHash = hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '');
if (isset($_SESSION['ua']) && !hash_equals($_SESSION['ua'], $uaHash)) {
    $_SESSION = [];
    session_regenerate_id(true);
}
$_SESSION['ua'] = $uaHash;

/* ---------- database ---------- */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $c = cfg('db');
        try {
            $pdo = new PDO("mysql:host={$c['host']};dbname={$c['name']};charset={$c['charset']}", $c['user'], $c['pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
            $pdo->exec("SET time_zone = '+08:00'");
        } catch (PDOException $e) {
            http_response_code(500);
            exit('Database connection failed. Check config.php and run install.php first.');
        }
    }
    return $pdo;
}

function q(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

/* ---------- output helpers ---------- */
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function json_out(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function take_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

function client_ip(): string
{
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);   // never trust X-Forwarded-For here
}

function app_url(string $path = ''): string
{
    $base = (string)cfg('app.base_url', '');
    if ($base === '') {
        $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
        if (str_ends_with($dir, '/api')) $dir = substr($dir, 0, -4);
        $base = (is_https() ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $dir;
    }
    return rtrim($base, '/') . '/' . ltrim($path, '/');
}

/* ---------- CSRF ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_valid(): bool
{
    $sent = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    return is_string($sent) && $sent !== '' && hash_equals(csrf_token(), $sent);
}

function require_post_csrf(bool $json = false): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valid()) {
        if ($json) {
            json_out(['error' => 'Your session expired. Reload the page and try again.'], 419);
        }
        http_response_code(419);
        exit('Your session expired. Go back, reload the page and try again.');
    }
}

/* ---------- rate limiting (shared across browsers, stored in MySQL) ---------- */
function rate_hit(string $bucket, string $key, int $max, int $window): bool
{
    $kh  = hash('sha256', $bucket . '|' . $key);
    $now = time();
    $row = q('SELECT hits, window_start FROM rate_limits WHERE bucket = ? AND key_hash = ?', [$bucket, $kh])->fetch();
    if (!$row || (int)$row['window_start'] + $window <= $now) {
        q('REPLACE INTO rate_limits (bucket, key_hash, hits, window_start) VALUES (?,?,1,?)', [$bucket, $kh, $now]);
        return true;
    }
    if ((int)$row['hits'] >= $max) {
        return false;
    }
    q('UPDATE rate_limits SET hits = hits + 1 WHERE bucket = ? AND key_hash = ?', [$bucket, $kh]);
    return true;
}

/** Limits per signed-in user (or per IP when nobody is signed in). */
function rate_ok(string $bucket, int $max = 6, int $window = 900): bool
{
    return rate_hit($bucket, (string)($_SESSION['uid'] ?? 0) . '|' . client_ip(), $max, $window);
}

/** Limits per IP address AND per target (for example per email), so neither can be hammered. */
function rate_ok_for(string $bucket, string $target, int $max = 6, int $window = 900): bool
{
    $a = rate_hit($bucket . ':ip', client_ip(), $max * 3, $window);
    $b = rate_hit($bucket . ':t', strtolower($target), $max, $window);
    return $a && $b;
}

/* ---------- audit trail (never write passwords, codes or whole tokens here) ---------- */
function audit(string $action, string $targetType = '', ?int $targetId = null, string $detail = '', ?int $actorId = null): void
{
    try {
        q('INSERT INTO audit_log (actor_id, action, target_type, target_id, ip, detail) VALUES (?,?,?,?,?,?)',
            [$actorId ?? ($_SESSION['uid'] ?? null), substr($action, 0, 40), substr($targetType, 0, 20), $targetId, client_ip(), mb_substr($detail, 0, 500)]);
    } catch (Throwable $e) {
        // Auditing must never break the request, but the failure is visible in error.log.
        @file_put_contents(CN_ROOT . '/database/error.log', '[' . date('c') . '] audit failed: ' . $e->getMessage() . "\n", FILE_APPEND);
    }
}

/* ---------- passwords ---------- */
function hash_password(string $pw): string
{
    return defined('PASSWORD_ARGON2ID') ? password_hash($pw, PASSWORD_ARGON2ID) : password_hash($pw, PASSWORD_BCRYPT, ['cost' => 12]);
}

/** Returns an error message, or null when the password is acceptable. */
function password_problem(string $pw, string $email = '', bool $staff = false): ?string
{
    $min = 12;
    if (strlen($pw) < $min) return 'Use at least 12 characters.';
    if (strlen($pw) > 200) return 'That password is too long.';
    if (!preg_match('/[a-z]/', $pw) || !preg_match('/[A-Z]/', $pw) || !preg_match('/\d/', $pw) || !preg_match('/[^A-Za-z0-9]/', $pw)) {
        return 'Use uppercase and lowercase letters, at least one number, and at least one symbol.';
    }
    $lower = strtolower($pw);
    if ($email !== '' && str_contains($lower, strtolower(explode('@', $email)[0]))) return 'Do not put your email name in the password.';
    if (in_array($lower, ['password1', 'password123', '12345678', '123456789', 'qwerty123', 'nemsu12345', 'admin12345'], true)) return 'That password is too common.';
    return null;
}

/* ---------- authentication ---------- */
const STAFF_ROLES = ['instructor', 'staff', 'admin'];

function current_user(): ?array
{
    static $cache = false;
    if ($cache !== false) {
        return $cache;
    }
    $id = $_SESSION['uid'] ?? null;
    if (!$id) {
        return $cache = null;
    }
    $u = q(
        'SELECT u.*, sr.student_no, sr.section_id, sr.first_name AS sr_first, sr.last_name AS sr_last,
                sec.code AS section_code, sec.program AS section_program, sec.year_level,
                ins.full_name AS instructor_name, ins.department
           FROM users u
           LEFT JOIN student_records sr ON sr.id = u.student_record_id
           LEFT JOIN sections sec ON sec.id = sr.section_id
           LEFT JOIN instructors ins ON ins.id = u.instructor_id
          WHERE u.id = ?',
        [$id]
    )->fetch();
    $stop = false;
    if (!$u || $u['status'] === 'suspended' || $u['status'] === 'rejected') {
        $stop = true;
    } elseif (!empty($u['password_changed_at']) && strtotime($u['password_changed_at']) > (int)($_SESSION['auth_at'] ?? 0)) {
        $stop = true;                                    // password changed after this session began
    } elseif (in_array($u['role'], STAFF_ROLES, true)
              && time() - (int)($_SESSION['last_seen'] ?? time()) > (int)cfg('security.staff_idle_minutes', 30) * 60) {
        $stop = true;                                    // staff idle timeout
        flash('error', 'You were signed out because of inactivity.');
    }
    if ($stop) {
        unset($_SESSION['uid'], $_SESSION['auth_at'], $_SESSION['reauth_at']);
        return $cache = null;
    }
    $_SESSION['last_seen'] = time();

    $u['staff_ok'] = in_array($u['role'], STAFF_ROLES, true) && $u['status'] === 'approved' && !empty($u['activated_at']);
    if (in_array($u['role'], STAFF_ROLES, true)) {
        // Staff powers need an approved AND activated account. Anything else is blocked.
        $u['mode'] = !$u['staff_ok'] ? 'blocked' : ($u['instructor_id'] ? 'instructor' : 'admin');
    } elseif ($u['status'] === 'approved') {
        $u['mode'] = $u['student_record_id'] ? 'student' : 'guest';
    } elseif ($u['status'] === 'pending_identity' && $u['requested_role'] === 'student') {
        $u['mode'] = 'pending';                          // student who still has to verify an ID
    } else {
        $u['mode'] = 'blocked';                          // pending email / pending admin / pending staff identity
    }
    // Administrator-only dashboard preview. It changes ONLY what the interface shows. role, staff_ok and every
    // server-side permission check stay exactly as they are, and the session value is honoured for admins only.
    $u['preview'] = '';
    if ($u['role'] === 'admin' && $u['staff_ok'] && in_array($_SESSION['preview_role'] ?? '', ['student', 'instructor'], true)) {
        $u['preview'] = (string)$_SESSION['preview_role'];
        $u['real_mode'] = $u['mode'];
        $u['mode'] = $u['preview'];
    }
    return $cache = $u;
}

function require_login(): array
{
    $u = current_user();
    if (!$u) {
        redirect('login.php');
    }
    return $u;
}

function is_staff(?array $u): bool
{
    return $u !== null && !empty($u['staff_ok']);
}

function is_admin(?array $u): bool
{
    return is_staff($u) && $u['role'] === 'admin';
}

/** Preview is read-only: blocks every POST while an administrator is previewing the Student or Instructor dashboard. */
function preview_block_writes(string $back): void
{
    $u = current_user();
    if ($u && !empty($u['preview']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        flash('error', 'Preview mode is read-only. Return to the Admin Dashboard to make changes.');
        redirect($back);
    }
}

/** Every staff page and action calls this. Students and pending applicants never get through. */
function require_staff(): array
{
    $u = require_login();
    if (!is_staff($u)) {
        audit('staff_page_denied', 'user', (int)$u['id'], basename($_SERVER['SCRIPT_NAME'] ?? ''));
        http_response_code(403);
        exit('This page is for approved instructors and staff.');
    }
    return $u;
}

function require_admin(): array
{
    $u = require_staff();
    if ($u['role'] !== 'admin') {
        audit('admin_page_denied', 'user', (int)$u['id'], basename($_SERVER['SCRIPT_NAME'] ?? ''));
        http_response_code(403);
        exit('Administrators only.');
    }
    return $u;
}

/**
 * Developer-only access. For backward compatibility with the current schema,
 * the designated Developer is an allowlisted existing admin account.
 * This is deliberately stricter than ordinary admin/staff access.
 */
function require_developer(): array
{
    $u = require_admin();
    $allowed = strtolower(trim((string)cfg('security.developer_email', '')));
    if ($allowed === '' || strtolower((string)$u['email']) !== $allowed) {
        audit('developer_access_denied', 'user', (int)$u['id'], basename($_SERVER['SCRIPT_NAME'] ?? ''));
        http_response_code(403);
        exit('Developer access only.');
    }
    return $u;
}

function api_user(): array
{
    $u = current_user();
    if (!$u) {
        json_out(['error' => 'Please sign in again.'], 401);
    }
    if ($u['mode'] === 'blocked') {
        json_out(['error' => 'Your account is not active yet.'], 403);
    }
    return $u;
}

function login_user(int $id): void
{
    session_regenerate_id(true);
    $_SESSION['uid'] = $id;
    $_SESSION['auth_at'] = time();
    $_SESSION['last_seen'] = time();
    unset($_SESSION['reauth_at'], $_SESSION['pending2fa'], $_SESSION['preview_role']);
    q('UPDATE users SET last_login = NOW() WHERE id = ?', [$id]);
    try {                                              // one row per successful sign-in, used by the statistics dashboard
        q('INSERT INTO login_events (user_id, role, ip) SELECT id, role, ? FROM users WHERE id = ?', [client_ip(), $id]);
    } catch (Throwable $e) { /* login_events exists after migration 003; sign-in must never fail because of it */ }
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', (bool)$p['secure'], (bool)$p['httponly']);
    }
    session_destroy();
}

/* Sensitive administrator actions ask for the password again if it was not entered recently. */
function reauth_fresh(): bool
{
    return time() - (int)($_SESSION['reauth_at'] ?? 0) <= (int)cfg('security.reauth_minutes', 10) * 60;
}

function require_reauth(string $returnTo): void
{
    if (!reauth_fresh()) {
        redirect('reauth.php?next=' . rawurlencode($returnTo));
    }
}

function normalize_mobile(string $raw): ?string
{
    $d = preg_replace('/[^\d+]/', '', $raw);
    $d = ltrim((string)$d, '+');
    if (preg_match('/^(?:63|0)?(9\d{9})$/', $d, $m)) {
        return '+63' . $m[1];
    }
    return null;
}

function find_user_by_identifier(string $identifier): ?array
{
    $identifier = trim($identifier);
    if (str_contains($identifier, '@')) {
        $row = q('SELECT * FROM users WHERE email = ?', [strtolower($identifier)])->fetch();
    } else {
        $m = normalize_mobile($identifier);
        $row = $m ? q('SELECT * FROM users WHERE mobile = ?', [$m])->fetch() : false;
    }
    return $row ?: null;
}

function age_from_birthday(?string $birthday): ?int
{
    if (!$birthday) return null;
    try {
        return (new DateTimeImmutable($birthday))->diff(new DateTimeImmutable('today'))->y;
    } catch (Exception $e) {
        return null;
    }
}

/* ---------- formatting ---------- */
function fmt_time(string $t): string
{
    return date('g:i A', strtotime($t));
}

function day_name(int $d): string
{
    return ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][$d] ?? '';
}

function day_short(int $d): string
{
    return ['', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][$d] ?? '';
}

function ordinal(int $n): string
{
    $s = ['th', 'st', 'nd', 'rd'];
    $v = $n % 100;
    return $n . ($s[($v - 20) % 10] ?? ($s[$v] ?? $s[0]));
}

function greeting(): string
{
    $h = (int)date('G');
    if ($h < 12) return 'Good morning';
    if ($h < 18) return 'Good afternoon';
    return 'Good evening';
}

function first_name(array $u): string
{
    $name = trim($u['full_name']);
    $name = preg_replace('/^(prof\.?|dr\.?|engr\.?|mr\.?|ms\.?|mrs\.?)\s+/i', '', $name);
    return explode(' ', $name)[0] ?: 'there';
}
