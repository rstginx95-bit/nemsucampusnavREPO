<?php
declare(strict_types=1);

/**
 * Flexible instructor-application review (Admin authority).
 *
 * - application_requirements() lists every requirement and whether it is met (computed live, server side).
 * - staff_decide() is the ONLY path for an Admin decision: approve (even with missing requirements),
 *   keep pending (request more), or reject. Each decision is recorded in application_decisions + audit_log
 *   and the applicant is emailed.
 * Only call staff_decide() from a page protected by require_admin(). It re-checks nothing about the caller's
 * role by itself, so never expose it anywhere else.
 */

const APP_DOC_MAX_BYTES = 3145728;                       // 3 MB
const APP_DOC_MAX_PER_USER = 5;

function app_doc_types(): array
{
    return ['application/pdf' => 'pdf', 'image/jpeg' => 'jpg', 'image/png' => 'png'];
}

function app_doc_dir(): string
{
    return CN_ROOT . '/storage/applications';
}

/** Validates an entry of $_FILES. Returns ['none'=>true] | ['error'=>msg] | ['mime'=>..,'ext'=>..,'size'=>..]. */
function app_doc_validate(?array $f): array
{
    if (!$f || !isset($f['error']) || is_array($f['error']) || $f['error'] === UPLOAD_ERR_NO_FILE) {
        return ['none' => true];
    }
    if ($f['error'] !== UPLOAD_ERR_OK) {
        return ['error' => 'The file could not be uploaded. Try a PDF, JPG or PNG of 3 MB or less.'];
    }
    $size = (int)($f['size'] ?? 0);
    if ($size <= 0 || $size > APP_DOC_MAX_BYTES) {
        return ['error' => 'The file must be 3 MB or smaller.'];
    }
    if (empty($f['tmp_name']) || !is_uploaded_file((string)$f['tmp_name'])) {
        return ['error' => 'The upload was not valid. Please try again.'];
    }
    if (!function_exists('finfo_open')) {
        return ['error' => 'File checking is unavailable on this server (enable the PHP fileinfo extension).'];
    }
    $fi = finfo_open(FILEINFO_MIME_TYPE);
    $mime = (string)finfo_file($fi, (string)$f['tmp_name']);
    finfo_close($fi);                                    // type is decided by file CONTENT, not the filename
    $types = app_doc_types();
    if (!isset($types[$mime])) {
        return ['error' => 'Only PDF, JPG or PNG files are accepted.'];
    }
    return ['mime' => $mime, 'ext' => $types[$mime], 'size' => $size];
}

/** Stores a validated upload outside public access. Never throws; returns false on any failure. */
function app_doc_save(int $userId, array $file, array $v, string $label): bool
{
    try {
        if (!empty($v['error']) || !empty($v['none'])) return false;
        $count = (int)q('SELECT COUNT(*) FROM application_documents WHERE user_id = ?', [$userId])->fetchColumn();
        if ($count >= APP_DOC_MAX_PER_USER) return false;
        $dir = app_doc_dir();
        if (!is_dir($dir) && !@mkdir($dir, 0750, true)) return false;
        if (!is_file($dir . '/.htaccess')) {
            @file_put_contents($dir . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
        }
        $stored = bin2hex(random_bytes(16)) . '.' . $v['ext'];     // 32 hex + dot + ext = 36 chars max
        if (!@move_uploaded_file((string)$file['tmp_name'], $dir . '/' . $stored)) return false;
        @chmod($dir . '/' . $stored, 0640);
        $orig = preg_replace('/[^A-Za-z0-9._ \-()]/', '_', basename((string)($file['name'] ?? 'document')));
        q('INSERT INTO application_documents (user_id, label, original_name, stored_name, mime, size_bytes) VALUES (?,?,?,?,?,?)',
            [$userId, mb_substr($label, 0, 80), mb_substr((string)$orig, 0, 120), $stored, $v['mime'], $v['size']]);
        audit('app_doc_uploaded', 'user', $userId, $label, $userId);
        return true;
    } catch (Throwable $e) {
        @file_put_contents(CN_ROOT . '/database/error.log', '[' . date('c') . '] app_doc_save: ' . $e->getMessage() . "\n", FILE_APPEND);
        return false;
    }
}

function app_documents(int $userId): array
{
    try {
        return q('SELECT id, label, original_name, mime, size_bytes, uploaded_at FROM application_documents WHERE user_id = ? ORDER BY id', [$userId])->fetchAll();
    } catch (Throwable $e) {
        return [];                                       // migration 002 not applied yet
    }
}

/**
 * Every requirement for an instructor application and whether it is met right now.
 * 'hard' items can never be overridden (identity/security); everything else the Admin may waive.
 * @return array<int, array{key:string,label:string,met:bool,hard:bool,detail:string}>
 */
function application_requirements(int $userId): array
{
    $user = q('SELECT * FROM users WHERE id = ?', [$userId])->fetch();
    $app  = q('SELECT * FROM staff_applications WHERE user_id = ?', [$userId])->fetch();
    if (!$user || !$app) return [];

    $items = [];
    $items[] = ['key' => 'email', 'label' => 'Email address verified', 'hard' => true,
        'met' => !empty($user['email_verified_at']),
        'detail' => !empty($user['email_verified_at']) ? 'Verified ' . date('M j, g:i A', strtotime((string)$user['email_verified_at'])) : 'The applicant has not confirmed their email. This cannot be waived.'];

    $haveInfo = trim((string)$app['employee_no']) !== '' && trim((string)$app['department']) !== '';
    $items[] = ['key' => 'info', 'label' => 'Employee ID and department submitted', 'hard' => false, 'met' => $haveInfo,
        'detail' => $haveInfo ? $app['employee_no'] . ' / ' . $app['department'] : 'Employee ID or department is blank.'];

    return $items;
}

/** @return string[] labels of requirements that are not met */
function requirements_missing(array $reqs, bool $hardOnly = false): array
{
    $out = [];
    foreach ($reqs as $r) {
        if (!$r['met'] && (!$hardOnly || $r['hard'])) $out[] = $r['label'];
    }
    return $out;
}

/** Writes the permanent decision record. Returns its id. */
function decision_record(int $userId, ?int $adminId, string $decision, array $missing, string $remarks): int
{
    q('INSERT INTO application_decisions (user_id, admin_id, decision, missing_requirements, remarks, ip) VALUES (?,?,?,?,?,?)',
        [$userId, $adminId, $decision, json_encode(array_values($missing), JSON_UNESCAPED_UNICODE), mb_substr($remarks, 0, 1000), client_ip()]);
    return (int)db()->lastInsertId();
}

function decision_set_email(int $decisionId, array $mail): void
{
    try {
        q('UPDATE application_decisions SET email_status = ?, email_error = ? WHERE id = ?',
            [(string)$mail['status'], mb_substr((string)$mail['error'], 0, 255), $decisionId]);
    } catch (Throwable $e) { /* never break the decision */ }
}

function clean_remarks(string $s): string
{
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', trim($s)) ?? '';
    return mb_substr($s, 0, 1000);
}

/**
 * The single entry point for an Admin decision on an instructor application.
 * $decision: 'approve' | 'pending' | 'reject'.
 * @return array{ok:bool,message:string,mail:string}
 */
function staff_decide(int $userId, int $adminId, string $decision, string $remarks, bool $ackMissing): array
{
    $remarks = clean_remarks($remarks);
    $fail = fn(string $m): array => ['ok' => false, 'message' => $m, 'mail' => ''];
    if (!in_array($decision, ['approve', 'pending', 'reject'], true)) return $fail('Choose a decision.');
    if ($userId === $adminId) return $fail('You cannot decide your own application.');
    if ($decision === 'pending' && mb_strlen($remarks) < 5) {
        return $fail('To keep an application pending, write what is still needed. The applicant is emailed this text.');
    }

    $mailRes = ['status' => 'failed', 'error' => 'not sent'];
    $decisionId = 0; $applicant = null; $missing = []; $type = '';
    db()->beginTransaction();
    try {
        $applicant = q('SELECT * FROM users WHERE id = ? FOR UPDATE', [$userId])->fetch();
        $app = q('SELECT * FROM staff_applications WHERE user_id = ?', [$userId])->fetch();
        if (!$applicant || !$app || !in_array($applicant['status'], ['pending_admin', 'pending_identity'], true) || $applicant['role'] !== 'student') {
            db()->rollBack();
            return $fail('That application is not waiting for a decision (it may already have been decided).');
        }
        $reqs = application_requirements($userId);       // recomputed here; the browser is never trusted
        $missing = requirements_missing($reqs);

        if ($decision === 'approve') {
            if (requirements_missing($reqs, true)) {
                db()->rollBack();
                return $fail('The applicant has not verified their email. This one requirement cannot be waived.');
            }
            if ($missing && !$ackMissing) {
                db()->rollBack();
                return $fail('Tick the box to confirm you are approving despite the missing requirements.');
            }
            staff_approve($userId, $adminId, $remarks !== '' ? $remarks : 'Approved by administrator.', false);
            $type = $missing ? 'approved_exception' : 'approved';
            $decisionId = decision_record($userId, $adminId, $type, $missing, $remarks);
            audit($missing ? 'approval_exception' : 'approval', 'user', $userId,
                ($missing ? 'missing=' . implode('; ', $missing) . ' | ' : '') . 'remarks=' . mb_substr($remarks, 0, 250), $adminId);
        } elseif ($decision === 'reject') {
            staff_reject($userId, $adminId, $remarks !== '' ? $remarks : 'Rejected by administrator.', false);
            $type = 'rejected';
            $decisionId = decision_record($userId, $adminId, $type, $missing, $remarks);
        } else {
            staff_request_more($userId, $adminId, $remarks, false);
            $type = 'kept_pending';
            $decisionId = decision_record($userId, $adminId, $type, $missing, $remarks);
        }
        db()->commit();
    } catch (Throwable $e) {
        if (db()->inTransaction()) db()->rollBack();
        @file_put_contents(CN_ROOT . '/database/error.log', '[' . date('c') . '] staff_decide: ' . $e->getMessage() . "\n", FILE_APPEND);
        return $fail('The decision could not be saved, nothing was changed. If this keeps happening, run migration 002 (see MIGRATION_GUIDE.md).');
    }

    // Email goes out AFTER the decision is safely committed, so a mail failure can never undo or block it.
    $name = (string)$applicant['full_name'];
    if ($type === 'rejected') {
        send_mail($applicant['email'], 'Your NEMSU CampusNav AI instructor application',
            "Hello $name,\n\nAfter review, we are unable to approve your instructor application at this time.\n"
            . "If you believe this is a mistake, please contact your department or the system administrator.\n", 'app_rejected');
        $mailRes = mail_last();
    } elseif ($type === 'kept_pending') {
        send_mail($applicant['email'], 'More information needed for your NEMSU CampusNav AI application',
            "Hello $name,\n\nYour instructor application is still pending. The administrator needs the following from you:\n\n"
            . $remarks . "\n\nSign in to the Instructor Login page and open your application status page to upload a document, "
            . "or contact the system administrator.\n", 'app_more_info');
        $mailRes = mail_last();
    } else {
        approval_email($userId, $missing);
        $mailRes = mail_last();
    }
    decision_set_email($decisionId, $mailRes);

    $label = ['approved' => 'Approved', 'approved_exception' => 'Approved as an exception (' . count($missing) . ' requirement(s) missing)',
              'rejected' => 'Rejected', 'kept_pending' => 'Kept pending'][$type];
    return ['ok' => true, 'message' => $label . '. ' . mail_outcome_text($mailRes), 'mail' => (string)$mailRes['status']];
}
