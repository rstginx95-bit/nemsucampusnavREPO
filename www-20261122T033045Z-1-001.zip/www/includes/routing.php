<?php
declare(strict_types=1);

/**
 * Campus routing: shortest walking path over the path_nodes / path_edges graph,
 * followed by indoor directions (floor + room hint).
 */

function haversine(float $lat1, float $lng1, float $lat2, float $lng2): float
{
    $r = 6371000.0;
    $p1 = deg2rad($lat1);
    $p2 = deg2rad($lat2);
    $dp = $p2 - $p1;
    $dl = deg2rad($lng2 - $lng1);
    $a = sin($dp / 2) ** 2 + cos($p1) * cos($p2) * sin($dl / 2) ** 2;
    return 2 * $r * asin(min(1.0, sqrt($a)));
}

function load_graph(): array
{
    $nodes = [];
    foreach (q('SELECT id, name, lat, lng, is_entry FROM path_nodes')->fetchAll() as $n) {
        $nodes[(int)$n['id']] = [
            'id' => (int)$n['id'], 'name' => $n['name'],
            'lat' => (float)$n['lat'], 'lng' => (float)$n['lng'], 'entry' => (int)$n['is_entry'] === 1,
        ];
    }
    $adj = array_fill_keys(array_keys($nodes), []);
    foreach (q('SELECT node_a, node_b FROM path_edges')->fetchAll() as $e) {
        $a = (int)$e['node_a'];
        $b = (int)$e['node_b'];
        if (!isset($nodes[$a], $nodes[$b])) continue;
        $d = haversine($nodes[$a]['lat'], $nodes[$a]['lng'], $nodes[$b]['lat'], $nodes[$b]['lng']);
        $adj[$a][$b] = $d;
        $adj[$b][$a] = $d;
    }
    return [$nodes, $adj];
}

function nearest_node(array $nodes, float $lat, float $lng): ?array
{
    $best = null;
    $bestD = INF;
    foreach ($nodes as $n) {
        $d = haversine($lat, $lng, $n['lat'], $n['lng']);
        if ($d < $bestD) {
            $bestD = $d;
            $best = $n;
        }
    }
    return $best ? $best + ['dist' => $bestD] : null;
}

/** Dijkstra. Returns the list of node ids from $from to $to, or null if unreachable. */
function shortest_path(array $adj, int $from, int $to): ?array
{
    if ($from === $to) return [$from];
    $dist = [$from => 0.0];
    $prev = [];
    $done = [];
    while (true) {
        $u = null;
        $best = INF;
        foreach ($dist as $id => $d) {
            if (!isset($done[$id]) && $d < $best) {
                $best = $d;
                $u = $id;
            }
        }
        if ($u === null) return null;
        if ($u === $to) break;
        $done[$u] = true;
        foreach ($adj[$u] ?? [] as $v => $w) {
            $nd = $dist[$u] + $w;
            if (!isset($dist[$v]) || $nd < $dist[$v]) {
                $dist[$v] = $nd;
                $prev[$v] = $u;
            }
        }
    }
    $path = [$to];
    while (isset($prev[$path[0]])) {
        array_unshift($path, $prev[$path[0]]);
    }
    return $path;
}

/**
 * Build a route to a location.
 * $lat/$lng = the user's GPS position (or null). Returns an array ready for JSON.
 */
function build_route(int $locationId, ?float $lat, ?float $lng): array
{
    $dest = location_by_id($locationId);
    if (!$dest) {
        return ['error' => 'That place is not in the campus directory.'];
    }
    if ($dest['lat'] === null) {
        return ['error' => $dest['name'] . ' does not have a map position yet. Ask an administrator to add it.'];
    }

    [$nodes, $adj] = load_graph();
    if (!$nodes) {
        return ['error' => 'The campus walkways have not been set up yet.'];
    }

    // Where does the walk start?
    $maxGps   = (float)cfg('campus.max_gps_distance', 1500);
    $campusLat = (float)cfg('campus.lat');
    $campusLng = (float)cfg('campus.lng');
    $onCampus = $lat !== null && $lng !== null
        && haversine($lat, $lng, $campusLat, $campusLng) <= $maxGps;

    $startLabel = 'Your location';
    $startNode  = null;
    $coords     = [];
    $gpsLeg     = 0.0;

    if ($onCampus) {
        $startNode = nearest_node($nodes, $lat, $lng);
        $coords[]  = [$lat, $lng];
        $gpsLeg    = $startNode['dist'];
    } else {
        foreach ($nodes as $n) {
            if ($n['entry']) { $startNode = $n; break; }
        }
        $startNode  = $startNode ?? reset($nodes);
        $startLabel = $startNode['name'];
    }

    // Where does the walk end?
    $endNode = $dest['node_id'] && isset($nodes[$dest['node_id']])
        ? $nodes[$dest['node_id']]
        : nearest_node($nodes, $dest['lat'], $dest['lng']);

    $ids = shortest_path($adj, $startNode['id'], $endNode['id']);
    $straight = false;
    if ($ids === null) {
        $ids = [$startNode['id'], $endNode['id']];
        $straight = true;
    }

    $total = $gpsLeg;
    $steps = [];
    $prevId = null;
    foreach ($ids as $i => $id) {
        $n = $nodes[$id];
        $coords[] = [$n['lat'], $n['lng']];
        if ($prevId !== null) {
            $seg = $adj[$prevId][$id] ?? haversine($nodes[$prevId]['lat'], $nodes[$prevId]['lng'], $n['lat'], $n['lng']);
            $total += $seg;
            if ($id !== $endNode['id']) {
                $steps[] = 'Walk about ' . round_m($seg) . ' to ' . $n['name'] . '.';
            } else {
                $steps[] = 'Walk about ' . round_m($seg) . ' to the ' . $n['name'] . '.';
            }
        }
        $prevId = $id;
    }

    if ($onCampus) {
        array_unshift($steps, 'Head to ' . $startNode['name'] . ' (about ' . round_m($gpsLeg) . ').');
    } else {
        array_unshift($steps, 'Start at the ' . $startNode['name'] . '. ' .
            ($lat !== null ? 'You seem to be away from campus, so the route begins at the entrance.' : 'Turn on location to start from where you are.'));
    }

    // Final leg: inside the building
    if ($dest['type'] !== 'building' && !empty($dest['parent_name'])) {
        $steps[] = 'Enter the ' . $dest['parent_name'] . '.';
        if ($dest['floor'] !== null && $dest['floor'] > 1) {
            $steps[] = 'Go up to the ' . ordinal($dest['floor']) . ' floor.';
        } elseif ($dest['floor'] === 1) {
            $steps[] = 'Stay on the ground floor.';
        }
        $steps[] = $dest['hint'] !== '' ? $dest['hint'] : 'Look for ' . $dest['name'] . '.';
    } elseif ($dest['type'] === 'building' || $dest['type'] === 'facility') {
        $steps[] = 'You have arrived at ' . $dest['name'] . '.';
    }

    $coords[] = [$dest['lat'], $dest['lng']];

    // Breadcrumb such as: Your location > CITE Building > 2nd floor > Room 601
    $crumbs = array_merge([$startLabel], $dest['path']);

    return [
        'ok'          => true,
        'destination' => location_public($dest),
        'breadcrumb'  => $crumbs,
        'coords'      => $coords,
        'distance_m'  => (int)round($total),
        'minutes'     => max(1, (int)ceil($total / (float)cfg('campus.walking_speed', 80))),
        'steps'       => $steps,
        'from_gps'    => $onCampus,
        'straight'    => $straight,
    ];
}

function round_m(float $m): string
{
    return max(10, (int)(round($m / 5) * 5)) . ' m';
}
