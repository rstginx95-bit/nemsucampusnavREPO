<?php
declare(strict_types=1);

/**
 * Reads student lists / staff rosters from CSV, Excel (.xlsx) and Word (.docx) files, with no extra libraries.
 * Files are parsed in memory and never executed. Size, type and ZIP content are checked first.
 */

const IMPORT_MAX_BYTES = 5 * 1024 * 1024;
const IMPORT_MAX_ROWS  = 5000;

function import_parse_file(string $tmp, string $name): array
{
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, ['csv', 'xlsx', 'docx'], true)) {
        throw new RuntimeException('Use a CSV, Excel (.xlsx) or Word (.docx) file.');
    }
    $size = (int)filesize($tmp);
    if ($size <= 0 || $size > IMPORT_MAX_BYTES) {
        throw new RuntimeException('The file is empty or larger than 5 MB.');
    }
    $head = (string)file_get_contents($tmp, false, null, 0, 4);
    if ($ext !== 'csv' && $head !== "PK\x03\x04") {
        throw new RuntimeException('That file is not a real ' . strtoupper($ext) . ' document.');
    }
    $rows = $ext === 'csv' ? import_csv($tmp) : ($ext === 'xlsx' ? import_xlsx($tmp) : import_docx($tmp));
    $rows = array_values(array_filter($rows, function ($r) {
        foreach ($r as $c) if (trim((string)$c) !== '') return true;
        return false;
    }));
    if (count($rows) < 2) {
        throw new RuntimeException('The file needs a header row and at least one data row.');
    }
    if (count($rows) > IMPORT_MAX_ROWS + 1) {
        throw new RuntimeException('Too many rows. The limit is ' . IMPORT_MAX_ROWS . ' per file.');
    }
    return $rows;
}

function import_clean(string $s): string
{
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $s) ?? '';
    if (!mb_check_encoding($s, 'UTF-8')) {
        $s = mb_convert_encoding($s, 'UTF-8', 'Windows-1252');
    }
    return trim(preg_replace('/\s+/u', ' ', $s) ?? '');
}

function import_csv(string $tmp): array
{
    $raw = (string)file_get_contents($tmp);
    $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw) ?? $raw;
    $firstLine = strtok($raw, "\n") ?: '';
    $delim = ',';
    foreach ([';', "\t", '|'] as $d) {
        if (substr_count($firstLine, $d) > substr_count($firstLine, $delim)) $delim = $d;
    }
    $fp = fopen('php://temp', 'r+');
    fwrite($fp, $raw);
    rewind($fp);
    $rows = [];
    while (($r = fgetcsv($fp, 0, $delim)) !== false) {
        $rows[] = array_map(fn($c) => import_clean((string)$c), $r);
        if (count($rows) > IMPORT_MAX_ROWS + 2) break;
    }
    fclose($fp);
    return $rows;
}

function import_zip_xml(ZipArchive $zip, string $entry): ?SimpleXMLElement
{
    $st = $zip->statName($entry);
    if (!$st || $st['size'] > 20 * 1024 * 1024) return null;      // guards against zip bombs
    $xml = $zip->getFromName($entry);
    if ($xml === false) return null;
    $prev = libxml_use_internal_errors(true);
    $doc = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOCDATA);
    libxml_use_internal_errors($prev);
    return $doc ?: null;
}

function import_col_index(string $ref): int
{
    $letters = preg_replace('/[^A-Z]/', '', strtoupper($ref));
    $n = 0;
    for ($i = 0; $i < strlen($letters); $i++) $n = $n * 26 + (ord($letters[$i]) - 64);
    return max(0, $n - 1);
}

function import_xlsx(string $tmp): array
{
    $zip = new ZipArchive();
    if ($zip->open($tmp) !== true || $zip->numFiles > 400) throw new RuntimeException('That Excel file could not be read.');
    $strings = [];
    if ($ss = import_zip_xml($zip, 'xl/sharedStrings.xml')) {
        foreach ($ss->si as $si) {
            $t = '';
            if (isset($si->t)) $t = (string)$si->t;
            foreach ($si->r as $r) $t .= (string)$r->t;
            $strings[] = import_clean($t);
        }
    }
    $sheet = null;
    for ($i = 1; $i <= 5 && !$sheet; $i++) $sheet = import_zip_xml($zip, "xl/worksheets/sheet$i.xml");
    if (!$sheet) throw new RuntimeException('No worksheet was found in that Excel file.');
    $rows = [];
    foreach ($sheet->sheetData->row as $row) {
        $cells = [];
        foreach ($row->c as $c) {
            $idx = import_col_index((string)$c['r']);
            $type = (string)$c['t'];
            $val = $type === 's' ? ($strings[(int)$c->v] ?? '') : ($type === 'inlineStr' ? import_clean((string)$c->is->t) : import_clean((string)$c->v));
            if ($type === '' && preg_match('/^\d+\.0$/', $val)) $val = substr($val, 0, -2);   // 12345.0 -> 12345
            $cells[$idx] = $val;
        }
        if ($cells) {
            $max = max(array_keys($cells));
            $line = [];
            for ($k = 0; $k <= $max; $k++) $line[] = $cells[$k] ?? '';
            $rows[] = $line;
        }
        if (count($rows) > IMPORT_MAX_ROWS + 2) break;
    }
    $zip->close();
    return $rows;
}

function import_docx(string $tmp): array
{
    $zip = new ZipArchive();
    if ($zip->open($tmp) !== true || $zip->numFiles > 400) throw new RuntimeException('That Word file could not be read.');
    $doc = import_zip_xml($zip, 'word/document.xml');
    $zip->close();
    if (!$doc) throw new RuntimeException('That Word file could not be read.');
    $doc->registerXPathNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
    $rows = [];
    $tables = $doc->xpath('//w:tbl');
    if ($tables) {
        foreach ($tables[0]->xpath('./w:tr') ?: [] as $tr) {
            $line = [];
            foreach ($tr->xpath('./w:tc') ?: [] as $tc) {
                $tc->registerXPathNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
                $parts = [];
                foreach ($tc->xpath('.//w:t') ?: [] as $t) $parts[] = (string)$t;
                $line[] = import_clean(implode(' ', $parts));
            }
            $rows[] = $line;
        }
        return $rows;
    }
    // No table: treat each paragraph as a row split by tabs, commas or runs of spaces.
    foreach ($doc->xpath('//w:p') ?: [] as $p) {
        $p->registerXPathNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
        $text = '';
        foreach ($p->xpath('.//w:t | .//w:tab') ?: [] as $n) $text .= $n->getName() === 'tab' ? "\t" : (string)$n;
        $text = trim($text);
        if ($text !== '') $rows[] = array_map('import_clean', preg_split('/\t+|\s{2,}|,/', $text) ?: []);
    }
    return $rows;
}

/* ---------------- column detection + row validation ---------------- */

function import_fields(string $target): array
{
    return $target === 'roster'
        ? ['employee_no' => 'Employee ID', 'full_name' => 'Full name', 'email' => 'Email address', 'department' => 'Department', 'role' => 'Role (instructor/staff)']
        : ['student_no' => 'Student ID', 'last_name' => 'Last name', 'first_name' => 'First name', 'full_name' => 'Full name', 'block' => 'Block / section'];
}

function import_guess_mapping(array $header, string $target): array
{
    $syn = $target === 'roster' ? [
        'employee_no' => ['employeeid', 'employeeno', 'employeenumber', 'empid', 'empno', 'id', 'idno', 'staffid'],
        'full_name'   => ['name', 'fullname', 'employeename', 'instructor', 'staffname'],
        'email'       => ['email', 'emailaddress', 'institutionalemail', 'nemsuemail'],
        'department'  => ['department', 'dept', 'office', 'college', 'unit'],
        'role'        => ['role', 'position', 'type', 'designation'],
    ] : [
        'student_no' => ['studentid', 'studentno', 'studentnumber', 'idnumber', 'idno', 'id', 'idnum', 'schoolid'],
        'last_name'  => ['lastname', 'surname', 'familyname', 'lname'],
        'first_name' => ['firstname', 'givenname', 'fname', 'firstnamemi'],
        'full_name'  => ['name', 'fullname', 'studentname', 'nameofstudent'],
        'block'      => ['block', 'section', 'blocksection', 'yearsection', 'class', 'course', 'sectioncode'],
    ];
    $map = [];
    foreach ($syn as $field => $names) {
        foreach ($header as $i => $h) {
            if (in_array(simplify((string)$h), $names, true) && !in_array($i, $map, true)) { $map[$field] = $i; break; }
        }
    }
    return $map;
}

function import_split_name(string $full): array
{
    $full = trim($full);
    if (str_contains($full, ',')) {
        [$last, $first] = array_map('trim', explode(',', $full, 2));
        return [$last, $first];
    }
    $parts = explode(' ', $full);
    if (count($parts) < 2) return [$full, ''];
    $last = array_pop($parts);
    return [$last, implode(' ', $parts)];
}

/** Turns raw rows into validated records with a status for each. */
function import_evaluate(array $rows, array $mapping, string $target, ?int $defaultBlock): array
{
    $out = [];
    $seen = [];
    $domain = '@' . strtolower((string)cfg('app.email_domain'));
    $blocks = [];
    foreach (q('SELECT id, code FROM sections')->fetchAll() as $b) $blocks[simplify($b['code'])] = (int)$b['id'];
    $get = fn(array $r, string $f) => isset($mapping[$f]) ? trim((string)($r[$mapping[$f]] ?? '')) : '';

    foreach (array_slice($rows, 1) as $n => $r) {
        $rec = ['line' => $n + 2, 'status' => 'ok', 'msg' => ''];
        if ($target === 'roster') {
            $rec['employee_no'] = strtoupper($get($r, 'employee_no'));
            $rec['full_name'] = $get($r, 'full_name');
            $rec['email'] = strtolower($get($r, 'email'));
            $rec['department'] = $get($r, 'department');
            $role = strtolower($get($r, 'role'));
            $rec['role'] = str_contains($role, 'staff') && !str_contains($role, 'instructor') ? 'staff' : 'instructor';
            $key = $rec['employee_no'];
            if (!preg_match('/^[A-Z0-9\-]{3,30}$/', $rec['employee_no'])) { $rec['status'] = 'invalid'; $rec['msg'] = 'Employee ID is missing or has odd characters'; }
            elseif ($rec['full_name'] === '' || $rec['department'] === '') { $rec['status'] = 'invalid'; $rec['msg'] = 'Name and department are required'; }
            elseif (!filter_var($rec['email'], FILTER_VALIDATE_EMAIL)) { $rec['status'] = 'invalid'; $rec['msg'] = 'Needs a valid email address'; }
            $exists = q('SELECT 1 FROM staff_roster WHERE employee_no = ? OR email = ?', [$rec['employee_no'], $rec['email']])->fetch();
        } else {
            $rec['student_no'] = strtoupper($get($r, 'student_no'));
            $last = $get($r, 'last_name'); $first = $get($r, 'first_name');
            if ($last === '' && $get($r, 'full_name') !== '') [$last, $first] = import_split_name($get($r, 'full_name'));
            $rec['last_name'] = $last; $rec['first_name'] = $first;
            $blk = $get($r, 'block');
            $rec['section_id'] = $blk !== '' ? ($blocks[simplify($blk)] ?? null) : $defaultBlock;
            if ($blk !== '' && $rec['section_id'] === null) { $rec['section_id'] = $defaultBlock; $rec['msg'] = 'Block "' . $blk . '" not found, default block used'; }
            $key = $rec['student_no'];
            if (!preg_match('/^[A-Z0-9\-]{4,30}$/', $rec['student_no'])) { $rec['status'] = 'invalid'; $rec['msg'] = 'Student ID is missing or has odd characters'; }
            elseif ($rec['last_name'] === '' || $rec['first_name'] === '') { $rec['status'] = 'invalid'; $rec['msg'] = 'Needs a first name and a last name'; }
            $exists = q('SELECT 1 FROM student_records WHERE student_no = ?', [$rec['student_no']])->fetch();
        }
        if ($rec['status'] === 'ok') {
            if (isset($seen[$key])) { $rec['status'] = 'duplicate'; $rec['msg'] = 'Appears twice in this file (first on line ' . $seen[$key] . ')'; }
            else { $seen[$key] = $rec['line']; if ($exists) { $rec['status'] = 'exists'; $rec['msg'] = 'Already in the system'; } }
        }
        $out[] = $rec;
    }
    return $out;
}
