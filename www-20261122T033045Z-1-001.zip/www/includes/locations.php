<?php
declare(strict_types=1);

/**
 * Locations: buildings, rooms, labs, offices and facilities.
 * Rooms inherit the building's coordinates and entrance node.
 */

const LOC_SELECT = 'SELECT l.*, p.name AS parent_name, p.lat AS p_lat, p.lng AS p_lng, p.node_id AS p_node
                      FROM locations l LEFT JOIN locations p ON p.id = l.parent_id';

function normalize_location(array $l): array
{
    $l['id']         = (int)$l['id'];
    $l['floor']      = $l['floor'] !== null ? (int)$l['floor'] : null;
    $l['lat']        = $l['lat'] !== null ? (float)$l['lat'] : ($l['p_lat'] !== null ? (float)$l['p_lat'] : null);
    $l['lng']        = $l['lng'] !== null ? (float)$l['lng'] : ($l['p_lng'] !== null ? (float)$l['p_lng'] : null);
    $l['node_id']    = $l['node_id'] !== null ? (int)$l['node_id'] : ($l['p_node'] !== null ? (int)$l['p_node'] : null);
    $l['building']   = $l['parent_name'] ?? ($l['type'] === 'building' ? $l['name'] : null);
    $l['path']       = location_path($l);
    unset($l['p_lat'], $l['p_lng'], $l['p_node']);
    return $l;
}

/** Breadcrumb such as ["CITE Building", "2nd floor", "Room 601"] */
function location_path(array $l): array
{
    $parts = [];
    if (!empty($l['parent_name'])) {
        $parts[] = $l['parent_name'];
        if ($l['floor'] !== null && $l['floor'] !== '') {
            $parts[] = ordinal((int)$l['floor']) . ' floor';
        }
    }
    $parts[] = $l['name'];
    return $parts;
}

function location_by_id(int $id): ?array
{
    $row = q(LOC_SELECT . ' WHERE l.id = ?', [$id])->fetch();
    return $row ? normalize_location($row) : null;
}

function all_locations(): array
{
    $rows = q(LOC_SELECT . ' ORDER BY FIELD(l.type, "building", "facility", "office", "lab", "room"), l.name')->fetchAll();
    return array_map('normalize_location', $rows);
}

/** Short text such as "Room 601, CITE Building (2nd floor)". */
function location_label(array $l): string
{
    if (!empty($l['parent_name'] ?? $l['building'] ?? null) && $l['type'] !== 'building') {
        $b = $l['parent_name'] ?? $l['building'];
        $f = $l['floor'] !== null ? ' (' . ordinal((int)$l['floor']) . ' floor)' : '';
        return $l['name'] . ', ' . $b . $f;
    }
    return $l['name'];
}

function simplify(string $s): string
{
    return preg_replace('/[^a-z0-9]+/', '', strtolower($s)) ?? '';
}

/**
 * How well does a location match a piece of text (a search query or a chat message)?
 * 0 = no match. Higher is better.
 */
function loc_score(array $l, string $text): int
{
    $t     = strtolower(trim($text));
    $tn    = simplify($text);
    $name  = strtolower($l['name']);
    $nameN = simplify($l['name']);
    $score = 0;

    if ($name !== '' && str_contains($t, $name)) {
        $score = 200 + strlen($name);
    } elseif ($nameN !== '' && str_contains($tn, $nameN)) {
        $score = 180 + strlen($nameN);
    }

    foreach (explode(',', (string)$l['keywords']) as $kw) {
        $kw = strtolower(trim($kw));
        if ($kw === '') continue;
        if (preg_match('/(?<![a-z0-9])' . preg_quote($kw, '/') . '(?![a-z0-9])/', $t)) {
            $score = max($score, 100 + strlen($kw));
        }
    }

    // Typing part of a name in the search box ("cite", "regis")
    if ($score === 0 && strlen($t) >= 2) {
        if (str_contains($name, $t)) {
            $score = 80;
        } elseif (str_contains(strtolower((string)$l['keywords']), $t)) {
            $score = 60;
        } elseif (!empty($l['parent_name']) && str_contains(strtolower($l['parent_name']), $t)) {
            $score = 40;
        }
    }
    return $score;
}

function search_locations(string $query, int $limit = 12): array
{
    $query = trim($query);
    $all = all_locations();
    if ($query === '') {
        return array_slice(array_values(array_filter($all, fn($l) => $l['type'] === 'building' || $l['type'] === 'facility')), 0, $limit);
    }
    $scored = [];
    foreach ($all as $l) {
        $s = loc_score($l, $query);
        if ($s > 0) {
            $l['score'] = $s;
            $scored[] = $l;
        }
    }
    usort($scored, fn($a, $b) => $b['score'] <=> $a['score'] ?: strcmp($a['name'], $b['name']));
    return array_slice($scored, 0, $limit);
}

/** Compact version safe to send to the browser. */
function location_public(array $l): array
{
    return [
        'id'       => $l['id'],
        'name'     => $l['name'],
        'type'     => $l['type'],
        'floor'    => $l['floor'],
        'building' => $l['building'],
        'path'     => $l['path'],
        'label'    => location_label($l),
        'desc'     => $l['description'],
        'hint'     => $l['hint'],
        'image'    => !empty($l['image_path']) ? 'uploads/locations/' . rawurlencode(basename((string)$l['image_path'])) : null,
        'lat'      => $l['lat'],
        'lng'      => $l['lng'],
    ];
}
