<?php
declare(strict_types=1);

require_once __DIR__ . '/app_review.php';
require_once __DIR__ . '/admin_accounts.php';

/**
 * Instructor / staff verification.
 * Nobody becomes staff by choosing a role. The server checks the applicant against the
 * administrator-maintained roster, and an administrator decides the rest.
 */

function norm_text(string $s): string
{
    return preg_replace('/[^a-z0-9]+/', '', mb_strtolower($s, 'UTF-8')) ?? '';
}

/**
 * Runs once the applicant's email is verified. The roster comparison is recorded for the Admin to read,
 * but it never blocks or grants anything: every application is queued for an administrator's decision.
 */
function staff_application_evaluate(int $userId): string
{
    $user = q('SELECT * FROM users WHERE id = ?', [$userId])->fetch();
    $app  = q('SELECT * FROM staff_applications WHERE user_id = ?', [$userId])->fetch();
    if (!$user || !$app || empty($user['email_verified_at'])) {
        return 'pending_email';
    }
    $roster = q('SELECT * FROM staff_roster WHERE email = ? AND active = 1', [strtolower($user['email'])])->fetch();
    $chkRoster = $roster ? 1 : 0;
    $chkEmp    = ($roster && strtoupper(trim($app['employee_no'])) === strtoupper(trim($roster['employee_no']))) ? 1 : 0;
    $chkDept   = ($roster && norm_text($app['department']) === norm_text($roster['department']) && norm_text($roster['department']) !== '') ? 1 : 0;
    $chkRole   = ($roster && $app['requested_role'] === $roster['role']) ? 1 : 0;
    q('UPDATE staff_applications SET roster_id = ?, chk_roster = ?, chk_employee = ?, chk_department = ?, chk_role = ?, chk_invite = 0, review_note = ? WHERE id = ?',
        [$roster['id'] ?? null, $chkRoster, $chkEmp, $chkDept, $chkRole, 'Awaiting administrator review.', $app['id']]);
    q("UPDATE users SET status = 'pending_admin' WHERE id = ? AND role = 'student'", [$userId]);
    audit('staff_app_queued', 'user', $userId, ($chkRoster && $chkEmp && $chkDept && $chkRole) ? 'roster match, awaiting administrator' : 'no full roster match, awaiting administrator', $userId);
    notify_admins('New instructor application', "A new instructor application is awaiting review.\n\nApplicant: " . $user['full_name']
        . "\nEmail: " . $user['email'] . "\nEmployee ID: " . $app['employee_no'] . "\nDepartment: " . $app['department']
        . "\nOfficial roster: " . ($chkRoster && $chkEmp && $chkDept && $chkRole ? 'matches' : 'no full match')
        . "\n\nReview it here: " . app_url('verification.php'));
    return 'pending_admin';
}

/** Grants the role. Only ever called by the automatic check (all gates passed) or by an administrator. */
function staff_approve(int $userId, ?int $adminId, string $note, bool $sendMail = true): void
{
    $user = q('SELECT * FROM users WHERE id = ?', [$userId])->fetch();
    $app  = q('SELECT * FROM staff_applications WHERE user_id = ?', [$userId])->fetch();
    if (!$user || !$app || empty($user['email_verified_at'])) {
        throw new RuntimeException('Cannot approve: email not verified.');
    }
    $role = $app['requested_role'];                       // 'instructor' or 'staff'; 'admin' can never be requested
    $insId = null;
    if ($role === 'instructor') {
        $ins = q('SELECT i.id FROM instructors i LEFT JOIN users u ON u.instructor_id = i.id
                   WHERE i.email = ? AND (u.id IS NULL OR u.id = ?)', [strtolower($user['email']), $userId])->fetch();
        if ($ins) {
            $insId = (int)$ins['id'];
        } else {
            $emp = $app['employee_no'];
            if (q('SELECT 1 FROM instructors WHERE employee_no = ?', [$emp])->fetch()) {
                $emp = $emp . '-' . $userId;
            }
            q('INSERT INTO instructors (employee_no, full_name, email, department) VALUES (?,?,?,?)',
                [$emp, $user['full_name'], strtolower($user['email']), $app['department']]);
            $insId = (int)db()->lastInsertId();
        }
    }
    q("UPDATE users SET role = ?, status = 'approved', instructor_id = ?, approved_by = ?, approved_at = NOW(), activated_at = NOW() WHERE id = ?",
        [$role, $insId, $adminId, $userId]);
    q('UPDATE staff_applications SET review_note = ?, reviewed_by = ?, reviewed_at = NOW() WHERE user_id = ?', [mb_substr($note, 0, 255), $adminId, $userId]);
    audit('role_granted', 'user', $userId, 'role=' . $role . ($adminId ? '' : ' (automatic)'), $adminId ?? $userId);
    if ($sendMail) {
        approval_email($userId);
    }
}

/** Tells an approved instructor they can sign in now. Approval itself already activated the account. */
function approval_email(int $userId, array $outstanding = []): bool
{
    $user = q('SELECT email, full_name FROM users WHERE id = ?', [$userId])->fetch();
    if (!$user) return false;
    $extra = $outstanding
        ? "\nNote: these items are still incomplete on file. Please give them to the administrator when you can:\n- " . implode("\n- ", $outstanding) . "\n"
        : '';
    $ok = send_mail($user['email'], 'Your NEMSU CampusNav AI instructor account is approved',
        "Hello " . $user['full_name'] . ",\n\nYour instructor account was approved. You can sign in now:\n\n" . app_url('instructor-login.php') . "\n" . $extra, 'app_approved');
    audit('approval_email', 'user', $userId, mail_last()['status'], $userId);
    return $ok;
}

/** @param string[] $outstanding requirements still incomplete when an Admin approved as an exception */
function activation_send(int $userId, array $outstanding = []): bool
{
    $user = q('SELECT email, full_name FROM users WHERE id = ?', [$userId])->fetch();
    if (!$user) return false;
    $token = link_token_issue($userId, 'activate', (int)cfg('security.activation_ttl_hours', 48) * 3600);
    $extra = $outstanding
        ? "\nNote: your application was approved, but these items are still incomplete on file. Please provide them to the administrator when you can:\n- " . implode("\n- ", $outstanding) . "\n"
        : '';
    $ok = send_mail($user['email'], 'Activate your NEMSU CampusNav AI staff account',
        "Hello " . $user['full_name'] . ",\n\nYour instructor/staff account was approved.\n" . $extra
        . "To finish, open this link and confirm your password. It works once and expires in "
        . (int)cfg('security.activation_ttl_hours', 48) . " hours:\n\n" . app_url('activate.php?token=' . $token)
        . "\n\nIf you did not apply for this account, ignore this email.\n", 'app_approved');
    audit('activation_sent', 'user', $userId, mail_last()['status'], $userId);
    return $ok;
}

function staff_reject(int $userId, int $adminId, string $note, bool $sendMail = true): void
{
    $user = q('SELECT email, full_name FROM users WHERE id = ?', [$userId])->fetch();
    q("UPDATE users SET status = 'rejected', role = 'student', instructor_id = NULL, activated_at = NULL WHERE id = ?", [$userId]);
    q('UPDATE staff_applications SET review_note = ?, reviewed_by = ?, reviewed_at = NOW() WHERE user_id = ?', [mb_substr($note, 0, 255), $adminId, $userId]);
    audit('staff_rejected', 'user', $userId, mb_substr($note, 0, 200), $adminId);
    if ($user && $sendMail) {
        send_mail($user['email'], 'Your NEMSU CampusNav AI application',
            "Hello " . $user['full_name'] . ",\n\nWe could not approve your instructor/staff application at this time.\n"
            . "If you think this is a mistake, please contact your department or the system administrator.\n");
    }
}

function staff_request_more(int $userId, int $adminId, string $note, bool $sendMail = true): void
{
    $user = q('SELECT email, full_name FROM users WHERE id = ?', [$userId])->fetch();
    q("UPDATE users SET status = 'pending_identity' WHERE id = ? AND role = 'student'", [$userId]);
    q('UPDATE staff_applications SET review_note = ?, reviewed_by = ?, reviewed_at = NOW() WHERE user_id = ?', [mb_substr($note, 0, 255), $adminId, $userId]);
    audit('staff_more_info', 'user', $userId, mb_substr($note, 0, 200), $adminId);
    if ($user && $sendMail) {
        send_mail($user['email'], 'More information needed for your NEMSU CampusNav AI application',
            "Hello " . $user['full_name'] . ",\n\nWe need a little more information to complete your application.\n"
            . "Please contact the system administrator or your department head.\n");
    }
}

/** Revoke: the account can no longer sign in. The role is removed. */
function staff_revoke(int $userId, int $adminId, string $note): void
{
    q("UPDATE users SET status = 'suspended', role = 'student', instructor_id = NULL, activated_at = NULL WHERE id = ? AND id <> ?", [$userId, $adminId]);
    audit('access_revoked', 'user', $userId, mb_substr($note, 0, 200), $adminId);
}

/** Bulk approve: ONLY applications whose every roster check passed and whose email is verified. */
function staff_bulk_approve(int $adminId): int
{
    $rows = q("SELECT a.user_id FROM staff_applications a JOIN users u ON u.id = a.user_id
                WHERE u.status = 'pending_admin' AND u.email_verified_at IS NOT NULL
                  AND a.chk_roster = 1 AND a.chk_employee = 1 AND a.chk_department = 1 AND a.chk_role = 1")->fetchAll();
    foreach ($rows as $r) {
        staff_approve((int)$r['user_id'], $adminId, 'Bulk approval: matched the official roster.');
        try { decision_record((int)$r['user_id'], $adminId, 'approved', [], 'Bulk approval: matched the official roster.'); } catch (Throwable $e) { /* migration 002 pending */ }
    }
    audit('bulk_approve', 'user', null, count($rows) . ' application(s)', $adminId);
    return count($rows);
}
