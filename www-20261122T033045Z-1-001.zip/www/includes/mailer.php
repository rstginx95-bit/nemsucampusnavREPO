<?php

/**
 * NEMSU CampusNav AI Mailer
 *
 * All recipients use the configured transport: explicit local log mode or real SMTP.
 */

/**
 * Sends one email and records the attempt in email_log.
 * Return value true means: "the configured transport accepted the message" - for SMTP that is the mail
 * server accepting it (NOT proof it reached the inbox); in log mode nothing is delivered at all.
 * Use mail_last() / mail_outcome_text() right after a call to tell the user the truth.
 */
function send_mail(
    string $to,
    string $subject,
    string $text,
    string $purpose = ''
): bool {
    $to = trim($to);
    $GLOBALS['CN_MAIL_LAST'] = ['status' => 'failed', 'error' => ''];

    if (
        !filter_var($to, FILTER_VALIDATE_EMAIL) ||
        preg_match('/[\r\n]/', $subject)
    ) {
        return mail_finish($to, $subject, $purpose, 'failed', 'Invalid recipient address or subject.');
    }

    $mail = cfg('mail', []);

    // Log mode is explicit and applies to every recipient. SMTP mode always attempts real delivery.
    if (($mail['transport'] ?? 'log') === 'log') {
        $ok = developer_mail_log($to, $subject, $text);
        return mail_finish($to, $subject, $purpose, $ok ? 'logged_locally' : 'failed', $ok ? '' : 'Cannot write database/mail.log.');
    }
    if (($mail['transport'] ?? '') !== 'smtp') {
        return mail_finish($to, $subject, $purpose, 'failed', 'Unsupported mail transport.');
    }

    if (
        empty($mail['host']) ||
        empty($mail['user']) ||
        empty($mail['pass']) ||
        empty($mail['from'])
    ) {
        return mail_finish($to, $subject, $purpose, 'failed', 'SMTP settings are incomplete (see config.local.php).');
    }

    try {
        $ok = smtp_send($mail, $to, $subject, $text);
        return mail_finish($to, $subject, $purpose, $ok ? 'accepted_by_smtp' : 'failed', $ok ? '' : 'SMTP send returned false.');
    } catch (Throwable $e) {
        error_log('SMTP error: ' . $e->getMessage());
        return mail_finish($to, $subject, $purpose, 'failed', $e->getMessage());   // messages never contain the password
    }
}

/** Records the outcome (email_log + $GLOBALS) and returns whether the transport accepted the message. */
function mail_finish(string $to, string $subject, string $purpose, string $status, string $error): bool
{
    $GLOBALS['CN_MAIL_LAST'] = ['status' => $status, 'error' => mb_substr($error, 0, 255)];
    try {
        q('INSERT INTO email_log (to_email, subject, purpose, status, error) VALUES (?,?,?,?,?)',
            [mb_substr($to, 0, 190), mb_substr($subject, 0, 190), mb_substr($purpose, 0, 40), $status, mb_substr($error, 0, 255)]);
    } catch (Throwable $e) {
        // email_log does not exist until migration 002 is applied; logging must never break sending.
    }
    return $status !== 'failed';
}

/** Outcome of the most recent send_mail() call in this request. */
function mail_last(): array
{
    return $GLOBALS['CN_MAIL_LAST'] ?? ['status' => 'failed', 'error' => 'No email was attempted.'];
}

/** Honest, user-facing wording for an outcome. */
function mail_outcome_text(array $last): string
{
    switch ($last['status'] ?? '') {
        case 'accepted_by_smtp':
            return 'The email was accepted by the mail server (this does not guarantee it reached the inbox).';
        case 'logged_locally':
            return 'Email is in log mode, so nothing was actually sent. The text is in database/mail.log.';
        default:
            return 'The email could NOT be sent' . (!empty($last['error']) ? ' (' . $last['error'] . ')' : '') . '. The decision itself was saved.';
    }
}

/**
 * Save an email locally only when the configured transport is explicitly 'log'.
 */
function developer_mail_log(
    string $to,
    string $subject,
    string $text
): bool {
    $file = CN_ROOT . '/database/mail.log';
    $txt_file = CN_ROOT . '/database/codes.txt';
    @file_put_contents($txt_file, "---- " . date('c') . " ----\nTo: $to\nSubject: $subject\n\n$text\n\n", FILE_APPEND | LOCK_EX);

    $message =
        "---- " . date('c') . " ----\n" .
        "To: " . $to . "\n" .
        "Subject: " . $subject . "\n\n" .
        $text . "\n\n";

    $written = @file_put_contents(
        $file,
        $message,
        FILE_APPEND | LOCK_EX
    );

    if ($written === false) {
        error_log('Cannot write Developer mail log.');
        return false;
    }

    @chmod($file, 0600);

    return true;
}

/**
 * Read SMTP response.
 */
function smtp_read($connection): array {
    $code = 0;
    $response = '';

    while (
        ($line = fgets($connection, 515)) !== false
    ) {
        $response .= $line;
        $code = (int)substr($line, 0, 3);

        if (isset($line[3]) && $line[3] === ' ') {
            break;
        }
    }

    return [$code, $response];
}

/**
 * Send SMTP command and verify response.
 */
function smtp_cmd(
    $connection,
    string $command,
    array $expected
): void {
    if (
        fwrite(
            $connection,
            $command . "\r\n"
        ) === false
    ) {
        throw new RuntimeException(
            'SMTP write failed.'
        );
    }

    [$code] = smtp_read($connection);

    if (!in_array($code, $expected, true)) {
        throw new RuntimeException(
            'SMTP rejected command. Status: ' . $code
        );
    }
}

/**
 * Send real email via SMTP.
 */
function smtp_send(
    array $mail,
    string $to,
    string $subject,
    string $text
): bool {
    $host = (string)$mail['host'];
    $port = (int)$mail['port'];
    $secure = (string)$mail['secure'];

    $remote = (
        $secure === 'ssl' ? 'ssl://' : ''
    ) . $host;

    $connection = @stream_socket_client(
        $remote . ':' . $port,
        $errno,
        $error,
        15
    );

    if (!$connection) {
        throw new RuntimeException(
            'SMTP connection failed: ' . $error
        );
    }

    try {
        stream_set_timeout($connection, 15);

        [$code] = smtp_read($connection);

        if ($code !== 220) {
            throw new RuntimeException(
                'SMTP greeting failed.'
            );
        }

        $serverName = preg_replace(
            '/[^a-z0-9.\-]/i',
            '',
            $_SERVER['SERVER_NAME'] ?? 'localhost'
        ) ?: 'localhost';

        smtp_cmd(
            $connection,
            'EHLO ' . $serverName,
            [250]
        );

        if ($secure === 'tls') {
            smtp_cmd(
                $connection,
                'STARTTLS',
                [220]
            );

            if (
                !stream_socket_enable_crypto(
                    $connection,
                    true,
                    STREAM_CRYPTO_METHOD_TLS_CLIENT
                )
            ) {
                throw new RuntimeException(
                    'SMTP TLS failed.'
                );
            }

            smtp_cmd(
                $connection,
                'EHLO ' . $serverName,
                [250]
            );
        }

        smtp_cmd($connection, 'AUTH LOGIN', [334]);

        smtp_cmd(
            $connection,
            base64_encode((string)$mail['user']),
            [334]
        );

        smtp_cmd(
            $connection,
            base64_encode((string)$mail['pass']),
            [235]
        );

        $from = (string)$mail['from'];

        if (!filter_var($from, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException(
                'Invalid sender email.'
            );
        }

        smtp_cmd(
            $connection,
            'MAIL FROM:<' . $from . '>',
            [250]
        );

        smtp_cmd(
            $connection,
            'RCPT TO:<' . $to . '>',
            [250, 251]
        );

        smtp_cmd(
            $connection,
            'DATA',
            [354]
        );

        $fromName = preg_replace(
            '/[\r\n"]/',
            '',
            (string)($mail['from_name'] ?? 'NEMSU CampusNav AI')
        );

        $headers =
            'From: "' . $fromName . '" <' . $from . ">\r\n" .
            'To: <' . $to . ">\r\n" .
            'Subject: =?UTF-8?B?' .
            base64_encode($subject) .
            "?=\r\n" .
            'Date: ' . date('r') . "\r\n" .
            "MIME-Version: 1.0\r\n" .
            "Content-Type: text/plain; charset=UTF-8\r\n" .
            "Content-Transfer-Encoding: base64\r\n";

        $body = chunk_split(base64_encode($text));

        $payload =
            $headers .
            "\r\n" .
            $body .
            "\r\n.\r\n";

        if (fwrite($connection, $payload) === false) {
            throw new RuntimeException(
                'SMTP message write failed.'
            );
        }

        [$resultCode] = smtp_read($connection);

        if ($resultCode !== 250) {
            throw new RuntimeException(
                'SMTP did not accept the email.'
            );
        }

        smtp_cmd(
            $connection,
            'QUIT',
            [221]
        );

        return true;

    } finally {
        fclose($connection);
    }
}

/**
 * Notify active, approved administrators.
 */
function notify_admins(
    string $subject,
    string $text
): void {
    $admins = q(
        "SELECT email
         FROM users
         WHERE role = 'admin'
           AND status = 'approved'"
    )->fetchAll(PDO::FETCH_ASSOC);

    foreach ($admins as $admin) {
        send_mail(
            $admin['email'],
            $subject,
            $text
        );
    }
}
