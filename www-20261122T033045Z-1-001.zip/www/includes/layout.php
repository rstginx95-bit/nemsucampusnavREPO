<?php
declare(strict_types=1);

function icon(string $name, string $class = 'ic'): string
{
    return '<svg class="' . e($class) . '" aria-hidden="true"><use href="#i-' . e($name) . '"/></svg>';
}

function nav_items(): array
{
    return [
        'home'     => ['Home', 'home.php', 'home'],
        'map'      => ['Map', 'map.php', 'map'],
        'schedule' => ['Schedule', 'schedule.php', 'calendar'],
        'calendar' => ['Calendar', 'calendar.php', 'cal'],
        'ai'       => ['Ask AI', 'ai.php', 'ai'],
    ];
}

function mode_label(array $u): string
{
    if (!empty($u['preview'])) return 'Administrator, previewing ' . ucfirst($u['preview']);
    switch ($u['mode']) {
        case 'admin':      return $u['role'] === 'admin' ? 'Administrator' : 'Staff';
        case 'instructor': return $u['role'] === 'admin' ? 'Administrator / Instructor' : 'Instructor';
        case 'student':    return 'Student' . (!empty($u['section_code']) ? ', ' . $u['section_code'] : '');
        case 'pending':    return 'Student (ID not verified)';
        case 'blocked':    return 'Account not active yet';
        default:
            $t = ['freshman' => 'Freshman', 'transferee' => 'Transferee'][$u['student_type'] ?? ''] ?? 'Guest';
            return $t . ' (map and AI)';
    }
}

/** Where a signed-in user must be sent before using the app. Null = they may continue. */
function flow_redirect(array $u, string $active): ?string
{
    if ($u['mode'] === 'blocked') {
        return empty($u['email_verified_at']) ? 'verify-email.php' : 'status.php';
    }
    if (!$u['profile_done'] && $active !== 'onboarding') {
        return 'onboarding.php';
    }
    if ($u['mode'] === 'pending' && !in_array($active, ['onboarding', 'account'], true)) {
        return 'onboarding.php?step=id';
    }
    return null;
}

function pending_application_count(): int
{
    try {
        // Same rule as the Applications tab, so the badge, the Manage card and the list always agree.
        return (int)q("SELECT COUNT(*) FROM users u JOIN staff_applications a ON a.user_id = u.id
                        WHERE u.status IN ('pending_admin','pending_identity') AND u.email_verified_at IS NOT NULL")->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

function theme_toggle(): string
{
    return '<button type="button" class="theme" data-theme-toggle aria-pressed="false" aria-label="Switch theme">'
         . '<span class="knob"><svg class="sun"><use href="#i-sun"/></svg><svg class="moon"><use href="#i-moon"/></svg></span></button>';
}

/**
 * Opens an app page. $active is one of: home, map, schedule, calendar, ai, account, admin.
 * $opts: bleed (full-height pages), leaflet (load Leaflet), gmaps (load Google Maps)
 */
function render_head(string $title, string $active, array $opts = []): void
{
    $u = require_login();
    if ($to = flow_redirect($u, $active)) {
        redirect($to);
    }
    $bleed   = !empty($opts['bleed']);
    $guest   = $u['mode'] === 'guest';
    $initial = strtoupper(substr(first_name($u), 0, 1));
    $opts['fx'] = $opts['fx'] ?? !$bleed;
    page_open($title, 'page-' . $active . ($bleed ? ' is-bleed' : ''), $opts, $u);
    ?>
<div class="shell">
  <aside class="sidebar" aria-label="Main navigation">
    <a class="brand" href="home.php">
      <span class="brand-mark" aria-hidden="true"><?= icon('nav') ?></span>
      <span class="brand-name">NEMSU CampusNav AI</span>
    </a>
    <nav class="side-nav">
      <?php foreach (nav_items() as $key => [$label, $href, $ic]): ?>
        <a href="<?= e($href) ?>" class="<?= $active === $key ? 'is-active' : '' ?>"<?= $active === $key ? ' aria-current="page"' : '' ?>>
          <?= icon($ic) ?><span><?= e($label) ?></span>
        </a>
      <?php endforeach; ?>
      <a href="settings.php" class="<?= $active === 'account' ? 'is-active' : '' ?>"><?= icon('user') ?><span>Settings</span></a>
      <?php if (is_staff($u) && ($u['preview'] ?? '') !== 'student'): ?>
        <a href="admin.php" class="<?= $active === 'admin' ? 'is-active' : '' ?>"><?= icon('shield') ?><span>Manage</span></a>
      <?php endif; ?>
      <?php if (is_admin($u) && empty($u['preview'])): ?>
        <a href="import.php" class="<?= $active === 'import' ? 'is-active' : '' ?>"><?= icon('upload') ?><span>Import students</span></a>
      <?php endif; ?>
      <?php if (is_admin($u) && empty($u['preview'])): $pc = pending_application_count(); ?>
        <a href="verification.php" class="<?= $active === 'verification' ? 'is-active' : '' ?>"><?= icon('shieldcheck') ?><span>Verification</span><?php if ($pc): ?><b class="badge"><?= $pc ?></b><?php endif; ?></a>
      <?php endif; ?>
      <?php if (is_admin($u)): ?>
        <a href="switch-dashboard.php" class="<?= $active === 'switch' ? 'is-active' : '' ?>"><?= icon('users') ?><span>Switch dashboard</span></a>
      <?php endif; ?>
    </nav>
    <div class="side-theme"><span>Theme</span><?= theme_toggle() ?></div>
    <?php if ($guest): ?>
      <a class="side-promo" href="settings.php#verify">
        <?= icon('idcard') ?>
        <span><strong>Enrolled already?</strong><small>Add your Student ID to unlock your schedule.</small></span>
      </a>
    <?php endif; ?>
    <div class="side-user">
      <div class="avatar"><?= e($initial) ?></div>
      <div class="side-user-text">
        <strong><?= e($u['full_name']) ?></strong>
        <span><?= e(mode_label($u)) ?></span>
      </div>
    </div>
  </aside>

  <div class="main">
    <header class="topbar">
      <a class="topbar-brand" href="home.php"><span class="brand-mark" aria-hidden="true"><?= icon('nav') ?></span>NEMSU CampusNav AI</a>
      <div class="topbar-actions">
        <?= theme_toggle() ?>
        <?php if (is_admin($u)): ?>
          <a class="icon-pill icon-pill-quiet" href="switch-dashboard.php" aria-label="Switch dashboard"><?= icon('users') ?></a>
        <?php endif; ?>
        <?php if (is_staff($u) && ($u['preview'] ?? '') !== 'student'): ?>
          <a class="icon-pill icon-pill-quiet" href="<?= is_admin($u) && empty($u['preview']) ? 'verification.php' : 'admin.php' ?>" aria-label="Manage"><?= icon('shield') ?></a>
        <?php endif; ?>
        <?php if ($guest): ?>
          <a class="icon-pill" href="settings.php#verify" aria-label="Add your Student ID">
            <?= icon('idcard') ?><span class="dot" aria-hidden="true"></span>
          </a>
        <?php endif; ?>
        <a class="avatar avatar-link" href="settings.php" aria-label="Account"><?= e($initial) ?></a>
      </div>
    </header>
    <main class="content<?= $bleed ? ' content-bleed' : '' ?>" id="content">
      <?php if (!empty($u['preview'])): ?>
        <div class="preview-bar" role="status">
          <span><?= icon('eye') ?> <strong>Administrator preview.</strong> You are viewing the <?= e(ucfirst($u['preview'])) ?> dashboard. Your account is still Administrator.</span>
          <form method="post" action="switch-dashboard.php"><?= csrf_field() ?><input type="hidden" name="target" value="admin"><button class="btn btn-primary btn-small" type="submit">Return to Admin Dashboard</button></form>
        </div>
      <?php endif; ?>
      <div class="toasts" id="toasts" aria-live="polite">
        <?php foreach (take_flashes() as $f): ?>
          <div class="toast toast-<?= e($f['type']) ?>" role="status"><?= e($f['message']) ?></div>
        <?php endforeach; ?>
      </div>
<?php
}

function render_foot(string $active, array $scripts = []): void
{
    ?>
    </main>
  </div>

  <nav class="tabbar" aria-label="Main navigation">
    <?php foreach (nav_items() as $key => [$label, $href, $ic]): ?>
      <a href="<?= e($href) ?>" class="<?= $active === $key ? 'is-active' : '' ?>"<?= $active === $key ? ' aria-current="page"' : '' ?>>
        <?= icon($ic) ?><span><?= e($label) ?></span>
      </a>
    <?php endforeach; ?>
  </nav>
</div>
<script src="assets/js/app.js?v=4"></script>
<?php foreach ($scripts as $s): ?>
<script src="<?= e($s) ?>"></script>
<?php endforeach; ?>
</body>
</html>
<?php
}

/** <head> + opening <body> + icon sprite. Shared by app pages and the sign-in / onboarding pages. */
function page_open(string $title, string $bodyClass, array $opts = [], ?array $u = null): void
{
    ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0f3d2e">
<script>try{var t=localStorage.getItem('cn-theme');if(t==='light'||t==='dark'){document.documentElement.setAttribute('data-theme',t);}}catch(e){}</script>
<meta name="color-scheme" content="light dark">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="NEMSU CampusNav AI">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<title><?= e($title) ?> - <?= e(cfg('app.name')) ?></title>
<link rel="manifest" href="manifest.json">
<link rel="icon" href="assets/icons/icon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="assets/icons/icon-192.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500..800&family=Instrument+Sans:wght@400..700&display=swap">
<?php if (!empty($opts['leaflet'])): ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<?php endif; ?>
<link rel="stylesheet" href="assets/css/app.css?v=4">
</head>
<body class="<?= e($bodyClass) ?><?= !empty($opts['fx']) ? ' has-fx' : '' ?>" data-csrf="<?= e(csrf_token()) ?>">
<?php render_sprite(); ?>
<?php if (!empty($opts['fx'])): ?><canvas id="fx" aria-hidden="true"></canvas><div class="glow" aria-hidden="true"></div><?php endif; ?>
<?php
}

function render_sprite(): void
{
    ?>
<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">
  <defs>
    <symbol id="i-home" viewBox="0 0 24 24"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/></symbol>
    <symbol id="i-map" viewBox="0 0 24 24"><path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2z"/><path d="M9 4v14M15 6v14"/></symbol>
    <symbol id="i-calendar" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/></symbol>
    <symbol id="i-cal" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="17" rx="3"/><path d="M3 9h18M8 2.5v3M16 2.5v3"/><path d="M8 13h2M14 13h2M8 17h2M14 17h2"/></symbol>
    <symbol id="i-ai" viewBox="0 0 24 24"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M18.5 16l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7z"/></symbol>
    <symbol id="i-user" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/></symbol>
    <symbol id="i-nav" viewBox="0 0 24 24"><path d="M4 11l16-7-7 16-2-7z"/></symbol>
    <symbol id="i-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></symbol>
    <symbol id="i-pin" viewBox="0 0 24 24"><path d="M12 21s7-6.2 7-12a7 7 0 10-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="9" r="2.5"/></symbol>
    <symbol id="i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></symbol>
    <symbol id="i-lock" viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/></symbol>
    <symbol id="i-chevron" viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></symbol>
    <symbol id="i-chevron-left" viewBox="0 0 24 24"><path d="M15 6l-6 6 6 6"/></symbol>
    <symbol id="i-x" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></symbol>
    <symbol id="i-send" viewBox="0 0 24 24"><path d="M12 19V5M5 12l7-7 7 7"/></symbol>
    <symbol id="i-target" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="8"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></symbol>
    <symbol id="i-shield" viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 4.5-3.2 7.8-8 9-4.8-1.2-8-4.5-8-9V6z"/></symbol>
    <symbol id="i-logout" viewBox="0 0 24 24"><path d="M9 4H5a2 2 0 00-2 2v12a2 2 0 002 2h4M16 8l4 4-4 4M20 12H9"/></symbol>
    <symbol id="i-alert" viewBox="0 0 24 24"><path d="M12 3l9 16H3z"/><path d="M12 10v4M12 17v.5"/></symbol>
    <symbol id="i-user-check" viewBox="0 0 24 24"><circle cx="9" cy="8" r="4"/><path d="M2 21c1-4 3.5-6 7-6s6 2 7 6M16 11l2 2 4-4"/></symbol>
    <symbol id="i-idcard" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="11" r="2"/><path d="M6 16c.5-1.5 1.7-2.2 3-2.2s2.5.7 3 2.2M14.5 10h4M14.5 13h3"/></symbol>
    <symbol id="i-check" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></symbol>
    <symbol id="i-external" viewBox="0 0 24 24"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 01-1 1H5a1 1 0 01-1-1V7a1 1 0 011-1h5"/></symbol>
    <symbol id="i-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/></symbol>
    <symbol id="i-moon" viewBox="0 0 24 24"><path d="M20 14.5A8 8 0 019.5 4 8 8 0 1020 14.5z"/></symbol>
    <symbol id="i-eye" viewBox="0 0 24 24"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></symbol>
    <symbol id="i-upload" viewBox="0 0 24 24"><path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 001 1h14a1 1 0 001-1v-3"/></symbol>
    <symbol id="i-file" viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></symbol>
    <symbol id="i-mail" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 8l9 6 9-6"/></symbol>
    <symbol id="i-users" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2 20c.8-3.5 3.3-5 7-5s6.2 1.5 7 5M16 5a3.5 3.5 0 010 7M18 15c2 .5 3.3 2 4 5"/></symbol>
    <symbol id="i-shieldcheck" viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 4.5-3.2 7.8-8 9-4.8-1.2-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/></symbol>
  </defs>
</svg>
<?php
}

/** Warning-sign list shown under the sign-in forms. */
function render_safety_notes(bool $staff = false): void
{
    ?>
<aside class="warnings" aria-label="Safety reminders">
  <h2><?= icon('alert') ?> Before you continue</h2>
  <ul>
    <li><?= icon('shieldcheck') ?><span>Use an email address you can access. Never share your password or one-time codes with anyone, including friends and classmates.</span></li>
    <?php if ($staff): ?>
      <li><?= icon('lock') ?><span>Staff access is checked against the official staff roster. Choosing a role does not grant it, and every sign in needs an emailed code.</span></li>
    <?php else: ?>
      <li><?= icon('idcard') ?><span>Old students and transferees must verify a valid NEMSU Student ID. A wrong or borrowed ID will not unlock any schedule.</span></li>
      <li><?= icon('map') ?><span>Freshmen can use the map and the AI assistant right away. Add your Student ID after you enroll to unlock your class schedule.</span></li>
    <?php endif; ?>
    <li><?= icon('alert') ?><span>Class schedules come from the official records. If something looks wrong, ask your instructor or the Registrar. CampusNav AI does not change grades or enrollment.</span></li>
  </ul>
</aside>
<?php
}
