<?php
declare(strict_types=1);

/** Shared frame for every sign-in / registration / verification screen (new glass design + background effects). */

function auth_start(string $title, bool $staff = false, string $wide = ''): void
{
    page_open($title, 'page-auth' . ($staff ? ' portal-staff' : ''), ['fx' => true]);
    ?>
<main class="stage<?= $wide ? ' ' . e($wide) : '' ?>">
  <header class="top enter">
    <a class="brand hu" href="index.php"><span class="mark"><?= icon('nav') ?></span>NEMSU CampusNav AI</a>
    <?= theme_toggle() ?>
  </header>
<?php
}

function auth_end(array $extraScripts = []): void
{
    ?>
</main>
<script src="assets/js/app.js?v=4"></script>
<?php foreach ($extraScripts as $s): ?><script src="<?= e($s) ?>"></script><?php endforeach; ?>
</body>
</html>
<?php
}

function auth_errors(array $errors): void
{
    foreach ($errors as $err): ?>
      <div class="notice notice-error" role="alert"><?= icon('alert') ?><div><?= e($err) ?></div></div>
    <?php endforeach;
    foreach (take_flashes() as $f): ?>
      <div class="notice notice-<?= $f['type'] === 'error' ? 'error' : 'ok' ?>" role="status"><?= icon($f['type'] === 'error' ? 'alert' : 'check') ?><div><?= e($f['message']) ?></div></div>
    <?php endforeach;
}

/** Only allow redirects to pages inside this app. */
function safe_next(string $next, string $fallback): string
{
    return preg_match('/^[a-z0-9\-]+\.php(\?[A-Za-z0-9_=&%.\-]*)?$/', $next) ? $next : $fallback;
}
