<?php
declare(strict_types=1);

/** Secret used to key the hashes of one-time codes. Generated once and kept in database/app.key (never in Git). */
function app_key(): string
{
    static $key = null;
    if ($key !== null) return $key;
    $file = CN_ROOT . '/database/app.key';
    if (is_file($file) && strlen((string)file_get_contents($file)) >= 32) {
        return $key = trim((string)file_get_contents($file));
    }
    $key = bin2hex(random_bytes(32));
    if (@file_put_contents($file, $key, LOCK_EX) === false) {
        throw new RuntimeException('database/app.key cannot be written. Make the database folder writable.');
    }
    @chmod($file, 0600);
    return $key;
}

function token_hash(string $token): string
{
    return hash_hmac('sha256', $token, app_key());
}

function new_token(): string
{
    return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
}

/* ---------------- one-time email codes ---------------- */

/** Creates a 6-digit single-use code, invalidating older ones for the same purpose. Returns the plain code ONCE. */
function otp_issue(int $userId, string $purpose): string
{
    q('UPDATE otp_codes SET used_at = NOW() WHERE user_id = ? AND purpose = ? AND used_at IS NULL', [$userId, $purpose]);
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    q('INSERT INTO otp_codes (user_id, purpose, code_hash, expires_at) VALUES (?,?,?, DATE_ADD(NOW(), INTERVAL ? SECOND))',
        [$userId, $purpose, token_hash($userId . ':' . $purpose . ':' . $code), (int)cfg('security.otp_ttl', 600)]);
    return $code;
}

/** true = code correct (and now used up). Limits wrong guesses per code and per user. */
function otp_check(int $userId, string $purpose, string $code): bool
{
    $code = preg_replace('/\D/', '', $code);
    if (strlen($code) !== 6) return false;
    $row = q('SELECT id, code_hash, attempts FROM otp_codes
               WHERE user_id = ? AND purpose = ? AND used_at IS NULL AND expires_at > NOW()
               ORDER BY id DESC LIMIT 1', [$userId, $purpose])->fetch();
    if (!$row || (int)$row['attempts'] >= (int)cfg('security.otp_max_attempts', 5)) return false;
    $ok = hash_equals($row['code_hash'], token_hash($userId . ':' . $purpose . ':' . $code));
    if ($ok) {
        q('UPDATE otp_codes SET used_at = NOW() WHERE id = ?', [$row['id']]);
        return true;
    }
    q('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?', [$row['id']]);
    return false;
}

/* ---------------- single-use links (activation, password reset) ---------------- */

function link_token_issue(int $userId, string $purpose, int $ttlSeconds): string
{
    q('UPDATE auth_tokens SET used_at = NOW() WHERE user_id = ? AND purpose = ? AND used_at IS NULL', [$userId, $purpose]);
    $token = new_token();
    q('INSERT INTO auth_tokens (user_id, purpose, token_hash, expires_at) VALUES (?,?,?, DATE_ADD(NOW(), INTERVAL ? SECOND))',
        [$userId, $purpose, token_hash($token), $ttlSeconds]);
    return $token;
}

/** Looks a token up without using it. Returns the row (with user_id) or null. */
function link_token_peek(string $token, string $purpose): ?array
{
    if (!preg_match('/^[A-Za-z0-9_\-]{30,80}$/', $token)) return null;
    $row = q('SELECT id, user_id FROM auth_tokens WHERE token_hash = ? AND purpose = ? AND used_at IS NULL AND expires_at > NOW()',
        [token_hash($token), $purpose])->fetch();
    return $row ?: null;
}

function link_token_burn(int $tokenId): void
{
    q('UPDATE auth_tokens SET used_at = NOW() WHERE id = ?', [$tokenId]);
}
