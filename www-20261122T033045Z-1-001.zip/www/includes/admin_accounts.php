<?php
declare(strict_types=1);

/**
 * Administrator account-management actions. Every function here must only be called from a page that
 * already ran require_admin() (and CSRF + recent password confirmation for POST actions).
 * Each returns ['ok' => bool, 'message' => string] so the page can flash an accurate result.
 */

function acct_ok(string $m): array { return ['ok' => true, 'message' => $m]; }
function acct_err(string $m): array { return ['ok' => false, 'message' => $m]; }

/** Loads a target account and refuses admins and the caller themself for risky actions. */
function acct_target(int $id, int $adminId, bool $allowAdminRole = false): array
{
    $u = q('SELECT id, email, full_name, role, requested_role, status, email_verified_at FROM users WHERE id = ?', [$id])->fetch();
    if (!$u) return [null, acct_err('That account no longer exists.')];
    if ($id === $adminId) return [null, acct_err('You cannot do that to your own account.')];
    if (!$allowAdminRole && $u['role'] === 'admin') return [null, acct_err('Administrator accounts are not changed from this screen.')];
    return [$u, null];
}

/** approve | reject | activate | deactivate */
function admin_account_status(int $id, string $action, int $adminId): array
{
    [$u, $err] = acct_target($id, $adminId);
    if ($err) return $err;
    $label = $u['full_name'] !== '' ? $u['full_name'] : $u['email'];
    $isInstructorApplicant = $u['role'] === 'student' && in_array($u['requested_role'], ['instructor', 'staff'], true);

    switch ($action) {
        case 'approve':
        case 'activate':
            if ($isInstructorApplicant) {
                if (empty($u['email_verified_at'])) return acct_err($label . ' has not verified their email yet, so the instructor role cannot be granted.');
                staff_approve($id, $adminId, 'Approved by administrator.');           // grants the role and activates it at once
                return acct_ok($label . ' is now an approved instructor and can sign in.');
            }
            q("UPDATE users SET status = 'approved', approved_by = ?, approved_at = COALESCE(approved_at, NOW()),
                                activated_at = IF(role IN ('instructor','staff'), COALESCE(activated_at, NOW()), activated_at) WHERE id = ?", [$adminId, $id]);
            audit($action === 'approve' ? 'account_approved' : 'account_activated', 'user', $id, $label, $adminId);
            return acct_ok($label . ($action === 'approve' ? ' was approved.' : ' was activated.'));
        case 'reject':
            if ($u['status'] === 'approved') return acct_err('Deactivate an approved account instead of rejecting it.');
            q("UPDATE users SET status = 'rejected' WHERE id = ?", [$id]);
            audit('account_rejected', 'user', $id, $label, $adminId);
            return acct_ok($label . ' was rejected.');
        case 'deactivate':
            q("UPDATE users SET status = 'suspended' WHERE id = ?", [$id]);
            audit('account_deactivated', 'user', $id, $label, $adminId);
            return acct_ok($label . ' was deactivated and can no longer sign in.');
    }
    return acct_err('Unknown action.');
}

/** Sets a new password. Plaintext is hashed with password_hash() (via hash_password) and never stored or shown. */
function admin_set_password(int $id, string $new, string $confirm, int $adminId): array
{
    [$u, $err] = acct_target($id, $adminId);
    if ($err) return $err;
    if ($new !== $confirm) return acct_err('The two passwords do not match.');
    if ($problem = password_problem($new, (string)$u['email'], in_array($u['role'], STAFF_ROLES, true))) return acct_err($problem);
    q('UPDATE users SET password_hash = ?, password_changed_at = NOW() WHERE id = ?', [hash_password($new), $id]);   // also ends their open sessions
    audit('password_updated', 'user', $id, ($u['full_name'] ?: $u['email']) . ' (by administrator)', $adminId);
    send_mail($u['email'], 'Your NEMSU CampusNav AI password was changed',
        "Hello " . $u['full_name'] . ",\n\nAn administrator changed your password. If you did not expect this, contact the administrator.\n"
        . "The new password was given to you by the administrator; it is not included in this email.\n", 'pw_changed');
    return acct_ok('Password updated for ' . ($u['full_name'] ?: $u['email']) . '. They must sign in again.');
}

/** Permanently deletes an account. Falls back to deactivation if the database refuses (linked records). */
function admin_account_delete(int $id, int $adminId): array
{
    [$u, $err] = acct_target($id, $adminId);
    if ($err) return $err;
    $label = ($u['full_name'] !== '' ? $u['full_name'] : 'account') . ' <' . $u['email'] . '>';
    $docs = [];
    try { $docs = q('SELECT stored_name FROM application_documents WHERE user_id = ?', [$id])->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $e) {}
    try {
        q('DELETE FROM users WHERE id = ?', [$id]);
    } catch (Throwable $e) {
        q("UPDATE users SET status = 'suspended' WHERE id = ?", [$id]);
        audit('account_deactivated', 'user', $id, $label . ' (delete refused by database)', $adminId);
        return acct_err('This account has linked records, so it was deactivated instead of deleted.');
    }
    foreach ($docs as $f) { @unlink(app_doc_dir() . '/' . basename((string)$f)); }
    try { q('DELETE FROM application_documents WHERE user_id = ?', [$id]); } catch (Throwable $e) {}
    audit('record_deleted', 'user', null, 'account: ' . $label, $adminId);
    return acct_ok('Account deleted: ' . $label . '. Their audit history is kept.');
}

/* ---------------- official staff roster ---------------- */

function roster_validate(array $in): array
{
    $emp = strtoupper(trim((string)($in['employee_no'] ?? '')));
    $nm  = trim((string)($in['full_name'] ?? ''));
    $em  = strtolower(trim((string)($in['email'] ?? '')));
    $dp  = trim((string)($in['department'] ?? ''));
    $rl  = (string)($in['role'] ?? 'instructor');
    if (!preg_match('/^[A-Z0-9\-]{3,30}$/', $emp) || $nm === '' || mb_strlen($nm) > 150 || !filter_var($em, FILTER_VALIDATE_EMAIL)
        || $dp === '' || mb_strlen($dp) > 120 || !in_array($rl, ['instructor', 'staff'], true)) {
        return [null, 'Check the entry: employee number, name, valid email, department and role are all required.'];
    }
    return [[$emp, $nm, $em, $dp, $rl], null];
}

function roster_update(int $id, array $in, int $adminId): array
{
    [$f, $err] = roster_validate($in);
    if ($err) return acct_err($err);
    $old = q('SELECT * FROM staff_roster WHERE id = ?', [$id])->fetch();
    if (!$old) return acct_err('That roster record no longer exists.');
    try {
        q('UPDATE staff_roster SET employee_no = ?, full_name = ?, email = ?, department = ?, role = ? WHERE id = ?', array_merge($f, [$id]));
    } catch (PDOException $e) {
        return acct_err('Another roster record already uses that employee number or email.');
    }
    audit('roster_changed', 'roster', $id, 'updated ' . $f[0], $adminId);
    return acct_ok('Roster record updated for ' . $f[1] . '.');
}

/** Activates or deactivates a roster record AND the instructor/staff account that uses the same email. */
function roster_set_active(int $id, bool $active, int $adminId): array
{
    $r = q('SELECT * FROM staff_roster WHERE id = ?', [$id])->fetch();
    if (!$r) return acct_err('That roster record no longer exists.');
    q('UPDATE staff_roster SET active = ? WHERE id = ?', [$active ? 1 : 0, $id]);
    $n = q($active
        ? "UPDATE users SET status = 'approved' WHERE email = ? AND role IN ('instructor','staff') AND status = 'suspended'"
        : "UPDATE users SET status = 'suspended' WHERE email = ? AND role IN ('instructor','staff') AND status = 'approved'",
        [$r['email']])->rowCount();
    audit($active ? 'roster_activated' : 'roster_deactivated', 'roster', $id, $r['employee_no'] . ($n ? ' (linked account ' . ($active ? 'restored' : 'deactivated') . ')' : ''), $adminId);
    return acct_ok($r['full_name'] . ($active ? ' is active.' : ' is deactivated.') . ($n ? ' Their account was ' . ($active ? 'restored' : 'deactivated') . ' too.' : ''));
}

function roster_delete(int $id, int $adminId): array
{
    $r = q('SELECT * FROM staff_roster WHERE id = ?', [$id])->fetch();
    if (!$r) return acct_err('That roster record no longer exists.');
    // The linked account is NOT deleted (schedules and history depend on it): it is deactivated instead.
    $n = q("UPDATE users SET status = 'suspended' WHERE email = ? AND role IN ('instructor','staff') AND status = 'approved'", [$r['email']])->rowCount();
    q('DELETE FROM staff_roster WHERE id = ?', [$id]);
    audit('record_deleted', 'roster', null, 'roster ' . $r['employee_no'] . ' ' . $r['full_name'] . ($n ? ' (linked account deactivated)' : ''), $adminId);
    return acct_ok('Roster record deleted for ' . $r['full_name'] . '.' . ($n ? ' Their account was deactivated; use Staff accounts to delete it permanently.' : ''));
}

function roster_set_password(int $id, string $new, string $confirm, int $adminId): array
{
    $r = q('SELECT email FROM staff_roster WHERE id = ?', [$id])->fetch();
    if (!$r) return acct_err('That roster record no longer exists.');
    $u = q("SELECT id FROM users WHERE email = ? AND role IN ('instructor','staff')", [$r['email']])->fetch();
    if (!$u) return acct_err('This person has no instructor account yet, so there is no password to update.');
    return admin_set_password((int)$u['id'], $new, $confirm, $adminId);
}

/* ---------------- audit log ---------------- */

function audit_delete(array $ids, int $adminId): array
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn($i) => $i > 0)));
    if (!$ids) return acct_err('Select at least one entry.');
    $ids = array_slice($ids, 0, 500);
    $n = q('DELETE FROM audit_log WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', $ids)->rowCount();
    audit('audit_deleted', 'audit', null, $n . ' entr' . ($n === 1 ? 'y' : 'ies') . ' deleted', $adminId);   // deleting leaves its own trace
    return acct_ok($n . ' audit log entr' . ($n === 1 ? 'y' : 'ies') . ' deleted.');
}
