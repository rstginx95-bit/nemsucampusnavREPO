NEMSU CampusNav AI database setup

Fresh production installation:
1. Run install.php (it executes schema.sql, then seed.sql).
2. seed.sql contains only the prototype campus map starter data.
3. No student, instructor, subject, section, schedule, calendar, or staff-roster demo records are inserted.

Optional testing only:
- On a disposable test database, import sample-data.sql after schema.sql and seed.sql.
- Do not import sample-data.sql into production.

Safety:
- schema.sql contains DROP TABLE statements. It is destructive to existing tables.
- install.php refuses to continue if tables already exist.
- Back up before migrations or any manual SQL changes.
- Campus coordinates and walkway connections are inherited prototype values and require on-site verification.
