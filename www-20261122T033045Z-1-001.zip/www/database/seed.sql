-- Sample data based on your prototype's buildings and classes.
-- Building coordinates are the ones from your prototype. Verify them on Google Maps
-- and correct them in Admin > Locations / Walkway points. Walkway points are estimates.
CREATE DATABASE IF NOT EXISTS nemsu_campusnav CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nemsu_campusnav;
SET NAMES utf8mb4;

INSERT INTO path_nodes (id, name, lat, lng, is_entry) VALUES
 (1,  'Main Gate',                         8.53835, 126.11180, 1),
 (2,  'Central walkway',                   8.53885, 126.11185, 0),
 (3,  'CITE Building entrance',            8.53915, 126.11235, 0),
 (4,  'Main Building entrance',            8.53878, 126.11175, 0),
 (5,  'Library entrance',                  8.53945, 126.11200, 0),
 (6,  'Gymnasium entrance',                8.53852, 126.11125, 0),
 (7,  'CEA Building entrance',             8.53900, 126.11152, 0),
 (8,  'Canteen entrance',                  8.53872, 126.11222, 0),
 (9,  'Administration Building entrance',  8.53888, 126.11105, 0),
 (10, 'Science Building entrance',         8.53925, 126.11275, 0);

INSERT INTO path_edges (node_a, node_b) VALUES
 (1, 2), (2, 4), (2, 8), (2, 7), (2, 3), (3, 10), (3, 5), (5, 7), (7, 9), (9, 6), (1, 6), (8, 3);

INSERT INTO locations (id, parent_id, name, type, floor, keywords, description, hint, lat, lng, node_id) VALUES
 (1,  NULL, 'Main Gate',               'facility', NULL, 'gate,entrance,guard,main entrance', 'Campus main entrance', '', 8.53830, 126.11180, 1),
 (2,  NULL, 'CITE Building',           'building', NULL, 'cite,cite,information technology,it building,computer', 'Academic building, 3 floors', '', 8.5392, 126.1124, 3),
 (3,  NULL, 'Main Building',           'building', NULL, 'main,mai,main building', 'Academic building, 3 floors', '', 8.5388, 126.1118, 4),
 (4,  NULL, 'University Library',      'facility', NULL, 'library,lib,books,study,reading', 'Library and study areas', '', 8.5395, 126.1120, 5),
 (5,  NULL, 'University Gymnasium',    'facility', NULL, 'gym,gymnasium,pe,sports,court', 'Covered court for PE and events', '', 8.5385, 126.1112, 6),
 (6,  NULL, 'CET Building',            'building', NULL, 'cet,engineering,technology', 'Academic building, 2 floors', '', 8.5390, 126.1115, 7),
 (7,  NULL, 'Student Canteen',         'facility', NULL, 'canteen,cafeteria,food,eat,lunch', 'Food and drinks', '', 8.5387, 126.1122, 8),
 (8,  NULL, 'Administration Building', 'building', NULL, 'admin,administration,adm,president', 'Administrative offices, 2 floors', '', 8.5389, 126.1110, 9),
 (9,  NULL, 'Science Building',        'building', NULL, 'science,sci,laboratory', 'Academic building, 2 floors', '', 8.5393, 126.1128, 10),

 (10, 2, 'CITE Laboratory 1', 'lab',    1, 'lab 1,cite lab 1,comlab 1,computer lab 1', 'Computer laboratory', 'Ground floor, right after the lobby.', NULL, NULL, NULL),
 (11, 2, 'CITE Laboratory 2', 'lab',    2, 'lab 2,cite lab 2,comlab 2,computer lab 2', 'Computer laboratory', 'Second floor, end of the hallway.', NULL, NULL, NULL),
 (12, 9, 'Room 105',          'room',   1, '105,room 105,sci 105', 'Lecture room', 'Ground floor, first door on the left.', NULL, NULL, NULL),
 (13, 3, 'Room 201',          'room',   2, '201,room 201,mai 201', 'Lecture room', 'Take the stairs to the 2nd floor, then turn right.', NULL, NULL, NULL),
 (14, 5, 'Court 1',           'room',   1, 'court 1,gym court', 'Main court', 'Enter through the main doors.', NULL, NULL, NULL),
 (15, 8, 'Registrar''s Office','office', 1, 'registrar,enrollment,records,tor', 'Enrollment, records and certificates', 'Ground floor, first window on the right.', NULL, NULL, NULL),
 (16, 8, 'Cashier',           'office', 1, 'cashier,payment,tuition,fees', 'Payments and fees', 'Ground floor, beside the Registrar.', NULL, NULL, NULL),
 (17, 8, 'Guidance Office',   'office', 2, 'guidance,counseling,counselor', 'Student guidance services', 'Second floor, near the stairs.', NULL, NULL, NULL);

-- Academic data is intentionally empty in a clean production installation.
-- Optional demo records are in sample-data.sql and must only be imported into a test database.
