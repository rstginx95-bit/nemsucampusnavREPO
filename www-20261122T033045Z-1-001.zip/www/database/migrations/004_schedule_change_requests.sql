﻿-- 004_schedule_change_requests.sql
-- Safe for an existing database. BACK UP FIRST. Run once; repeating is harmless.
-- Adds pending instructor schedule change requests. Official schedules change only after admin approval (Phase 2+).
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS schedule_change_requests (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  schedule_id INT UNSIGNED NOT NULL,
  requester_user_id INT UNSIGNED NOT NULL,
  requester_instructor_id INT UNSIGNED NOT NULL,
  old_day_of_week TINYINT NOT NULL,
  old_start_time TIME NOT NULL,
  old_end_time TIME NOT NULL,
  old_room_id INT UNSIGNED NULL,
  new_day_of_week TINYINT NOT NULL,
  new_start_time TIME NOT NULL,
  new_end_time TIME NOT NULL,
  new_room_id INT UNSIGNED NULL,
  reason VARCHAR(500) NOT NULL DEFAULT '',
  status ENUM('pending','approved','rejected','cancelled','stale') NOT NULL DEFAULT 'pending',
  review_note VARCHAR(500) NOT NULL DEFAULT '',
  reviewed_by INT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_scr_status (status, created_at),
  INDEX idx_scr_schedule (schedule_id, status),
  INDEX idx_scr_requester (requester_user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
