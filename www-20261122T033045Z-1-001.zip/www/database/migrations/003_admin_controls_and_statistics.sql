-- 003_admin_controls_and_statistics.sql
-- Safe for an existing database. BACK UP FIRST (see MIGRATION_GUIDE.md). Run once; repeating it is harmless.
-- It creates one NEW table and makes one small data correction. No table is dropped or altered,
-- no student, instructor, schedule, location, subject, block or record row is deleted.
SET NAMES utf8mb4;

-- 1. One row per successful sign-in. Powers "sign-ins today", active users and the sign-in charts.
CREATE TABLE IF NOT EXISTS login_events (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  role VARCHAR(10) NOT NULL,
  ip VARCHAR(45) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_login_time (created_at),
  INDEX idx_login_role (role, created_at),
  INDEX idx_login_user (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. The invitation system was removed. Approval now activates an instructor immediately, so approved
--    instructors who were still waiting for an emailed activation link are activated now.
--    (Only rows that are already approved instructors/staff and not yet activated are touched.)
UPDATE users SET activated_at = NOW()
 WHERE role IN ('instructor','staff') AND status = 'approved' AND activated_at IS NULL;

-- The old `invitations` table is intentionally NOT dropped, so nothing is lost. It is simply unused.
-- To remove it later, after confirming you do not need it:  DROP TABLE invitations;
