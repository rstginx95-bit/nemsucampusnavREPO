-- 002_flexible_instructor_approval.sql
-- SAFE, ADDITIVE migration: creates three NEW tables only.
-- It does not ALTER, DROP, TRUNCATE or modify any existing table or row.
-- Safe to run more than once (CREATE TABLE IF NOT EXISTS).
-- BACK UP THE DATABASE FIRST (see MIGRATION_GUIDE.md).

SET NAMES utf8mb4;

-- Every Admin decision on an instructor application, with the requirements that were
-- missing at the moment of the decision. Rows are never updated except email_status.
CREATE TABLE IF NOT EXISTS application_decisions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,                    -- the applicant
  admin_id INT UNSIGNED NULL,                       -- the Admin who decided (NULL = automatic)
  decision ENUM('approved','approved_exception','rejected','kept_pending') NOT NULL,
  missing_requirements TEXT NULL,                   -- JSON list of unmet requirement labels at decision time
  remarks VARCHAR(1000) NOT NULL DEFAULT '',
  email_status VARCHAR(20) NOT NULL DEFAULT 'pending',  -- accepted_by_smtp | logged_locally | failed | pending
  email_error VARCHAR(255) NOT NULL DEFAULT '',
  ip VARCHAR(45) NOT NULL DEFAULT '',
  decided_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_dec_user (user_id, decided_at),
  INDEX idx_dec_time (decided_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Supporting documents uploaded by applicants. Files live OUTSIDE public access in storage/applications/.
CREATE TABLE IF NOT EXISTS application_documents (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  label VARCHAR(80) NOT NULL DEFAULT 'Supporting document',
  original_name VARCHAR(120) NOT NULL DEFAULT '',
  stored_name CHAR(36) NOT NULL UNIQUE,            -- random name + extension, never the user's filename
  mime VARCHAR(60) NOT NULL,
  size_bytes INT UNSIGNED NOT NULL DEFAULT 0,
  uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_doc_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One row per email attempt. 'accepted_by_smtp' means the mail server accepted the message;
-- it is NOT proof the message reached the inbox. 'logged_locally' means nothing was sent.
CREATE TABLE IF NOT EXISTS email_log (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  to_email VARCHAR(190) NOT NULL,
  subject VARCHAR(190) NOT NULL,
  purpose VARCHAR(40) NOT NULL DEFAULT '',
  status ENUM('accepted_by_smtp','logged_locally','failed') NOT NULL,
  error VARCHAR(255) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_mail_time (created_at),
  INDEX idx_mail_to (to_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
