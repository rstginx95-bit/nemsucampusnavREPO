-- Run once on an existing database after taking a verified backup.
-- Adds optional campus location photo support; does not delete or rewrite existing records.
ALTER TABLE locations ADD COLUMN image_path VARCHAR(255) NULL AFTER hint;
