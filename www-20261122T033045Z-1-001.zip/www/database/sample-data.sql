-- OPTIONAL DEMO DATA ONLY.
-- Import ONLY into a disposable development/test database after schema.sql and seed.sql.
-- This file creates sample sections, subjects, instructors, student records, schedules,
-- calendar events and a sample staff roster. It is not part of the production installer.
-- These are demonstration identities and example academic records, not verified NEMSU data.
USE nemsu_campusnav;

INSERT INTO sections (id, code, program, year_level) VALUES
 (1, 'BSCS 3-A', 'BS Computer Science', 3),
 (2, 'BSCS 1-A', 'BS Computer Science', 1);

INSERT INTO subjects (id, code, title, units) VALUES
 (1, 'CS 221',   'Computer Programming 2',   3),
 (2, 'MATH 210', 'Discrete Mathematics',     3),
 (3, 'GE 105',   'Purposive Communication',  3),
 (4, 'CS 310',   'Data Structures',          3),
 (5, 'PE 2',     'Physical Education',       2);

-- Emails are placeholders: replace them with the real institutional emails.
INSERT INTO instructors (id, employee_no, full_name, email, department) VALUES
 (1, 'EMP-001', 'Simon Michael S. Quezada', 'smquezada@nemsu.edu.ph',  'CITE'),
 (2, 'EMP-002', 'Vinz Christian Berdos',             'vinz@nemsu.edu.ph',    ''),
 (3, 'EMP-003', 'Justin Lasang',          'justin@nemsu.edu.ph',  ''),
 (4, 'EMP-004', 'Cj Labastilla I.',              'cj@nemsu.edu.ph',     '');


-- OPTIONAL SAMPLE STUDENT RECORDS. Test identities only; do not use as real student data.
INSERT INTO student_records (id, student_no, last_name, first_name, section_id) VALUES
 (1, '24-00453', 'Santos', 'Dareen S.', 1),
 (2, '24-06742', 'Dela Cruz', 'Christian', 1),
 (3, '24-00454', 'Reyes', 'Justin', 1);

-- Block BSCS 3-A (from your prototype). day_of_week: 1 = Monday
INSERT INTO schedules (section_id, subject_id, instructor_id, room_id, day_of_week, start_time, end_time) VALUES
 (1, 1, 1, 10, 1, '08:00:00', '09:30:00'),
 (1, 2, 2, 12, 1, '10:00:00', '11:30:00'),
 (1, 1, 1, 10, 2, '08:00:00', '09:30:00'),
 (1, 3, 3, 13, 2, '13:00:00', '14:30:00'),
 (1, 1, 1, 10, 3, '08:00:00', '09:30:00'),
 (1, 2, 2, 12, 3, '10:00:00', '11:30:00'),
 (1, 4, 1, 11, 3, '13:00:00', '14:30:00'),
 (1, 5, 4, 14, 3, '15:00:00', '16:00:00'),
 (1, 1, 1, 10, 4, '08:00:00', '09:30:00'),
 (1, 3, 3, 13, 4, '13:00:00', '14:30:00'),
 (1, 1, 1, 10, 5, '08:00:00', '09:30:00'),
 (1, 4, 1, 11, 5, '10:00:00', '11:30:00');

-- Calendar. Holidays are fixed national dates. Academic entries are SAMPLES: replace them
-- with the official NEMSU academic calendar in Admin > Calendar.
INSERT INTO calendar_events (title, category, start_date, end_date, description) VALUES
 ('All Saints'' Day',           'holiday',  '2026-11-01', '2026-11-01', 'Special non-working day'),
 ('Bonifacio Day',              'holiday',  '2026-11-30', '2026-11-30', 'Regular holiday'),
 ('Christmas Day',              'holiday',  '2026-12-25', '2026-12-25', 'Regular holiday'),
 ('Rizal Day',                  'holiday',  '2026-12-30', '2026-12-30', 'Regular holiday'),
 ('New Year''s Day',            'holiday',  '2027-01-01', '2027-01-01', 'Regular holiday'),
 ('Midterm examinations (sample)', 'exam',  '2026-10-19', '2026-10-24', 'Sample entry. Replace with the official dates.'),
 ('Final examinations (sample)',   'exam',  '2026-12-07', '2026-12-12', 'Sample entry. Replace with the official dates.'),
 ('Enrollment, next term (sample)','academic','2026-12-14','2026-12-18', 'Sample entry. Replace with the official dates.');

-- Trusted staff roster (maintained by administrators). Sample row: replace with your real roster.
INSERT INTO staff_roster (employee_no, full_name, email, department, role) VALUES
 ('EMP-001', 'Simon Michael S. Quezada', 'smquezada@nemsu.edu.ph', 'CITE', 'instructor');
