-- NEMSU CampusNav - database schema (MySQL 5.7+ / MariaDB 10.3+)
CREATE DATABASE IF NOT EXISTS nemsu_campusnav CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nemsu_campusnav;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS rate_limits;
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS staff_applications;
DROP TABLE IF EXISTS staff_roster;
DROP TABLE IF EXISTS auth_tokens;
DROP TABLE IF EXISTS otp_codes;
DROP TABLE IF EXISTS ai_messages;
DROP TABLE IF EXISTS calendar_events;
DROP TABLE IF EXISTS student_classes;
DROP TABLE IF EXISTS schedule_change_requests;
DROP TABLE IF EXISTS schedule_changes;
DROP TABLE IF EXISTS schedules;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS student_records;
DROP TABLE IF EXISTS sections;
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS instructors;
DROP TABLE IF EXISTS locations;
DROP TABLE IF EXISTS path_edges;
DROP TABLE IF EXISTS path_nodes;

SET FOREIGN_KEY_CHECKS = 1;

-- Walkable points on campus (gate, junctions, building entrances)
CREATE TABLE path_nodes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  lat DOUBLE NOT NULL,
  lng DOUBLE NOT NULL,
  is_entry TINYINT(1) NOT NULL DEFAULT 0   -- 1 = campus entrance used when GPS is unavailable
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Walkways between two nodes (two-way)
CREATE TABLE path_edges (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  node_a INT UNSIGNED NOT NULL,
  node_b INT UNSIGNED NOT NULL,
  FOREIGN KEY (node_a) REFERENCES path_nodes(id) ON DELETE CASCADE,
  FOREIGN KEY (node_b) REFERENCES path_nodes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Buildings, rooms, laboratories, offices and other places
CREATE TABLE locations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  parent_id INT UNSIGNED NULL,                       -- building that contains this room/office
  name VARCHAR(120) NOT NULL,
  type ENUM('building','room','lab','office','facility') NOT NULL DEFAULT 'room',
  floor TINYINT NULL,                                -- 1 = ground floor
  keywords VARCHAR(255) NOT NULL DEFAULT '',         -- comma-separated search words used by search + AI
  description VARCHAR(255) NOT NULL DEFAULT '',
  hint VARCHAR(255) NOT NULL DEFAULT '',
  image_path VARCHAR(255) NULL,                      -- uploaded campus/building photo filename             -- indoor tip, e.g. "Second door after the stairs"
  lat DOUBLE NULL,                                   -- rooms inherit the building's position
  lng DOUBLE NULL,
  node_id INT UNSIGNED NULL,                         -- entrance node on the walking graph
  FOREIGN KEY (parent_id) REFERENCES locations(id) ON DELETE SET NULL,
  FOREIGN KEY (node_id) REFERENCES path_nodes(id) ON DELETE SET NULL,
  INDEX idx_loc_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE instructors (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  employee_no VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  department VARCHAR(120) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE subjects (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(30) NOT NULL UNIQUE,
  title VARCHAR(150) NOT NULL,
  units DECIMAL(3,1) NOT NULL DEFAULT 3.0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Block / section, e.g. "BSCS 2-A"
CREATE TABLE sections (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(40) NOT NULL UNIQUE,
  program VARCHAR(120) NOT NULL DEFAULT '',
  year_level TINYINT NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Official enrollment list (maintained by the registrar/admin).
-- A student unlocks their schedule by matching a row here.
CREATE TABLE student_records (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_no VARCHAR(30) NOT NULL UNIQUE,
  last_name VARCHAR(80) NOT NULL,
  first_name VARCHAR(80) NOT NULL,
  section_id INT UNSIGNED NULL,
  added_by INT UNSIGNED NULL,                -- staff account that enrolled this student in the system
  FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Accounts. "role" is what the account is ALLOWED to do (only ever changed by the server after verification).
-- "requested_role" is only what the person asked for at sign-up and never grants anything.
CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL UNIQUE,
  mobile VARCHAR(20) NULL UNIQUE,                    -- stored as +639XXXXXXXXX
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(150) NOT NULL DEFAULT '',
  birthday DATE NULL,
  address VARCHAR(255) NULL,
  student_type ENUM('freshman','transferee','old') NULL,
  profile_done TINYINT(1) NOT NULL DEFAULT 0,
  role ENUM('student','instructor','staff','admin') NOT NULL DEFAULT 'student',
  requested_role ENUM('student','instructor','staff') NOT NULL DEFAULT 'student',
  status ENUM('pending_email','pending_identity','pending_admin','approved','rejected','suspended') NOT NULL DEFAULT 'pending_email',
  claimed_student_no VARCHAR(30) NULL,               -- what the person typed; NOT trusted until verified
  student_record_id INT UNSIGNED NULL UNIQUE,
  instructor_id INT UNSIGNED NULL UNIQUE,
  email_verified_at DATETIME NULL,
  activated_at DATETIME NULL,                        -- staff must activate through the emailed link
  approved_by INT UNSIGNED NULL,
  approved_at DATETIME NULL,
  password_changed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login DATETIME NULL,
  FOREIGN KEY (student_record_id) REFERENCES student_records(id) ON DELETE SET NULL,
  FOREIGN KEY (instructor_id) REFERENCES instructors(id) ON DELETE SET NULL,
  INDEX idx_users_status (status, requested_role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Official class schedule. day_of_week: 1 = Monday ... 7 = Sunday
CREATE TABLE schedules (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  section_id INT UNSIGNED NOT NULL,
  subject_id INT UNSIGNED NOT NULL,
  instructor_id INT UNSIGNED NULL,
  room_id INT UNSIGNED NULL,
  day_of_week TINYINT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  FOREIGN KEY (instructor_id) REFERENCES instructors(id) ON DELETE SET NULL,
  FOREIGN KEY (room_id) REFERENCES locations(id) ON DELETE SET NULL,
  INDEX idx_sched_day (day_of_week, start_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Notices shown to affected students/instructors when an admin changes a schedule
CREATE TABLE schedule_changes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  schedule_id INT UNSIGNED NULL,
  section_id INT UNSIGNED NULL,
  instructor_id INT UNSIGNED NULL,
  record_id INT UNSIGNED NULL,                       -- set for changes that affect one student only
  summary VARCHAR(255) NOT NULL,
  changed_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_chg_section (section_id, created_at),
  INDEX idx_chg_instructor (instructor_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Instructor-submitted schedule edits (day/time/room). Official schedules change only after admin approval.
CREATE TABLE schedule_change_requests (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  schedule_id INT UNSIGNED NOT NULL,
  requester_user_id INT UNSIGNED NOT NULL,
  requester_instructor_id INT UNSIGNED NOT NULL,
  old_day_of_week TINYINT NOT NULL,
  old_start_time TIME NOT NULL,
  old_end_time TIME NOT NULL,
  old_room_id INT UNSIGNED NULL,
  new_day_of_week TINYINT NOT NULL,
  new_start_time TIME NOT NULL,
  new_end_time TIME NOT NULL,
  new_room_id INT UNSIGNED NULL,
  reason VARCHAR(500) NOT NULL DEFAULT '',
  status ENUM('pending','approved','rejected','cancelled','stale') NOT NULL DEFAULT 'pending',
  review_note VARCHAR(500) NOT NULL DEFAULT '',
  reviewed_by INT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_scr_status (status, created_at),
  INDEX idx_scr_schedule (schedule_id, status),
  INDEX idx_scr_requester (requester_user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE ai_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  sender ENUM('user','ai') NOT NULL,
  body TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_ai_user (user_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Classes added to one student on top of their block (irregular students, transferees, extra subjects)
CREATE TABLE student_classes (
  record_id INT UNSIGNED NOT NULL,
  schedule_id INT UNSIGNED NOT NULL,
  added_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (record_id, schedule_id),
  FOREIGN KEY (record_id) REFERENCES student_records(id) ON DELETE CASCADE,
  FOREIGN KEY (schedule_id) REFERENCES schedules(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- NEMSU calendar: academic dates, exams, holidays and events
CREATE TABLE calendar_events (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  category ENUM('academic','exam','holiday','event') NOT NULL DEFAULT 'event',
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  created_by INT UNSIGNED NULL,
  INDEX idx_cal_dates (start_date, end_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One-time email codes (email verification, staff sign-in). Only a keyed hash of the code is stored.
CREATE TABLE otp_codes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  purpose VARCHAR(20) NOT NULL,
  code_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  used_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_otp (user_id, purpose)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Single-use links (account activation, password reset). Only the SHA-256 of the token is stored.
CREATE TABLE auth_tokens (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  purpose VARCHAR(20) NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Official staff roster, maintained by administrators. This is the trusted source for staff verification.
CREATE TABLE staff_roster (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  employee_no VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  department VARCHAR(120) NOT NULL DEFAULT '',
  role ENUM('instructor','staff') NOT NULL DEFAULT 'instructor',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- What an instructor/staff applicant submitted, and which automatic checks passed.
CREATE TABLE staff_applications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL UNIQUE,
  employee_no VARCHAR(30) NOT NULL,
  department VARCHAR(120) NOT NULL DEFAULT '',
  requested_role ENUM('instructor','staff') NOT NULL,
  roster_id INT UNSIGNED NULL,
  invitation_id INT UNSIGNED NULL,
  chk_roster TINYINT(1) NOT NULL DEFAULT 0,
  chk_employee TINYINT(1) NOT NULL DEFAULT 0,
  chk_department TINYINT(1) NOT NULL DEFAULT 0,
  chk_role TINYINT(1) NOT NULL DEFAULT 0,
  chk_invite TINYINT(1) NOT NULL DEFAULT 0,
  review_note VARCHAR(255) NOT NULL DEFAULT '',
  reviewed_by INT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Every approval, rejection, role change, token use and suspicious attempt. Never holds passwords, codes or full tokens.
CREATE TABLE audit_log (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_id INT UNSIGNED NULL,
  action VARCHAR(40) NOT NULL,
  target_type VARCHAR(20) NOT NULL DEFAULT '',
  target_id INT UNSIGNED NULL,
  ip VARCHAR(45) NOT NULL DEFAULT '',
  detail VARCHAR(500) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_action (action, created_at),
  INDEX idx_audit_time (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Shared attempt limiter (works across browsers and devices, not just one session)
CREATE TABLE rate_limits (
  bucket VARCHAR(30) NOT NULL,
  key_hash CHAR(64) NOT NULL,
  hits INT UNSIGNED NOT NULL DEFAULT 0,
  window_start INT UNSIGNED NOT NULL,
  PRIMARY KEY (bucket, key_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Flexible instructor approval (migration 002, included for fresh installs)
CREATE TABLE IF NOT EXISTS application_decisions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,                    -- the applicant
  admin_id INT UNSIGNED NULL,                       -- the Admin who decided (NULL = automatic)
  decision ENUM('approved','approved_exception','rejected','kept_pending') NOT NULL,
  missing_requirements TEXT NULL,                   -- JSON list of unmet requirement labels at decision time
  remarks VARCHAR(1000) NOT NULL DEFAULT '',
  email_status VARCHAR(20) NOT NULL DEFAULT 'pending',  -- accepted_by_smtp | logged_locally | failed | pending
  email_error VARCHAR(255) NOT NULL DEFAULT '',
  ip VARCHAR(45) NOT NULL DEFAULT '',
  decided_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_dec_user (user_id, decided_at),
  INDEX idx_dec_time (decided_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Supporting documents uploaded by applicants. Files live OUTSIDE public access in storage/applications/.
CREATE TABLE IF NOT EXISTS application_documents (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  label VARCHAR(80) NOT NULL DEFAULT 'Supporting document',
  original_name VARCHAR(120) NOT NULL DEFAULT '',
  stored_name CHAR(36) NOT NULL UNIQUE,            -- random name + extension, never the user's filename
  mime VARCHAR(60) NOT NULL,
  size_bytes INT UNSIGNED NOT NULL DEFAULT 0,
  uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_doc_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One row per email attempt. 'accepted_by_smtp' means the mail server accepted the message;
-- it is NOT proof the message reached the inbox. 'logged_locally' means nothing was sent.
CREATE TABLE IF NOT EXISTS email_log (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  to_email VARCHAR(190) NOT NULL,
  subject VARCHAR(190) NOT NULL,
  purpose VARCHAR(40) NOT NULL DEFAULT '',
  status ENUM('accepted_by_smtp','logged_locally','failed') NOT NULL,
  error VARCHAR(255) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_mail_time (created_at),
  INDEX idx_mail_to (to_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One row per successful sign-in (statistics dashboard). Migration 003 creates it on existing databases.
CREATE TABLE IF NOT EXISTS login_events (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  role VARCHAR(10) NOT NULL,
  ip VARCHAR(45) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_login_time (created_at),
  INDEX idx_login_role (role, created_at),
  INDEX idx_login_user (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
