<?php
declare(strict_types=1);
// Backward-compatible account URL; Settings is the canonical page.
header('Location: settings.php', true, 302);
exit;
