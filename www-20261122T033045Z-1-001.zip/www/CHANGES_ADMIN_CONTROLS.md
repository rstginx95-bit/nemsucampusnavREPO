# Changes: admin controls, dashboard switcher and statistics

## What changed, by request item
| # | Request | Where |
|---|---|---|
| 1 | No approval-reason restriction; approve/reject/activate/deactivate any account | `verification.php` (Applications, Students, Staff accounts, Accounts views), `includes/admin_accounts.php` |
| 2 | Roster: Activate, Deactivate, Update Password, Delete, Edit | `verification.php` (Official roster), `includes/admin_accounts.php` |
| 3 | Invitation system removed | `verification.php`, `includes/staff_verify.php`, `includes/tokens.php`, `register.php`, `config.php`, `check.php`, `database/schema.sql` |
| 4 | Update Password on staff accounts | `verification.php` (every accounts table) |
| 5 | Delete audit entries (single and multiple, with confirmation) | `verification.php` (Audit log), `audit_delete()` |
| 6 | Manage cards clickable with filtered destinations | `admin.php`, `verification.php` (filters `f`, `role`, `h`, `q`) |
| 7 | Walkway Points, Developer Dashboard, Manage Instructors, Location Photos removed from admin navigation | `admin.php` |
| 8 | Administrator-only Dashboard Switcher | new `switch-dashboard.php`, `includes/bootstrap.php`, `includes/layout.php` |
| 9 | Main navigation | `includes/layout.php` (adds Switch dashboard for administrators only) |
| + | Statistics dashboard | new `includes/stats.php`, `assets/js/stats.js`, top of `admin.php` |

## New / changed files
New: `switch-dashboard.php`, `includes/admin_accounts.php`, `includes/stats.php`, `assets/js/stats.js`, `database/migrations/003_admin_controls_and_statistics.sql`.
Changed: `admin.php`, `verification.php`, `register.php`, `index.php`, `import.php`, `config.php`, `check.php`, `includes/bootstrap.php`, `includes/layout.php`, `includes/staff_verify.php`, `includes/app_review.php`, `includes/tokens.php`, `includes/role_login.php`, `assets/css/app.css`, `database/schema.sql`.

## Behaviour notes
- Approving an instructor now activates the account at once (no emailed activation step); a notice email is still sent.
- Every account action needs CSRF and a password confirmation within the last 10 minutes (existing `reauth` rule). Buttons are disabled with a link until confirmed.
- Roster Deactivate/Activate also suspends/restores the account with the same email. Roster Delete deactivates the account instead of erasing it. "Delete" on an account row deletes it permanently and removes its uploaded documents; audit history stays. If the database refuses (linked records) the account is deactivated and you are told.
- Administrator accounts cannot be deactivated, deleted, or have their password changed from these screens, and nobody can do these to their own account.
- Dashboard Switcher: stores `preview_role` in the administrator's own session only. `current_user()` honours it only for `role = admin`; the role, status and every `require_admin()` check are untouched. Preview is read-only (POSTs are refused). Logging in again clears it.
- After admin login the Developer Dashboard is no longer the landing page; everyone lands on `admin.php`. `developer.php` and `developer-location-photos.php` still exist but have no navigation link.
- Statistics: account totals are current values; registrations, approvals, sign-ins, charts and recent activities follow the selected period. Sign-in history starts when migration 003 is applied (earlier sign-ins were never stored individually).
- Chart.js loads from cdnjs. Without internet the charts show as plain data tables.
