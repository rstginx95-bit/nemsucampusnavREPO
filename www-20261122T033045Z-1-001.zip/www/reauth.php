<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/auth_page.php';

$u = require_staff();
$next = safe_next((string)($_GET['next'] ?? $_POST['next'] ?? ''), 'admin.php');
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    if (!rate_ok_for('reauth', (string)$u['id'], 5, 900)) {
        $errors[] = 'Too many attempts. Try again in 15 minutes.';
    } elseif (password_verify((string)($_POST['password'] ?? ''), $u['password_hash'])) {
        $_SESSION['reauth_at'] = time();
        audit('reauth_ok', 'user', (int)$u['id'], $next);
        redirect($next);
    } else {
        audit('reauth_failed', 'user', (int)$u['id'], '');
        $errors[] = 'That password is not correct.';
    }
}
auth_start('Confirm your password', true);
?>
  <section class="holo card enter" id="card" aria-labelledby="t">
    <div class="big-icon"><?= icon('lock') ?></div>
    <h1 id="t">Confirm it is you</h1>
    <p class="muted">This action changes who can access the system, so please enter your password again.</p>
    <?php auth_errors($errors); ?>
    <form method="post" class="form"><?= csrf_field() ?><input type="hidden" name="next" value="<?= e($next) ?>">
      <label class="field">Your password<input type="password" name="password" autocomplete="current-password" required autofocus></label>
      <button class="btn btn-primary" type="submit">Confirm</button>
    </form>
    <p class="foot"><a class="hu" href="<?= e($next) ?>">Cancel</a></p>
  </section>
<?php auth_end(); ?>
