<?php
declare(strict_types=1);
$registration_kind = 'staff';
require __DIR__ . '/register.php';
