<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/tokens.php';
require __DIR__ . '/includes/mailer.php';
require __DIR__ . '/includes/verify.php';
require __DIR__ . '/includes/staff_verify.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/auth_page.php';

$u = require_login();
$uid = (int)$u['id'];
$errors = [];
$notice = '';

if (!empty($u['email_verified_at'])) {
    if (($u['requested_role'] ?? 'student') === 'student') {
        student_finish_registration($uid);
        redirect('home.php');
    }
    staff_application_evaluate($uid);
    redirect('status.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $action = (string)($_POST['action'] ?? 'verify');
    if ($action === 'resend') {
        if (!rate_ok_for('verify_resend', (string)$u['email'], 3, 900)) {
            $errors[] = 'Please wait before requesting another code.';
        } else {
            $code = otp_issue($uid, 'verify_email');
            send_mail((string)$u['email'], 'Your NEMSU CampusNav email verification code',
                "Your verification code is: {$code}\n\nIt expires in " . ((int)cfg('security.otp_ttl', 600) / 60) . " minutes and works once.\nNever share this code with anyone.\n");
            $notice = 'A new verification code has been sent if email delivery is configured.';
        }
    } else {
        $code = trim((string)($_POST['code'] ?? ''));
        if (otp_check($uid, 'verify_email', $code)) {
            q('UPDATE users SET email_verified_at = NOW() WHERE id = ?', [$uid]);
            audit('email_verified', 'user', $uid, 'email OTP verified', $uid);
            if (($u['requested_role'] ?? 'student') === 'student') {
                student_finish_registration($uid);
                redirect('home.php');
            }
            staff_application_evaluate($uid);
            redirect('status.php');
        }
        $errors[] = 'That code is incorrect, expired, or has reached its attempt limit. Request a new code and try again.';
    }
}

auth_start('Verify your email', !empty($u['requested_role']) && $u['requested_role'] !== 'student');
?>
<section class="holo card enter" id="card" aria-labelledby="t">
  <h1 id="t">Verify your email</h1>
  <p class="muted">Enter the six-digit code sent to <strong><?= e($u['email']) ?></strong>. The code expires after <?= (int)(cfg('security.otp_ttl', 600) / 60) ?> minutes.</p>
  <?php auth_errors($errors); ?>
  <?php if ($notice !== ''): ?><div class="notice notice-ok" role="status"><?= e($notice) ?></div><?php endif; ?>
  <form method="post" class="form" autocomplete="one-time-code">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="verify">
    <label class="field">Six-digit verification code
      <input type="text" name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" minlength="6" autocomplete="one-time-code" placeholder="000000" required>
    </label>
    <button class="btn btn-primary" type="submit">Verify email</button>
  </form>
  <form method="post" class="form">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="resend">
    <button class="btn btn-ghost" type="submit">Resend code</button>
  </form>
</section>
<?php auth_end(); ?>
