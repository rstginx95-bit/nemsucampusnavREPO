<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require_post_csrf();
$u = current_user();
if ($u) {
    audit('logout', 'user', (int)$u['id'], '', (int)$u['id']);
}
logout_user();
redirect('index.php');
