<?php
declare(strict_types=1);
header('Location: instructor-login.php', true, 302);
exit;
