<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/locations.php';
require __DIR__ . '/includes/importer.php';
require __DIR__ . '/includes/layout.php';

$u = require_staff();
preview_block_writes('import.php');
$target = (($_GET['target'] ?? $_POST['target'] ?? 'students') === 'roster') ? 'roster' : 'students';
if ($target === 'students' && !is_admin($u)) {
    http_response_code(403);
    exit('Only administrators can import students.');
}
if ($target === 'roster' && !is_admin($u)) {
    http_response_code(403);
    exit('Only administrators can import the staff roster.');
}

/* ---------------- JSON actions ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf(true);
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'parse') {
            if (!rate_ok('import', 20, 3600)) json_out(['error' => 'Too many uploads. Try again later.'], 429);
            $f = $_FILES['file'] ?? null;
            if (!$f || ($f['error'] ?? 1) !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) json_out(['error' => 'The file did not upload. Try again.'], 400);
            $rows = import_parse_file($f['tmp_name'], (string)$f['name']);
            $header = array_map('strval', $rows[0]);
            $mapping = import_guess_mapping($header, $target);
            $tok = bin2hex(random_bytes(12));
            $_SESSION['import'] = ['tok' => $tok, 'target' => $target, 'rows' => $rows, 'file' => mb_substr((string)$f['name'], 0, 80)];
            audit('import_parsed', 'import', null, $target . ', ' . (count($rows) - 1) . ' rows');
            json_out(['ok' => true, 'token' => $tok, 'file' => $_SESSION['import']['file'], 'header' => $header, 'mapping' => $mapping, 'fields' => import_fields($target)]);
        }

        $imp = $_SESSION['import'] ?? null;
        if (!$imp || !hash_equals((string)$imp['tok'], (string)($_POST['token'] ?? '')) || $imp['target'] !== $target) {
            json_out(['error' => 'That upload expired. Drop the file again.'], 410);
        }
        $mapping = [];
        foreach ((array)json_decode((string)($_POST['mapping'] ?? '{}'), true) as $field => $col) {
            if (array_key_exists($field, import_fields($target)) && is_numeric($col) && $col >= 0) $mapping[$field] = (int)$col;
        }
        $defaultBlock = (int)($_POST['block'] ?? 0) ?: null;
        $recs = import_evaluate($imp['rows'], $mapping, $target, $defaultBlock);
        $mode = ($_POST['mode'] ?? 'skip') === 'update' ? 'update' : 'skip';
        $count = ['ok' => 0, 'exists' => 0, 'duplicate' => 0, 'invalid' => 0];
        foreach ($recs as $r) $count[$r['status']]++;

        if ($action === 'preview') {
            json_out(['ok' => true, 'counts' => $count, 'rows' => array_slice($recs, 0, 150), 'total' => count($recs)]);
        }

        if ($action === 'commit') {
            if ($target === 'roster' && !reauth_fresh()) {
                json_out(['error' => 'Please confirm your password first.', 'reauth' => 'reauth.php?next=' . rawurlencode('import.php?target=roster')], 403);
            }
            $added = 0; $updated = 0;
            db()->beginTransaction();
            foreach ($recs as $r) {
                if ($r['status'] === 'ok' || ($r['status'] === 'exists' && $mode === 'update')) {
                    if ($target === 'roster') {
                        q('INSERT INTO staff_roster (employee_no, full_name, email, department, role, created_by) VALUES (?,?,?,?,?,?)
                           ON DUPLICATE KEY UPDATE full_name = VALUES(full_name), department = VALUES(department), role = VALUES(role), active = 1',
                            [$r['employee_no'], $r['full_name'], $r['email'], $r['department'], $r['role'], $u['id']]);
                    } else {
                        q('INSERT INTO student_records (student_no, last_name, first_name, section_id, added_by) VALUES (?,?,?,?,?)
                           ON DUPLICATE KEY UPDATE last_name = VALUES(last_name), first_name = VALUES(first_name), section_id = IFNULL(VALUES(section_id), section_id)',
                            [$r['student_no'], $r['last_name'], $r['first_name'], $r['section_id'], $u['id']]);
                    }
                    $r['status'] === 'ok' ? $added++ : $updated++;
                }
            }
            db()->commit();
            unset($_SESSION['import']);
            audit($target === 'roster' ? 'roster_imported' : 'students_imported', 'import', null, "added=$added updated=$updated skipped=" . ($count['exists'] - ($mode === 'update' ? $count['exists'] : 0) + $count['duplicate'] + $count['invalid']));
            json_out(['ok' => true, 'added' => $added, 'updated' => $updated, 'skipped' => count($recs) - $added - $updated]);
        }
        json_out(['error' => 'Unknown action.'], 400);
    } catch (RuntimeException $e) {
        if (db()->inTransaction()) db()->rollBack();
        json_out(['error' => $e->getMessage()], 400);
    } catch (Throwable $e) {
        if (db()->inTransaction()) db()->rollBack();
        throw $e;
    }
}

$sections = q('SELECT id, code FROM sections ORDER BY code')->fetchAll();
render_head('Import', 'import');
?>
<div class="page-head"><div>
  <h1><?= $target === 'roster' ? 'Import the staff roster' : 'Import students' ?></h1>
  <p class="muted"><?= $target === 'roster' ? 'Add trusted staff from a file instead of typing each person.' : 'Drop your class list. No more typing every ID and name by hand.' ?></p></div>
  <?php if ($target === 'students' && is_admin($u)): ?><a class="btn btn-ghost btn-small" href="import.php?target=roster">Import staff roster instead</a><?php endif; ?>
</div>

<section class="card" id="imp" data-target="<?= e($target) ?>">
  <div class="dropzone" id="drop" tabindex="0" role="button" aria-label="Choose or drop a file">
    <?= icon('upload') ?>
    <strong>Drag a file here or tap to choose</strong>
    <span class="muted">Excel (.xlsx), Word (.docx) or CSV, up to 5 MB. The first row must be the column names.</span>
    <input type="file" id="file" accept=".xlsx,.docx,.csv" hidden>
  </div>
  <p class="notice notice-error" id="imp-error" role="alert" hidden></p>

  <div id="imp-step2" hidden>
    <h2><?= icon('file') ?> <span id="imp-file"></span></h2>
    <p class="muted">Check that each column is matched correctly. You can change a match.</p>
    <div class="map-grid" id="map-grid"></div>
    <div class="field-row">
      <?php if ($target === 'students'): ?>
        <label class="field">Block for students with none in the file
          <select id="imp-block"><option value="">No block</option><?php foreach ($sections as $s): ?><option value="<?= (int)$s['id'] ?>"><?= e($s['code']) ?></option><?php endforeach; ?></select></label>
      <?php endif; ?>
      <label class="field">If the ID is already in the system
        <select id="imp-mode"><option value="skip">Skip it (keep what is there)</option><option value="update">Update the name and block</option></select></label>
    </div>
    <div class="imp-counts" id="imp-counts" aria-live="polite"></div>
    <div class="table-wrap"><table class="table" id="imp-table"></table></div>
    <div class="btn-row"><button class="btn btn-primary" id="imp-go" type="button">Import</button><button class="btn btn-ghost" id="imp-cancel" type="button">Choose another file</button></div>
  </div>
  <p class="notice notice-ok" id="imp-done" hidden></p>
</section>
<script>window.CN_IMPORT = <?= json_encode(['target' => $target], JSON_HEX_TAG | JSON_HEX_AMP) ?>;</script>
<?php render_foot('import', ['assets/js/import.js?v=4']); ?>
