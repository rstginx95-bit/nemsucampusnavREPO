<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/tokens.php';
require __DIR__ . '/includes/mailer.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/auth_page.php';
require __DIR__ . '/includes/staff_verify.php';

if ($u = current_user()) {
    redirect(is_staff($u) ? 'admin.php' : 'home.php');
}

$domain  = (string)cfg('app.email_domain');
$errors  = [];
// Students and instructors have separate public registration routes. Instructor applications
// are independently submitted and remain pending until an administrator approves them.
$kind = (($registration_kind ?? 'student') === 'staff') ? 'staff' : 'student';
$v = fn(string $k, string $d = '') => e($_POST[$k] ?? $d);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $name   = trim(preg_replace('/\s+/', ' ', (string)($_POST['full_name'] ?? '')));
    $email  = strtolower(trim((string)($_POST['email'] ?? '')));
    $pass   = (string)($_POST['password'] ?? '');
    $conf   = (string)($_POST['confirm'] ?? '');
    $isStaff = $kind === 'staff';

    if (!rate_ok_for('register', $email, 5, 3600)) {
        $errors[] = 'Too many attempts. Please wait a while and try again.';
        audit('register_rate_limited', 'user', null, $kind);
    } else {
        if (mb_strlen($name) < 3 || mb_strlen($name) > 120 || !str_contains($name, ' ')) $errors[] = 'Enter your full name (first and last name).';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address. Gmail, Yahoo, Outlook and other email providers are accepted.';
        if ($pw = password_problem($pass, $email, $isStaff)) $errors[] = $pw;
        if ($pass !== $conf) $errors[] = 'The two passwords do not match.';

        $stype = ''; $sno = ''; $empNo = ''; $dept = ''; $srole = '';
        if (!$isStaff) {
            $stype = (string)($_POST['student_type'] ?? '');
            $sno   = strtoupper(trim((string)($_POST['student_no'] ?? '')));
            if (!in_array($stype, ['freshman', 'transferee', 'old'], true)) $errors[] = 'Choose freshman, transferee or old student.';
            if ($stype === 'old' && $sno === '') $errors[] = 'Old students must enter their Student ID.';
            if ($sno !== '' && !preg_match('/^[A-Z0-9\-]{4,30}$/', $sno)) $errors[] = 'Check the Student ID format, for example 24-00453.';
            if ($sno !== '' && q('SELECT 1 FROM users WHERE UPPER(claimed_student_no) = ? LIMIT 1', [$sno])->fetch()) {
                $errors[] = 'That Student ID has already been claimed by another account. Contact the Registrar if this is a mistake.';
            }
            if ($stype === 'freshman') $sno = '';
        } else {
            $srole = 'instructor';
            $empNo = strtoupper(trim((string)($_POST['employee_no'] ?? '')));
            $dept  = trim(preg_replace('/\s+/', ' ', (string)($_POST['department'] ?? '')));
            if (!preg_match('/^[A-Z0-9\-]{3,30}$/', $empNo)) $errors[] = 'Enter your employee ID, for example EMP-001.';
            if (mb_strlen($dept) < 2 || mb_strlen($dept) > 120) $errors[] = 'Enter your department or office.';
            if ($empNo !== '' && (q('SELECT 1 FROM instructors WHERE UPPER(employee_no) = ? LIMIT 1', [$empNo])->fetch()
                || q('SELECT 1 FROM staff_applications WHERE UPPER(employee_no) = ? LIMIT 1', [$empNo])->fetch())) {
                $errors[] = 'That Employee ID is already associated with an instructor account or application. Contact the administrator if you believe this is an error.';
            }
        }
        if (!$errors && q('SELECT 1 FROM users WHERE email = ?', [$email])->fetch()) {
            $errors[] = 'That email is already registered. Log in, or use "Forgot password".';
        }
        if (!$errors) {
            // The selected role is ONLY a request. Everybody starts as a student with no extra power.
            q("INSERT INTO users (email_verified_at, email, password_hash, full_name, role, requested_role, status, student_type, claimed_student_no)
               VALUES (NULL, ?,?,?, 'student', ?, 'pending_email', ?, ?)",
                [$email, hash_password($pass), $name, $isStaff ? $srole : 'student', $isStaff ? null : $stype, $sno !== '' ? $sno : null]);
            $uid = (int)db()->lastInsertId();
            if ($isStaff) {
                q('INSERT INTO staff_applications (user_id, employee_no, department, requested_role) VALUES (?,?,?,?)',
                    [$uid, $empNo, $dept, $srole]);
            }
            audit('register', 'user', $uid, 'requested=' . ($isStaff ? $srole : 'student'), $uid);
            $code = otp_issue($uid, 'verify_email');
            send_mail($email, 'Your NEMSU CampusNav AI verification code',
                "Your verification code is: $code\n\nIt expires in " . ((int)cfg('security.otp_ttl', 600) / 60) . " minutes and works once.\nNever share this code with anyone.\n");
            login_user($uid);
            $_SESSION['otp_sent_at'] = time();
            redirect('verify-email.php');
        }
    }
}
$cur = $_POST['student_type'] ?? '';
auth_start('Create account', $kind === 'staff', 'stage-wide');
?>
  <section class="holo card enter" id="card" aria-labelledby="t">
    <h1 id="t">Create your account</h1>
    <p class="muted"><?= $kind === 'staff' ? 'Apply for instructor access using your employee details. Your application will be reviewed by an administrator.' : 'Create your student account using your details and a valid email address.' ?></p>


    <?php auth_errors($errors); ?>

    <form method="post" class="form" autocomplete="on">
      <?= csrf_field() ?>
      <div class="field-row">
        <label class="field">Full name<input type="text" name="full_name" value="<?= $v('full_name') ?>" autocomplete="name" maxlength="120" required></label>
        <label class="field">Email address<input type="email" name="email" value="<?= $v('email') ?>" placeholder="name@gmail.com" autocomplete="email" required></label>
      </div>
      <div class="field-row">
        <label class="field">Password<input type="password" name="password" autocomplete="new-password" minlength="12" required></label>
        <label class="field">Confirm password<input type="password" name="confirm" autocomplete="new-password" required></label>
      </div>

      <?php if ($kind === 'student'): ?>
        <fieldset class="choices">
          <legend>I am a</legend>
          <?php foreach (['freshman' => ['New student', 'No Student ID yet. Map and AI open right away.'], 'transferee' => ['Transferee', 'Use your NEMSU Student ID once the Registrar issues it.'], 'old' => ['Old student', 'Student ID required to open the app.']] as $k => [$lbl, $desc]): ?>
            <label class="choice"><input type="radio" name="student_type" value="<?= $k ?>" <?= $cur === $k ? 'checked' : '' ?> required>
              <span class="choice-body"><strong><?= $lbl ?></strong><small><?= $desc ?></small></span><span class="choice-check"><?= icon('check') ?></span></label>
          <?php endforeach; ?>
        </fieldset>
        <label class="field" id="sno-wrap">Student ID number
          <input type="text" name="student_no" value="<?= $v('student_no') ?>" placeholder="24-00000" autocapitalize="characters" maxlength="30">
          <small class="help">Required for old students. Transferees can add it now or later.</small></label>
      <?php else: ?>
        <div class="field-row">
          <div class="field"><span>Account type</span><strong>Instructor</strong><small class="help">Requested during registration; access is granted after administrator approval.</small></div>
          <label class="field">Employee ID<input type="text" name="employee_no" value="<?= $v('employee_no') ?>" placeholder="EMP-001" autocapitalize="characters" maxlength="30" required></label>
        </div>
        <label class="field">Department or office<input type="text" name="department" value="<?= $v('department') ?>" placeholder="e.g. CITE" maxlength="120" required></label>
        <div class="notice notice-warn"><?= icon('shieldcheck') ?><div>Your application will be submitted for administrator review. You can use any valid email address. Instructor features remain locked until approval.</div></div>
      <?php endif; ?>

      <button class="btn btn-primary" type="submit">Continue</button>
    </form>
    <p class="foot">Already have an account? <a class="hu" href="<?= $kind === 'staff' ? 'instructor-login.php' : 'student-login.php' ?>"><?= $kind === 'staff' ? 'Instructor login' : 'Student login' ?></a></p>
  </section>
<?php auth_end(); ?>
