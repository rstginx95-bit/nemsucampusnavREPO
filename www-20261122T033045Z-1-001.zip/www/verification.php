<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/tokens.php';
require __DIR__ . '/includes/mailer.php';
require __DIR__ . '/includes/staff_verify.php';
require __DIR__ . '/includes/layout.php';

$admin = require_admin();
$tab = (string)($_GET['tab'] ?? 'pending');
if (!in_array($tab, ['pending', 'decisions', 'roster', 'students', 'staff', 'accounts', 'logins', 'audit'], true)) $tab = 'pending';
// Filters travel in the URL so Manage-dashboard cards can open a filtered view, and actions return to the same view.
$f = in_array((string)($_GET['f'] ?? ''), ['approved', 'pending', 'rejected', 'suspended', 'active7'], true) ? (string)$_GET['f'] : '';
$roleF = in_array((string)($_GET['role'] ?? ''), ['student', 'instructor', 'admin'], true) ? (string)$_GET['role'] : '';
$hrs = in_array((int)($_GET['h'] ?? 0), [24, 168, 720], true) ? (int)$_GET['h'] : 0;
$qs = mb_substr(trim((string)($_GET['q'] ?? '')), 0, 80);
$self = 'verification.php?' . http_build_query(array_filter(['tab' => $tab, 'f' => $f, 'role' => $roleF, 'h' => $hrs ?: null, 'q' => $qs], fn($v) => $v !== '' && $v !== null));

/* ---------------- actions (POST only, CSRF, admin only, password re-entered recently) ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $act = (string)($_POST['a'] ?? '');
    $uid = (int)($_POST['user_id'] ?? 0);
    $note = (string)($_POST['remarks'] ?? '');
    require_reauth($self);                                // sensitive: sends the admin to reauth.php if needed
    $adminId = (int)$admin['id'];

    try {
        if ($act === 'decide' && $uid) {
            // One audited path for approve / keep pending / reject. Server recomputes the missing requirements.
            $res = staff_decide($uid, $adminId, (string)($_POST['decision'] ?? ''), $note, !empty($_POST['ack_missing']));
            flash($res['ok'] ? ($res['mail'] === 'failed' ? 'error' : 'ok') : 'error', $res['message']);
        } elseif ($act === 'revoke' && $uid) {
            if ($uid === $adminId) { flash('error', 'You cannot revoke your own access.'); }
            else { staff_revoke($uid, $adminId, $note); flash('ok', 'Access revoked. That account can no longer sign in.'); }
        } elseif ($act === 'bulk') {
            $n = staff_bulk_approve($adminId);
            flash('ok', $n . ' application(s) matching the official roster were approved.');
        } elseif ($act === 'set_role' && $uid) {
            $new = (string)($_POST['role'] ?? '');
            if ($uid === $adminId) { flash('error', 'You cannot change your own role.'); }
            elseif (!in_array($new, ['instructor', 'staff', 'admin'], true)) { flash('error', 'Invalid role.'); }
            else {
                $old = q('SELECT role FROM users WHERE id = ? AND status = "approved"', [$uid])->fetch();
                if ($old) {
                    q('UPDATE users SET role = ? WHERE id = ?', [$new, $uid]);
                    audit('role_changed', 'user', $uid, $old['role'] . ' -> ' . $new, $adminId);
                    flash('ok', 'Role updated.');
                }
            }
        } elseif ($act === 'roster_save') {
            [$fields, $why] = roster_validate($_POST);
            if ($why) { flash('error', $why); }
            else {
                try {
                    q('INSERT INTO staff_roster (employee_no, full_name, email, department, role, created_by) VALUES (?,?,?,?,?,?)', array_merge($fields, [$adminId]));
                    audit('roster_changed', 'roster', (int)db()->lastInsertId(), 'added ' . $fields[0], $adminId);
                    flash('ok', 'Added ' . $fields[1] . ' to the roster.');
                } catch (PDOException $dup) { flash('error', 'That employee number or email is already on the roster. Use Edit on the existing record.'); }
            }
        } elseif ($act === 'roster_update') {
            $res = roster_update((int)($_POST['id'] ?? 0), $_POST, $adminId); flash($res['ok'] ? 'ok' : 'error', $res['message']);
        } elseif ($act === 'roster_toggle') {
            $res = roster_set_active((int)($_POST['id'] ?? 0), !empty($_POST['active']), $adminId); flash($res['ok'] ? 'ok' : 'error', $res['message']);
        } elseif ($act === 'roster_delete') {
            $res = roster_delete((int)($_POST['id'] ?? 0), $adminId); flash($res['ok'] ? 'ok' : 'error', $res['message']);
        } elseif ($act === 'roster_password') {
            $res = roster_set_password((int)($_POST['id'] ?? 0), (string)($_POST['new_password'] ?? ''), (string)($_POST['confirm_password'] ?? ''), $adminId);
            flash($res['ok'] ? 'ok' : 'error', $res['message']);
        } elseif ($act === 'acct_status' && $uid) {
            $res = admin_account_status($uid, (string)($_POST['do'] ?? ''), $adminId); flash($res['ok'] ? 'ok' : 'error', $res['message']);
        } elseif ($act === 'acct_password' && $uid) {
            $res = admin_set_password($uid, (string)($_POST['new_password'] ?? ''), (string)($_POST['confirm_password'] ?? ''), $adminId);
            flash($res['ok'] ? 'ok' : 'error', $res['message']);
        } elseif ($act === 'acct_delete' && $uid) {
            $res = admin_account_delete($uid, $adminId); flash($res['ok'] ? 'ok' : 'error', $res['message']);
        } elseif ($act === 'audit_delete') {
            $res = audit_delete((array)($_POST['ids'] ?? []), $adminId); flash($res['ok'] ? 'ok' : 'error', $res['message']);
        }
    } catch (Throwable $e) {
        flash('error', 'That action could not be completed.');
        @file_put_contents(CN_ROOT . '/database/error.log', '[' . date('c') . '] verification: ' . $e->getMessage() . "\n", FILE_APPEND);
    }
    redirect($self);
}

/* ---------------- data ---------------- */
$pending = q("SELECT u.id, u.full_name, u.email, u.status, u.requested_role, u.created_at, a.employee_no, a.department,
                     a.chk_roster, a.chk_employee, a.chk_department, a.chk_role, a.chk_invite, a.review_note
                FROM users u JOIN staff_applications a ON a.user_id = u.id
               WHERE u.status IN ('pending_admin','pending_identity') AND u.email_verified_at IS NOT NULL
               ORDER BY FIELD(u.status,'pending_admin','pending_identity'), u.created_at")->fetchAll();
$waiting = q("SELECT COUNT(*) FROM users WHERE status = 'pending_email' AND requested_role <> 'student'")->fetchColumn();
$eligible = 0;
foreach ($pending as $p) {
    if ($p['status'] === 'pending_admin' && $p['chk_roster'] && $p['chk_employee'] && $p['chk_department'] && $p['chk_role']) $eligible++;
}
$reauthOk = reauth_fresh();

function chk(int $ok, string $label): string
{
    return '<span class="chk ' . ($ok ? 'yes' : 'no') . '">' . ($ok ? '✓' : '✗') . ' ' . e($label) . '</span>';
}

$dis = $reauthOk ? '' : ' disabled title="Confirm your password first"';

/** Shared account table with every management action. Used by the Students, Staff accounts and Active accounts views. */
function render_accounts_table(array $rows, array $admin, string $dis, bool $withRole): void
{
    ?>
    <div class="table-wrap"><table class="table">
      <thead><tr><th scope="col">Name</th><th scope="col">Email</th><th scope="col">Role</th><th scope="col">Status</th><th scope="col">Last sign in</th><th scope="col">Actions</th></tr></thead><tbody>
      <?php foreach ($rows as $s):
          $id = (int)$s['id'];
          $st = $s['status'] === 'suspended' ? 'Deactivated' : ucfirst(str_replace('_', ' ', (string)$s['status']));
          $isApplicant = $s['role'] === 'student' && in_array($s['requested_role'], ['instructor', 'staff'], true); ?>
        <tr><td><?= e($s['full_name']) ?></td><td><?= e($s['email']) ?></td>
          <td><?= e($isApplicant ? 'instructor (applicant)' : $s['role']) ?></td>
          <td><span class="pill <?= $s['status'] === 'approved' ? 'pill-live' : (in_array($s['status'], ['rejected', 'suspended'], true) ? 'pill-bad' : '') ?>"><?= e($st) ?></span></td>
          <td><?= $s['last_login'] ? e(date('M j, g:i A', strtotime($s['last_login']))) : '-' ?></td>
          <td class="actions">
          <?php if ($id === (int)$admin['id']): ?><span class="muted">You</span>
          <?php elseif ($s['role'] === 'admin'): ?><span class="muted">Administrator</span>
          <?php else: ?>
            <?php foreach ([['approve', 'Approve', $s['status'] !== 'approved' && $s['status'] !== 'suspended', ''],
                            ['reject', 'Reject', !in_array($s['status'], ['approved', 'rejected'], true), 'btn-danger'],
                            ['deactivate', 'Deactivate', $s['status'] === 'approved', ''],
                            ['activate', 'Activate', $s['status'] === 'suspended', '']] as [$do, $lab, $show, $cls]): if (!$show) continue; ?>
              <form method="post" class="inline"<?= $do === 'reject' || $do === 'deactivate' ? ' onsubmit="return confirm(\'' . $lab . ' ' . e(addslashes($s['full_name'])) . '?\');"' : '' ?>><?= csrf_field() ?><input type="hidden" name="a" value="acct_status"><input type="hidden" name="user_id" value="<?= $id ?>"><input type="hidden" name="do" value="<?= $do ?>">
                <button class="btn btn-ghost btn-small <?= $cls ?>" type="submit"<?= $dis ?>><?= $lab ?></button></form>
            <?php endforeach; ?>
            <details class="row-pop"><summary class="btn btn-ghost btn-small">Update password</summary>
              <form method="post" class="form pop-form" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="a" value="acct_password"><input type="hidden" name="user_id" value="<?= $id ?>">
                <label class="field">New password<input type="password" name="new_password" autocomplete="new-password" minlength="12" required></label>
                <label class="field">Confirm password<input type="password" name="confirm_password" autocomplete="new-password" minlength="12" required></label>
                <button class="btn btn-primary btn-small" type="submit"<?= $dis ?>>Set password</button></form></details>
            <?php if ($withRole && $s['status'] === 'approved'): ?>
              <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="a" value="set_role"><input type="hidden" name="user_id" value="<?= $id ?>">
                <label class="sr-only" for="r<?= $id ?>">Role</label>
                <select id="r<?= $id ?>" name="role"><?php foreach (['instructor', 'staff', 'admin'] as $ro): ?><option <?= $s['role'] === $ro ? 'selected' : '' ?>><?= $ro ?></option><?php endforeach; ?></select>
                <button class="btn btn-ghost btn-small" type="submit"<?= $dis ?>>Change role</button></form>
            <?php endif; ?>
            <form method="post" class="inline" onsubmit="return confirm('Permanently delete <?= e(addslashes($s['full_name'])) ?>’s account? This cannot be undone.');"><?= csrf_field() ?><input type="hidden" name="a" value="acct_delete"><input type="hidden" name="user_id" value="<?= $id ?>">
              <button class="btn btn-danger btn-small" type="submit"<?= $dis ?>>Delete</button></form>
          <?php endif; ?>
          </td></tr>
      <?php endforeach; ?>
      </tbody></table></div>
    <?php if (!$rows): ?><p class="muted">No accounts match this view.</p><?php endif;
}

render_head('Verification', 'verification');
?>
<div class="page-head"><div><h1>Verification</h1><p class="muted">Applications, the official roster, student and staff accounts, sign-ins and the audit trail</p></div></div>

<nav class="admin-tabs" aria-label="Verification sections">
  <?php foreach (['pending' => 'Applications', 'decisions' => 'Decisions', 'roster' => 'Official roster', 'students' => 'Students', 'staff' => 'Staff accounts', 'logins' => 'Sign-ins', 'audit' => 'Audit log'] as $k => $l): ?>
    <a href="verification.php?tab=<?= $k ?>" class="<?= $tab === $k ? 'is-active' : '' ?>"><?= e($l) ?><?= $k === 'pending' && $pending ? ' (' . count($pending) . ')' : '' ?></a>
  <?php endforeach; ?>
</nav>

<?php if (!$reauthOk): ?>
  <div class="notice notice-warn"><?= icon('lock') ?><div>Account actions ask for your password once every <?= (int)cfg('security.reauth_minutes', 10) ?> minutes. Buttons are disabled until you confirm it. <a class="hu" href="reauth.php?next=<?= e(rawurlencode($self)) ?>">Confirm password</a></div></div>
<?php endif; ?>

<?php if ($tab === 'pending'): ?>
  <section class="card">
    <div class="card-head"><h2>Applications waiting for you</h2>
      <?php if ($eligible): ?>
        <form method="post" onsubmit="return confirm('Approve <?= $eligible ?> application(s) that fully match the official roster?');">
          <?= csrf_field() ?><input type="hidden" name="a" value="bulk"><button class="btn btn-primary btn-small" type="submit"><?= icon('check') ?> Approve all <?= $eligible ?> matching the roster</button></form>
      <?php endif; ?>
    </div>
    <?php if ($waiting): ?><p class="muted"><?= (int)$waiting ?> applicant(s) have not confirmed their email yet. They appear here after they do.</p><?php endif; ?>
    <?php if (!$pending): ?><p class="muted">No applications are waiting. 🎉</p><?php endif; ?>
    <div class="app-list">
    <?php foreach ($pending as $p):
        $reqs = application_requirements((int)$p['id']);
        $missingAll = requirements_missing($reqs);
        $hardMissing = requirements_missing($reqs, true);
        $docs = app_documents((int)$p['id']); ?>
      <article class="app-card <?= $missingAll ? 'is-flag' : 'is-match' ?>">
        <header>
          <div><h3><?= e($p['full_name']) ?></h3><p class="muted"><?= e($p['email']) ?></p></div>
          <span class="pill <?= $p['status'] === 'pending_admin' ? 'pill-live' : 'pill-warn' ?>"><?= $p['status'] === 'pending_admin' ? 'Pending admin approval' : 'Kept pending: more info requested' ?></span>
        </header>
        <dl class="facts">
          <div><dt>Requested role</dt><dd><?= e($p['requested_role']) ?></dd></div>
          <div><dt>Employee ID</dt><dd><?= e($p['employee_no']) ?></dd></div>
          <div><dt>Department</dt><dd><?= e($p['department']) ?></dd></div>
          <div><dt>Applied</dt><dd><?= e(date('M j, g:i A', strtotime($p['created_at']))) ?></dd></div>
        </dl>
        <div class="req-box <?= $missingAll ? 'has-missing' : '' ?>">
          <h4><?= $missingAll ? count($missingAll) . ' requirement(s) missing' : 'All requirements met' ?></h4>
          <ul class="req-list">
          <?php foreach ($reqs as $r): ?>
            <li class="<?= $r['met'] ? 'ok' : 'miss' ?>"><span class="req-mark"><?= $r['met'] ? '✓' : '✗' ?></span>
              <span><strong><?= e($r['label']) ?></strong><?= $r['hard'] ? ' <em>(cannot be waived)</em>' : '' ?><small><?= e($r['detail']) ?></small></span></li>
          <?php endforeach; ?>
          </ul>
          <?php if ($docs): ?><p class="req-docs">Documents:
            <?php foreach ($docs as $d): ?><a class="hu" href="application-document.php?id=<?= (int)$d['id'] ?>"><?= e($d['original_name'] ?: $d['label']) ?></a> <?php endforeach; ?></p><?php endif; ?>
        </div>
        <?php if ($p['review_note']): ?><p class="muted">Last note: <?= e($p['review_note']) ?></p><?php endif; ?>
        <form method="post" class="decide" data-missing="<?= e(json_encode($missingAll, JSON_UNESCAPED_UNICODE)) ?>">
          <?= csrf_field() ?><input type="hidden" name="a" value="decide"><input type="hidden" name="user_id" value="<?= (int)$p['id'] ?>">
          <label class="field">Remarks (optional)
            <textarea name="remarks" maxlength="1000" rows="3" placeholder="Required for “Request more verification”: this text is emailed to the applicant as what is still needed. For Approve and Reject it stays internal."></textarea></label>
          <?php if ($missingAll && !$hardMissing): ?>
            <label class="ack"><input type="checkbox" name="ack_missing" value="1"> I understand the requirements listed above are missing, and I am approving as an authorized Admin exception. This will be recorded.</label>
          <?php endif; ?>
          <div class="btn-row">
            <button class="btn btn-primary" type="submit" name="decision" value="approve"<?= $dis ?><?= $hardMissing ? ' disabled title="Email is not verified"' : '' ?>>Approve</button>
            <button class="btn btn-ghost" type="submit" name="decision" value="pending"<?= $dis ?>>Request more verification</button>
            <button class="btn btn-danger" type="submit" name="decision" value="reject"<?= $dis ?>>Reject</button>
            <?php if (!$reauthOk): ?><a class="btn btn-ghost" href="reauth.php?next=<?= e(rawurlencode($self)) ?>">Confirm password to decide</a><?php endif; ?>
          </div>
        </form>
      </article>
    <?php endforeach; ?>
    </div>
  </section>

<?php elseif ($tab === 'decisions'): ?>
  <?php try { $decs = q("SELECT d.*, u.full_name AS applicant, u.email AS app_email, a.full_name AS admin_name
                           FROM application_decisions d LEFT JOIN users u ON u.id = d.user_id LEFT JOIN users a ON a.id = d.admin_id
                          ORDER BY d.id DESC LIMIT 300")->fetchAll(); $decErr = false; } catch (Throwable $ex) { $decs = []; $decErr = true; } ?>
  <section class="card">
    <div class="card-head"><h2>Decision history</h2></div>
    <p class="muted">Every approval, exception, rejection and “kept pending” decision with its date, time, remarks and the requirements that were missing at that moment.</p>
    <?php if ($decErr): ?><div class="notice notice-warn"><?= icon('alert') ?><div>The decision tables do not exist yet. Run <code>database/migrations/002_flexible_instructor_approval.sql</code> (see MIGRATION_GUIDE.md).</div></div><?php endif; ?>
    <div class="table-wrap"><table class="table">
      <thead><tr><th scope="col">When</th><th scope="col">Applicant</th><th scope="col">Decision</th><th scope="col">Missing at the time</th><th scope="col">Remarks</th><th scope="col">By</th><th scope="col">Email</th></tr></thead><tbody>
      <?php foreach ($decs as $d): $m = json_decode((string)$d['missing_requirements'], true) ?: [];
          $lbl = ['approved' => 'Approved', 'approved_exception' => 'Approved (exception)', 'rejected' => 'Rejected', 'kept_pending' => 'Kept pending'][$d['decision']] ?? $d['decision']; ?>
        <tr><td><?= e(date('M j, Y g:i:s A', strtotime($d['decided_at']))) ?></td><td><?= e($d['applicant'] ?? '-') ?><br><small class="muted"><?= e($d['app_email'] ?? '') ?></small></td>
          <td><span class="pill <?= $d['decision'] === 'rejected' ? 'pill-bad' : ($d['decision'] === 'approved_exception' ? 'pill-warn' : 'pill-live') ?>"><?= e($lbl) ?></span></td>
          <td><?= $m ? e(implode('; ', $m)) : '-' ?></td><td><?= e($d['remarks'] ?: '-') ?></td><td><?= e($d['admin_name'] ?? 'Automatic') ?></td>
          <td><?= e(['accepted_by_smtp' => 'Accepted by mail server', 'logged_locally' => 'Log mode (not sent)', 'failed' => 'Failed', 'pending' => 'Pending'][$d['email_status']] ?? $d['email_status']) ?></td></tr>
      <?php endforeach; ?>
      </tbody></table></div>
    <?php if (!$decs && !$decErr): ?><p class="muted">No decisions recorded yet.</p><?php endif; ?>
  </section>

<?php elseif ($tab === 'roster'): ?>
  <?php $roster = q('SELECT r.*, u.id AS acct_id, u.status AS acct_status FROM staff_roster r LEFT JOIN users u ON u.email = r.email ORDER BY r.full_name')->fetchAll(); ?>
  <section class="card">
    <div class="card-head"><h2>Official staff roster</h2><a class="btn btn-ghost btn-small" href="import.php?target=roster"><?= icon('upload') ?> Import from Excel, Word or CSV</a></div>
    <p class="muted">The trusted list of employees. You can edit any record, activate or deactivate it, set a password for the person’s account, or delete it.</p>
    <form method="post" class="form roster-form"><?= csrf_field() ?><input type="hidden" name="a" value="roster_save">
      <div class="field-row"><label class="field">Employee number<input name="employee_no" placeholder="EMP-002" required></label><label class="field">Full name<input name="full_name" required></label></div>
      <div class="field-row"><label class="field">Institutional email<input type="email" name="email" required></label><label class="field">Department<input name="department" required></label></div>
      <label class="field">Role<select name="role"><option value="instructor">Instructor</option><option value="staff">Staff</option></select></label>
      <button class="btn btn-primary btn-small" type="submit">Add to roster</button>
    </form>
    <div class="table-wrap"><table class="table">
      <thead><tr><th scope="col">Employee number</th><th scope="col">Full name</th><th scope="col">Institutional email</th><th scope="col">Department</th><th scope="col">Role</th><th scope="col">Account status</th><th scope="col">Actions</th></tr></thead>
      <tbody>
      <?php foreach ($roster as $r):
          $off = !$r['active'] || $r['acct_status'] === 'suspended';
          $stLabel = $off ? 'Deactivated' : ($r['acct_status'] === null ? 'No account yet' : ($r['acct_status'] === 'approved' ? 'Active' : ucfirst(str_replace('_', ' ', (string)$r['acct_status']))));
          $rid = (int)$r['id']; ?>
        <tr class="<?= $off ? 'is-off' : '' ?>">
          <td><?= e($r['employee_no']) ?></td><td><?= e($r['full_name']) ?></td><td><?= e($r['email']) ?></td><td><?= e($r['department']) ?></td><td><?= e($r['role']) ?></td>
          <td><span class="pill <?= $stLabel === 'Active' ? 'pill-live' : ($off ? 'pill-bad' : '') ?>"><?= e($stLabel) ?></span></td>
          <td class="actions">
            <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="a" value="roster_toggle"><input type="hidden" name="id" value="<?= $rid ?>"><input type="hidden" name="active" value="<?= $r['active'] && !$off ? 0 : 1 ?>">
              <button class="btn btn-ghost btn-small" type="submit"<?= $dis ?>><?= $r['active'] && !$off ? 'Deactivate' : 'Activate' ?></button></form>
            <details class="row-pop"><summary class="btn btn-ghost btn-small">Edit</summary>
              <form method="post" class="form pop-form"><?= csrf_field() ?><input type="hidden" name="a" value="roster_update"><input type="hidden" name="id" value="<?= $rid ?>">
                <label class="field">Employee number<input name="employee_no" value="<?= e($r['employee_no']) ?>" required></label>
                <label class="field">Full name<input name="full_name" value="<?= e($r['full_name']) ?>" required></label>
                <label class="field">Institutional email<input type="email" name="email" value="<?= e($r['email']) ?>" required></label>
                <label class="field">Department<input name="department" value="<?= e($r['department']) ?>" required></label>
                <label class="field">Role<select name="role"><?php foreach (['instructor', 'staff'] as $ro): ?><option value="<?= $ro ?>" <?= $r['role'] === $ro ? 'selected' : '' ?>><?= $ro ?></option><?php endforeach; ?></select></label>
                <button class="btn btn-primary btn-small" type="submit"<?= $dis ?>>Save changes</button></form></details>
            <details class="row-pop"><summary class="btn btn-ghost btn-small">Update password</summary>
              <?php if ($r['acct_id']): ?>
              <form method="post" class="form pop-form" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="a" value="roster_password"><input type="hidden" name="id" value="<?= $rid ?>">
                <label class="field">New password<input type="password" name="new_password" autocomplete="new-password" minlength="12" required></label>
                <label class="field">Confirm password<input type="password" name="confirm_password" autocomplete="new-password" minlength="12" required></label>
                <button class="btn btn-primary btn-small" type="submit"<?= $dis ?>>Set password</button></form>
              <?php else: ?><p class="muted pop-form">No account exists for this email yet.</p><?php endif; ?></details>
            <form method="post" class="inline" onsubmit="return confirm('Delete the roster record for <?= e(addslashes($r['full_name'])) ?>? Their account, if any, will be deactivated, not erased.');"><?= csrf_field() ?><input type="hidden" name="a" value="roster_delete"><input type="hidden" name="id" value="<?= $rid ?>">
              <button class="btn btn-danger btn-small" type="submit"<?= $dis ?>>Delete</button></form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php if (!$roster): ?><p class="muted">The roster is empty. Add an employee above or import a list.</p><?php endif; ?>
  </section>

<?php elseif (in_array($tab, ['students', 'staff', 'accounts'], true)): ?>
  <?php
    $where = []; $par = [];
    if ($tab === 'students') { $where[] = "u.role = 'student' AND u.requested_role = 'student'"; }
    elseif ($tab === 'staff') { $where[] = $roleF === 'instructor' ? "u.role IN ('instructor','staff')" : "u.role IN ('instructor','staff','admin')"; }
    elseif ($tab === 'accounts' && $roleF === 'instructor') { $where[] = "(u.role IN ('instructor','staff') OR u.requested_role IN ('instructor','staff'))"; }
    if ($f === 'approved') $where[] = "u.status = 'approved'";
    elseif ($f === 'pending') $where[] = "u.status IN ('pending_email','pending_identity','pending_admin')";
    elseif ($f === 'rejected') $where[] = "u.status = 'rejected'";
    elseif ($f === 'suspended') $where[] = "u.status = 'suspended'";
    elseif ($f === 'active7') $where[] = 'u.last_login >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
    if ($qs !== '') { $where[] = '(u.full_name LIKE ? OR u.email LIKE ?)'; $par[] = '%' . $qs . '%'; $par[] = '%' . $qs . '%'; }
    $sqlW = $where ? 'WHERE ' . implode(' AND ', $where) : '';
    $total = (int)q("SELECT COUNT(*) FROM users u $sqlW", $par)->fetchColumn();
    $rows = q("SELECT u.id, u.full_name, u.email, u.role, u.requested_role, u.status, u.activated_at, u.last_login, u.created_at FROM users u $sqlW ORDER BY u.role, u.full_name LIMIT 300", $par)->fetchAll();
    $titles = ['students' => 'Student accounts', 'staff' => $roleF === 'instructor' ? 'Instructor accounts' : 'Staff accounts', 'accounts' => $f === 'active7' ? 'Active accounts (signed in during the last 7 days)' : 'Accounts'];
    $base = 'verification.php?tab=' . $tab . ($roleF ? '&role=' . urlencode($roleF) : '');
    $chips = ['' => 'All', 'approved' => 'Approved', 'pending' => 'Pending', 'rejected' => 'Rejected', 'suspended' => 'Deactivated'];
  ?>
  <section class="card">
    <div class="card-head"><h2><?= e($titles[$tab]) ?></h2><span class="pill"><?= number_format($total) ?> account<?= $total === 1 ? '' : 's' ?></span></div>
    <?php if ($tab !== 'accounts'): ?>
    <div class="chips" role="group" aria-label="Filter by status">
      <?php foreach ($chips as $k => $l): ?><a class="chip <?= $f === $k ? 'is-on' : '' ?>" href="<?= e($base . ($k !== '' ? '&f=' . $k : '')) ?>"><?= e($l) ?></a><?php endforeach; ?>
    </div>
    <?php endif; ?>
    <form method="get" class="form search-row"><input type="hidden" name="tab" value="<?= e($tab) ?>"><?php if ($roleF): ?><input type="hidden" name="role" value="<?= e($roleF) ?>"><?php endif; ?><?php if ($f): ?><input type="hidden" name="f" value="<?= e($f) ?>"><?php endif; ?>
      <label class="sr-only" for="qs">Search name or email</label><input id="qs" name="q" value="<?= e($qs) ?>" placeholder="Search name or email" maxlength="80"><button class="btn btn-ghost btn-small" type="submit"><?= icon('search') ?> Search</button></form>
    <?php render_accounts_table($rows, $admin, $dis, $tab === 'staff'); ?>
    <?php if ($total > 300): ?><p class="muted">Showing the first 300 of <?= number_format($total) ?>. Use search to narrow the list.</p><?php endif; ?>
  </section>

<?php elseif ($tab === 'logins'): ?>
  <?php
    $conds = []; $par = [];
    if ($roleF === 'student') { $conds[] = "e.role = 'student'"; }
    elseif ($roleF === 'instructor') { $conds[] = "e.role IN ('instructor','staff')"; }
    elseif ($roleF === 'admin') { $conds[] = "e.role = 'admin'"; }
    if ($hrs > 0) { $conds[] = 'e.created_at >= DATE_SUB(NOW(), INTERVAL ' . (int)$hrs . ' HOUR)'; }
    $sqlW = $conds ? 'WHERE ' . implode(' AND ', $conds) : '';
    $loginErr = false; $events = []; $loginTotal = 0;
    try {
        $loginTotal = (int)q("SELECT COUNT(*) FROM login_events e $sqlW")->fetchColumn();
        $events = q("SELECT e.created_at, e.role, e.ip, u.full_name, u.email FROM login_events e LEFT JOIN users u ON u.id = e.user_id $sqlW ORDER BY e.id DESC LIMIT 300")->fetchAll();
    } catch (Throwable $ex) { $loginErr = true; }
    $rl = ['' => 'Everyone', 'student' => 'Students', 'instructor' => 'Instructors', 'admin' => 'Administrators'];
    $hl = [24 => '24 hours', 168 => '7 days', 720 => '30 days', 0 => 'All time'];
  ?>
  <section class="card">
    <div class="card-head"><h2>Sign-ins</h2><span class="pill"><?= number_format($loginTotal) ?> sign-in<?= $loginTotal === 1 ? '' : 's' ?></span></div>
    <p class="muted">Every successful sign-in, recorded from the time migration 003 was applied.</p>
    <div class="chips"><?php foreach ($rl as $k => $l): ?><a class="chip <?= $roleF === $k ? 'is-on' : '' ?>" href="<?= e('verification.php?tab=logins&h=' . $hrs . ($k !== '' ? '&role=' . $k : '')) ?>"><?= e($l) ?></a><?php endforeach; ?></div>
    <div class="chips"><?php foreach ($hl as $k => $l): ?><a class="chip <?= $hrs === $k ? 'is-on' : '' ?>" href="<?= e('verification.php?tab=logins&h=' . $k . ($roleF !== '' ? '&role=' . $roleF : '')) ?>"><?= e($l) ?></a><?php endforeach; ?></div>
    <?php if ($loginErr): ?><div class="notice notice-warn"><?= icon('alert') ?><div>The sign-in table does not exist yet. Run <code>database/migrations/003_admin_controls_and_statistics.sql</code>.</div></div><?php endif; ?>
    <div class="table-wrap"><table class="table"><thead><tr><th scope="col">When</th><th scope="col">Account</th><th scope="col">Role</th><th scope="col">IP</th></tr></thead><tbody>
      <?php foreach ($events as $ev): ?><tr><td><?= e(date('M j, Y g:i:s A', strtotime($ev['created_at']))) ?></td><td><?= e($ev['full_name'] ?? '(deleted account)') ?><br><small class="muted"><?= e($ev['email'] ?? '') ?></small></td><td><?= e($ev['role']) ?></td><td><?= e($ev['ip']) ?></td></tr><?php endforeach; ?>
    </tbody></table></div>
    <?php if (!$events && !$loginErr): ?><p class="muted">No sign-ins match this filter.</p><?php endif; ?>
  </section>

<?php else: ?>
  <?php $log = q('SELECT l.*, a.full_name AS actor FROM audit_log l LEFT JOIN users a ON a.id = l.actor_id ORDER BY l.id DESC LIMIT 200')->fetchAll(); ?>
  <section class="card">
    <div class="card-head"><h2>Audit log</h2><span class="pill">Latest <?= count($log) ?></span></div>
    <p class="muted">Approvals, rejections, account and password changes, deletions and suspicious attempts. Passwords, codes and full tokens are never recorded. Only an administrator can delete entries, and every deletion is itself logged.</p>
    <form method="post" id="auditForm" onsubmit="var n=this.querySelectorAll('input[name=&quot;ids[]&quot;]:checked').length; if(!n){alert('Select at least one entry.');return false;} return confirm('Permanently delete '+n+' audit log entr'+(n===1?'y':'ies')+'? This cannot be undone.');">
      <?= csrf_field() ?><input type="hidden" name="a" value="audit_delete">
      <div class="btn-row"><button class="btn btn-danger btn-small" type="submit"<?= $dis ?>>Delete selected</button></div>
      <div class="table-wrap"><table class="table">
        <thead><tr><th scope="col"><input type="checkbox" id="auditAll" aria-label="Select all entries"></th><th scope="col">When</th><th scope="col">Who</th><th scope="col">What</th><th scope="col">Details</th><th scope="col">IP</th><th scope="col"></th></tr></thead><tbody>
        <?php foreach ($log as $l): ?>
          <tr><td><input type="checkbox" name="ids[]" value="<?= (int)$l['id'] ?>" aria-label="Select entry <?= (int)$l['id'] ?>"></td>
            <td><?= e(date('M j, g:i:s A', strtotime($l['created_at']))) ?></td><td><?= e($l['actor'] ?? '-') ?></td><td><?= e($l['action']) ?></td><td><?= e($l['detail']) ?></td><td><?= e($l['ip']) ?></td>
            <td><button class="btn btn-ghost btn-small" type="submit" name="ids[]" value="<?= (int)$l['id'] ?>" formnovalidate onclick="return confirmOne(this)"<?= $dis ?>>Delete</button></td></tr>
        <?php endforeach; ?>
        </tbody></table></div>
    </form>
    <?php if (!$log): ?><p class="muted">The audit log is empty.</p><?php endif; ?>
  </section>
<?php endif; ?>
<script>
(function () {
  var all = document.getElementById('auditAll');
  if (all) all.addEventListener('change', function () { document.querySelectorAll('input[name="ids[]"][type=checkbox]').forEach(function (c) { c.checked = all.checked; }); });
})();
// The per-row Delete button submits only its own id: uncheck every box first so the page-level confirm counts correctly.
function confirmOne(btn) {
  if (!confirm('Permanently delete this audit log entry? This cannot be undone.')) return false;
  var f = btn.form; f.onsubmit = null;
  f.querySelectorAll('input[type=checkbox][name="ids[]"]').forEach(function (c) { c.checked = false; });
  return true;
}
</script>
<script>
document.querySelectorAll('form.decide').forEach(function (f) {
  f.addEventListener('submit', function (ev) {
    var d = ev.submitter && ev.submitter.value; if (!d) return;
    var missing = []; try { missing = JSON.parse(f.getAttribute('data-missing') || '[]'); } catch (e) {}
    var msg = '';
    if (d === 'approve') msg = missing.length ? 'Approve despite ' + missing.length + ' missing item(s)?\n\n- ' + missing.join('\n- ') + '\n\nThis is recorded with your name, the time and your remarks.' : 'Approve this application?';
    else if (d === 'reject') msg = 'Reject this application? The applicant will be emailed.';
    else if (!f.remarks.value.trim()) { alert('Write what is still needed. The applicant is emailed this text.'); ev.preventDefault(); return; }
    if (msg && !confirm(msg)) ev.preventDefault();
  });
});
</script>
<?php render_foot('verification'); ?>
