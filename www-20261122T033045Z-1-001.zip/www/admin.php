<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/locations.php';
require __DIR__ . '/includes/schedule.php';

$admin = require_staff();
preview_block_writes('admin.php');
$isAdmin = is_admin($admin) && empty($admin['preview']);   // an admin previewing the Instructor dashboard sees the instructor view

const DAY_OPTIONS = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday'];

/* ------------------------------------------------------------------ */
/* Table definitions: one entry per manageable table.                  */
/* 'list' = SQL for the table view (first column must be id).           */
/* 'fields' = what appears in the add/edit form.                        */
/* ------------------------------------------------------------------ */
$FK = [
    'sections'    => "SELECT id, code AS label FROM sections ORDER BY code",
    'subjects'    => "SELECT id, CONCAT(code, ' - ', title) AS label FROM subjects ORDER BY code",
    'instructors' => "SELECT id, full_name AS label FROM instructors ORDER BY full_name",
    'buildings'   => "SELECT id, name AS label FROM locations WHERE type = 'building' ORDER BY name",
    'places'      => "SELECT l.id, CONCAT(l.name, IFNULL(CONCAT(' (', p.name, ')'), '')) AS label
                        FROM locations l LEFT JOIN locations p ON p.id = l.parent_id
                       ORDER BY IFNULL(p.name, l.name), l.name",
    'nodes'       => "SELECT id, name AS label FROM path_nodes ORDER BY name",
    'records'     => "SELECT id, CONCAT(student_no, ' - ', last_name, ', ', first_name) AS label FROM student_records ORDER BY student_no",
];

$TABLES = [
    'schedules' => [
        'label' => 'Schedules',
        'singular' => 'class',
        'list' => "SELECT s.id, sec.code AS Block, sub.code AS Subject, IFNULL(ins.full_name, '-') AS Instructor,
                          IFNULL(CONCAT(r.name, IFNULL(CONCAT(', ', b.name), '')), '-') AS Room,
                          ELT(s.day_of_week, 'Mon','Tue','Wed','Thu','Fri','Sat','Sun') AS Day,
                          CONCAT(TIME_FORMAT(s.start_time, '%l:%i %p'), ' - ', TIME_FORMAT(s.end_time, '%l:%i %p')) AS Time
                     FROM schedules s
                     JOIN sections sec ON sec.id = s.section_id
                     JOIN subjects sub ON sub.id = s.subject_id
                     LEFT JOIN instructors ins ON ins.id = s.instructor_id
                     LEFT JOIN locations r ON r.id = s.room_id
                     LEFT JOIN locations b ON b.id = r.parent_id
                    /*SCOPE*/
                    ORDER BY sec.code, s.day_of_week, s.start_time LIMIT 500",
        'fields' => [
            'section_id'    => ['label' => 'Block / section', 'type' => 'fk', 'fk' => 'sections'],
            'subject_id'    => ['label' => 'Subject', 'type' => 'fk', 'fk' => 'subjects'],
            'instructor_id' => ['label' => 'Instructor', 'type' => 'fk', 'fk' => 'instructors', 'null' => true],
            'room_id'       => ['label' => 'Room / place', 'type' => 'fk', 'fk' => 'places', 'null' => true],
            'day_of_week'   => ['label' => 'Day', 'type' => 'select', 'options' => DAY_OPTIONS],
            'start_time'    => ['label' => 'Starts', 'type' => 'time'],
            'end_time'      => ['label' => 'Ends', 'type' => 'time'],
        ],
    ],
    'locations' => [
        'label' => 'Locations',
        'singular' => 'location',
        'list' => "SELECT l.id, l.name AS Name, l.type AS Type, IFNULL(p.name, '-') AS Building,
                          IFNULL(l.floor, '-') AS Floor, IF(l.lat IS NULL AND p.lat IS NULL, 'No', 'Yes') AS Mapped
                     FROM locations l LEFT JOIN locations p ON p.id = l.parent_id
                    ORDER BY FIELD(l.type, 'building','facility','office','lab','room'), IFNULL(p.name, l.name), l.name LIMIT 500",
        'fields' => [
            'name'        => ['label' => 'Name', 'type' => 'text', 'max' => 120],
            'type'        => ['label' => 'Type', 'type' => 'select', 'options' => ['building' => 'Building', 'room' => 'Room', 'lab' => 'Laboratory', 'office' => 'Office', 'facility' => 'Facility']],
            'parent_id'   => ['label' => 'Inside building', 'type' => 'fk', 'fk' => 'buildings', 'null' => true, 'help' => 'For rooms, labs and offices. Leave empty for buildings.'],
            'floor'       => ['label' => 'Floor (1 = ground)', 'type' => 'number', 'null' => true],
            'keywords'    => ['label' => 'Search words', 'type' => 'text', 'empty' => true, 'help' => 'Comma-separated, e.g. registrar, enrollment, records'],
            'description' => ['label' => 'Description', 'type' => 'text', 'empty' => true],
            'hint'        => ['label' => 'Indoor hint', 'type' => 'text', 'empty' => true, 'help' => 'Shown in directions, e.g. "Second door after the stairs".'],
            'lat'         => ['label' => 'Latitude', 'type' => 'number', 'null' => true, 'step' => 'any', 'help' => 'Buildings need a position. Rooms use their building\'s.'],
            'lng'         => ['label' => 'Longitude', 'type' => 'number', 'null' => true, 'step' => 'any'],
            'node_id'     => ['label' => 'Entrance on walkway', 'type' => 'fk', 'fk' => 'nodes', 'null' => true, 'help' => 'The walkway point where people enter this building.'],
        ],
    ],
    'path_nodes' => [
        'label' => 'Walkway points',
        'singular' => 'walkway point',
        'list' => "SELECT id, name AS Name, lat AS Latitude, lng AS Longitude, IF(is_entry = 1, 'Yes', '') AS `Campus entrance` FROM path_nodes ORDER BY name",
        'fields' => [
            'name'     => ['label' => 'Name', 'type' => 'text', 'max' => 100],
            'lat'      => ['label' => 'Latitude', 'type' => 'number', 'step' => 'any'],
            'lng'      => ['label' => 'Longitude', 'type' => 'number', 'step' => 'any'],
            'is_entry' => ['label' => 'Campus entrance?', 'type' => 'select', 'options' => [0 => 'No', 1 => 'Yes'], 'help' => 'Routes start here when GPS is off.'],
        ],
    ],
    'path_edges' => [
        'label' => 'Walkways',
        'singular' => 'walkway',
        'list' => "SELECT e.id, a.name AS `From`, b.name AS `To`
                     FROM path_edges e JOIN path_nodes a ON a.id = e.node_a JOIN path_nodes b ON b.id = e.node_b ORDER BY a.name, b.name",
        'fields' => [
            'node_a' => ['label' => 'From', 'type' => 'fk', 'fk' => 'nodes'],
            'node_b' => ['label' => 'To', 'type' => 'fk', 'fk' => 'nodes'],
        ],
    ],
    'subjects' => [
        'label' => 'Subjects',
        'singular' => 'subject',
        'list' => "SELECT id, code AS Code, title AS Title, units AS Units FROM subjects ORDER BY code",
        'fields' => [
            'code'  => ['label' => 'Code', 'type' => 'text', 'max' => 30],
            'title' => ['label' => 'Title', 'type' => 'text', 'max' => 150],
            'units' => ['label' => 'Units', 'type' => 'number', 'step' => '0.5'],
        ],
    ],
    'sections' => [
        'label' => 'Blocks',
        'singular' => 'block',
        'list' => "SELECT s.id, s.code AS Block, s.program AS Program, s.year_level AS Year,
                          (SELECT COUNT(*) FROM student_records r WHERE r.section_id = s.id) AS Students
                     FROM sections s ORDER BY s.code",
        'fields' => [
            'code'       => ['label' => 'Block code', 'type' => 'text', 'max' => 40],
            'program'    => ['label' => 'Program', 'type' => 'text', 'max' => 120, 'empty' => true],
            'year_level' => ['label' => 'Year level', 'type' => 'number'],
        ],
    ],
    'instructors' => [
        'label' => 'Instructors',
        'singular' => 'instructor',
        'list' => "SELECT id, employee_no AS `Employee no.`, full_name AS Name, email AS Email, department AS Department FROM instructors ORDER BY full_name",
        'fields' => [
            'employee_no' => ['label' => 'Employee number', 'type' => 'text', 'max' => 30],
            'full_name'   => ['label' => 'Full name', 'type' => 'text', 'max' => 150],
            'email'       => ['label' => 'Email address', 'type' => 'email', 'help' => 'The instructor can use any valid email address to sign in.'],
            'department'  => ['label' => 'Department', 'type' => 'text', 'max' => 120, 'empty' => true],
        ],
    ],
    'student_records' => [
        'label' => 'Student records',
        'singular' => 'student record',
        'list' => "SELECT r.id, r.student_no AS `Student ID`, r.last_name AS `Last name`, r.first_name AS `First name`,
                          IFNULL(s.code, '-') AS Block,
                          IF(u.id IS NULL, 'Not yet', 'Linked') AS Account
                     FROM student_records r
                     LEFT JOIN sections s ON s.id = r.section_id
                     LEFT JOIN users u ON u.student_record_id = r.id
                    ORDER BY r.student_no LIMIT 1000",
        'fields' => [
            'student_no' => ['label' => 'Student ID', 'type' => 'text', 'max' => 30],
            'last_name'  => ['label' => 'Last name', 'type' => 'text', 'max' => 80],
            'first_name' => ['label' => 'First name', 'type' => 'text', 'max' => 80],
            'section_id' => ['label' => 'Block / section', 'type' => 'fk', 'fk' => 'sections', 'null' => true, 'help' => 'Changing the block updates the student\'s schedule right away.'],
        ],
    ],
    'calendar_events' => [
        'label' => 'Calendar',
        'singular' => 'calendar date',
        'list' => "SELECT id, title AS Title, category AS Category, start_date AS Starts, end_date AS Ends, description AS Notes
                     FROM calendar_events ORDER BY start_date DESC, title LIMIT 500",
        'fields' => [
            'title'       => ['label' => 'Title', 'type' => 'text', 'max' => 150],
            'category'    => ['label' => 'Type', 'type' => 'select', 'options' => ['academic' => 'Academic date', 'exam' => 'Examination', 'holiday' => 'Holiday', 'event' => 'Event']],
            'start_date'  => ['label' => 'Starts on', 'type' => 'date'],
            'end_date'    => ['label' => 'Ends on', 'type' => 'date', 'help' => 'Same as the start date for a single day.'],
            'description' => ['label' => 'Notes', 'type' => 'text', 'empty' => true, 'max' => 250],
        ],
    ],
];

// Instructors manage their own schedules only; academic data is admin-owned/imported.
if (!$isAdmin) {
    foreach (array_keys($TABLES) as $k) {
        if ($k !== 'schedules') unset($TABLES[$k]);
    }
}

/* ---------------- helpers ---------------- */
function admin_url(string $t, array $extra = []): string
{
    return 'admin.php?' . http_build_query(array_merge(['t' => $t], $extra));
}

function place_name(?int $id): string
{
    if (!$id) return 'no room';
    $r = q('SELECT l.name, p.name AS b FROM locations l LEFT JOIN locations p ON p.id = l.parent_id WHERE l.id = ?', [$id])->fetch();
    return $r ? $r['name'] . ($r['b'] ? ', ' . $r['b'] : '') : 'no room';
}

function instructor_name(?int $id): string
{
    if (!$id) return 'no instructor';
    $r = q('SELECT full_name FROM instructors WHERE id = ?', [$id])->fetch();
    return $r ? $r['full_name'] : 'no instructor';
}

function section_code(?int $id): string
{
    $r = $id ? q('SELECT code FROM sections WHERE id = ?', [$id])->fetch() : null;
    return $r ? $r['code'] : 'unknown block';
}

function subject_code(?int $id): string
{
    $r = $id ? q('SELECT code FROM subjects WHERE id = ?', [$id])->fetch() : null;
    return $r ? $r['code'] : 'class';
}

function collect_values(array $fields, array $post, array &$errors): array
{
    $vals = [];
    foreach ($fields as $name => $f) {
        $raw = trim((string)($post[$name] ?? ''));
        if ($raw === '') {
            if (!empty($f['null'])) { $vals[$name] = null; continue; }
            if (!empty($f['empty'])) { $vals[$name] = ''; continue; }
            $errors[] = $f['label'] . ' is required.';
            continue;
        }
        switch ($f['type']) {
            case 'number':
                if (!is_numeric($raw)) { $errors[] = $f['label'] . ' must be a number.'; break; }
                $vals[$name] = $raw + 0;
                break;
            case 'time':
                if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/', $raw)) { $errors[] = $f['label'] . ' must be a time like 08:30.'; break; }
                $vals[$name] = strlen($raw) === 5 ? $raw . ':00' : $raw;
                break;
            case 'date':
                $dt = DateTimeImmutable::createFromFormat('!Y-m-d', $raw);
                if (!$dt || $dt->format('Y-m-d') !== $raw) { $errors[] = $f['label'] . ' must be a date.'; break; }
                $vals[$name] = $raw;
                break;
            case 'email':
                if (!filter_var($raw, FILTER_VALIDATE_EMAIL)) { $errors[] = $f['label'] . ' must be a valid email.'; break; }
                $vals[$name] = strtolower($raw);
                break;
            case 'select':
                if (!array_key_exists($raw, $f['options'])) { $errors[] = $f['label'] . ' has an invalid choice.'; break; }
                $vals[$name] = $raw;
                break;
            case 'fk':
                $vals[$name] = (int)$raw;
                break;
            default:
                $vals[$name] = mb_substr($raw, 0, (int)($f['max'] ?? 255));
        }
    }
    return $vals;
}

/** Overlapping classes for the same room, instructor or block. */
function schedule_conflicts(array $v, int $ignoreId): array
{
    $out = [];
    if ($v['end_time'] <= $v['start_time']) {
        return ['The class must end after it starts.'];
    }
    $rows = q(SCHEDULE_SELECT . ' WHERE s.day_of_week = ? AND s.start_time < ? AND s.end_time > ? AND s.id <> ?',
        [$v['day_of_week'], $v['end_time'], $v['start_time'], $ignoreId])->fetchAll();
    foreach ($rows as $r) {
        $when = $r['subject_code'] . ' (' . $r['section_code'] . ') ' . fmt_time($r['start_time']) . ' to ' . fmt_time($r['end_time']);
        if ($v['room_id'] && (int)$r['room_id'] === (int)$v['room_id']) {
            $out[] = 'Room conflict: ' . $r['room_name'] . ' is already used by ' . $when . '.';
        }
        if ($v['instructor_id'] && (int)$r['instructor_id'] === (int)$v['instructor_id']) {
            $out[] = 'Instructor conflict: ' . $r['instructor_name'] . ' already teaches ' . $when . '.';
        }
        if ((int)$r['section_id'] === (int)$v['section_id']) {
            $out[] = 'Block conflict: ' . $r['section_code'] . ' already has ' . $when . '.';
        }
    }
    return array_values(array_unique($out));
}

function log_change(?int $scheduleId, ?int $sectionId, ?int $instructorId, string $summary, int $by, ?int $recordId = null): void
{
    q('INSERT INTO schedule_changes (schedule_id, section_id, instructor_id, record_id, summary, changed_by) VALUES (?,?,?,?,?,?)',
        [$scheduleId, $sectionId, $instructorId, $recordId, mb_substr($summary, 0, 255), $by]);
}

/** Students who were given a class individually also hear about changes to it. */
function notify_individuals(int $scheduleId, string $summary, int $by): void
{
    foreach (q('SELECT record_id FROM student_classes WHERE schedule_id = ?', [$scheduleId])->fetchAll() as $r) {
        log_change($scheduleId, null, null, $summary, $by, (int)$r['record_id']);
    }
}

function describe_slot(array $v): string
{
    return day_short((int)$v['day_of_week']) . ' ' . fmt_time($v['start_time']) . '-' . fmt_time($v['end_time']);
}

function log_schedule_save(?array $old, array $new, int $newId, int $by): void
{
    $code = subject_code((int)$new['subject_id']);
    if ($old === null) {
        log_change($newId, (int)$new['section_id'], $new['instructor_id'] ? (int)$new['instructor_id'] : null,
            "New class: {$code}, " . describe_slot($new) . ', ' . place_name($new['room_id'] ? (int)$new['room_id'] : null) . '.', $by);
        return;
    }
    $parts = [];
    if ((int)$old['room_id'] !== (int)$new['room_id']) {
        $parts[] = 'room changed from ' . place_name($old['room_id'] ? (int)$old['room_id'] : null) . ' to ' . place_name($new['room_id'] ? (int)$new['room_id'] : null);
    }
    if ((int)$old['instructor_id'] !== (int)$new['instructor_id']) {
        $parts[] = 'instructor changed from ' . instructor_name($old['instructor_id'] ? (int)$old['instructor_id'] : null) . ' to ' . instructor_name($new['instructor_id'] ? (int)$new['instructor_id'] : null);
    }
    if ((int)$old['day_of_week'] !== (int)$new['day_of_week'] || $old['start_time'] !== $new['start_time'] || $old['end_time'] !== $new['end_time']) {
        $parts[] = 'time changed from ' . describe_slot($old) . ' to ' . describe_slot($new);
    }
    if ((int)$old['subject_id'] !== (int)$new['subject_id']) {
        $parts[] = 'subject changed from ' . subject_code((int)$old['subject_id']) . ' to ' . $code;
    }
    $sectionMoved = (int)$old['section_id'] !== (int)$new['section_id'];
    if ($sectionMoved) {
        $parts[] = 'block changed from ' . section_code((int)$old['section_id']) . ' to ' . section_code((int)$new['section_id']);
    }
    if (!$parts) return;

    $summary = $code . ': ' . implode('; ', $parts) . '.';
    log_change($newId, (int)$new['section_id'], $new['instructor_id'] ? (int)$new['instructor_id'] : null, $summary, $by);
    notify_individuals($newId, $summary, $by);

    // People who lose the class should hear about it too.
    if ($sectionMoved) {
        log_change($newId, (int)$old['section_id'], null, "{$code} was moved out of your block.", $by);
    }
    if ((int)$old['instructor_id'] && (int)$old['instructor_id'] !== (int)$new['instructor_id']) {
        log_change($newId, null, (int)$old['instructor_id'], "{$code} (" . section_code((int)$new['section_id']) . ") was reassigned to another instructor.", $by);
    }
}

/* ---------------- request handling ---------------- */
$t = (string)($_GET['t'] ?? $_POST['t'] ?? 'schedules');
if (!isset($TABLES[$t])) $t = 'schedules';
$T = $TABLES[$t];
$ownInstructor = $admin['instructor_id'] ? (int)$admin['instructor_id'] : 0;
if ($t === 'schedules' && !$isAdmin) {
    // Instructors see only their own classes. They may request day/time/room changes; admin owns structure.
    unset($T['fields']['instructor_id']);
    $T['list'] = str_replace('/*SCOPE*/', 'WHERE s.instructor_id = ' . $ownInstructor, $T['list']);
    $T['create'] = false;
    $T['delete'] = false;
} else {
    $T['list'] = str_replace('/*SCOPE*/', '', $T['list']);
}
$errors = [];
$formValues = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $act = (string)($_POST['a'] ?? '');
    $id  = (int)($_POST['id'] ?? 0);

    try {
        // Give a student an extra class / take it away
        if (($act === 'add_class' || $act === 'remove_class') && $t === 'student_records' && $id > 0) {
            $sid = (int)($_POST['schedule_id'] ?? 0);
            $sched = q(SCHEDULE_SELECT . ' WHERE s.id = ?', [$sid])->fetch();
            $rec = q('SELECT * FROM student_records WHERE id = ?', [$id])->fetch();
            if (!$sched || !$rec || (!$isAdmin && (int)$sched['instructor_id'] !== $ownInstructor)) {
                flash('error', 'You can only add or remove classes that you teach.');
            } elseif ($act === 'add_class') {
                $clash = [];
                $mine = q(SCHEDULE_SELECT . ' WHERE (s.section_id = ? OR s.id IN (SELECT schedule_id FROM student_classes WHERE record_id = ?))
                                               AND s.day_of_week = ? AND s.start_time < ? AND s.end_time > ?',
                    [$rec['section_id'] ?? 0, $id, $sched['day_of_week'], $sched['end_time'], $sched['start_time']])->fetchAll();
                foreach ($mine as $m) $clash[] = $m['subject_code'] . ' ' . fmt_time($m['start_time']) . '-' . fmt_time($m['end_time']);
                if ($clash) {
                    flash('error', 'This overlaps with the student\'s existing class: ' . implode(', ', $clash) . '.');
                } else {
                    q('INSERT IGNORE INTO student_classes (record_id, schedule_id, added_by) VALUES (?,?,?)', [$id, $sid, $admin['id']]);
                    log_change($sid, null, null, 'Added to your schedule: ' . $sched['subject_code'] . ', ' . day_short((int)$sched['day_of_week']) . ' ' . fmt_time($sched['start_time']) . ', ' . ($sched['room_name'] ?? 'room TBA') . '.', (int)$admin['id'], $id);
                    flash('ok', $sched['subject_code'] . ' added to ' . $rec['first_name'] . ' ' . $rec['last_name'] . '. It shows in their schedule right away.');
                }
            } else {
                q('DELETE FROM student_classes WHERE record_id = ? AND schedule_id = ?', [$id, $sid]);
                log_change($sid, null, null, 'Removed from your schedule: ' . $sched['subject_code'] . '.', (int)$admin['id'], $id);
                flash('ok', 'Class removed from this student.');
            }
            redirect(admin_url('student_records', ['a' => 'classes', 'id' => $id]));
        }

        if ($act === 'delete' && ($T['delete'] ?? true) && $id > 0) {
            if ($t === 'schedules' && !$isAdmin) {
                $own = q('SELECT instructor_id FROM schedules WHERE id = ?', [$id])->fetch();
                if (!$own || (int)$own['instructor_id'] !== $ownInstructor) {
                    flash('error', 'You can only delete your own classes.');
                    redirect(admin_url($t));
                }
            }
            if ($t === 'schedules') {
                $old = q('SELECT * FROM schedules WHERE id = ?', [$id])->fetch();
                if ($old) {
                    log_change(null, (int)$old['section_id'], $old['instructor_id'] ? (int)$old['instructor_id'] : null,
                        'Class removed: ' . subject_code((int)$old['subject_id']) . ', ' . describe_slot($old) . '.', (int)$admin['id']);
                }
            }
            q("DELETE FROM `$t` WHERE id = ?", [$id]);
            flash('ok', 'Deleted.');
            redirect(admin_url($t));
        }

        if ($act === 'save') {
            if ($t === 'schedules' && !$isAdmin) {
                $errors[] = 'Instructors cannot change schedules. These records are managed by the administrator.';
            }
            $vals = collect_values($T['fields'], $_POST, $errors);
            if ($t === 'calendar_events' && isset($vals['start_date'], $vals['end_date']) && $vals['end_date'] < $vals['start_date']) {
                $errors[] = 'The end date cannot be before the start date.';
            }
            if ($t === 'users' && !$isAdmin) { $errors[] = 'Administrators only.'; }
            if ($id === 0 && $t === 'student_records') { $vals['added_by'] = (int)$admin['id']; }
            if ($id === 0 && $t === 'calendar_events') { $vals['created_by'] = (int)$admin['id']; }

            if ($t === 'users' && $id === (int)$admin['id'] && ($vals['role'] ?? 'admin') !== 'admin') {
                $errors[] = 'You cannot remove your own administrator role.';
            }
            if ($t === 'locations' && ($vals['type'] ?? '') === 'building' && !empty($vals['parent_id'])) {
                $errors[] = 'A building cannot be inside another building.';
            }
            if ($t === 'locations' && ($vals['type'] ?? '') === 'building' && ($vals['lat'] === null || $vals['lng'] === null)) {
                $errors[] = 'A building needs a latitude and longitude so it can appear on the map.';
            }
            if ($t === 'locations' && isset($vals['parent_id']) && (int)$vals['parent_id'] === $id && $id > 0) {
                $errors[] = 'A place cannot be inside itself.';
            }
            if ($t === 'path_edges' && isset($vals['node_a'], $vals['node_b']) && $vals['node_a'] === $vals['node_b']) {
                $errors[] = 'Choose two different walkway points.';
            }
            if ($t === 'schedules' && !$errors) {
                $errors = schedule_conflicts($vals, $id);
            }

            if (!$errors) {
                $old = ($t === 'schedules' && $id > 0) ? q('SELECT * FROM schedules WHERE id = ?', [$id])->fetch() : null;
                $cols = array_keys($vals);
                if ($id > 0) {
                    $set = implode(', ', array_map(fn($c) => "`$c` = ?", $cols));
                    q("UPDATE `$t` SET $set WHERE id = ?", array_merge(array_values($vals), [$id]));
                    $newId = $id;
                } else {
                    $ph = implode(', ', array_fill(0, count($cols), '?'));
                    q("INSERT INTO `$t` (`" . implode('`, `', $cols) . "`) VALUES ($ph)", array_values($vals));
                    $newId = (int)db()->lastInsertId();
                }
                if ($t === 'schedules') {
                    log_schedule_save($old ?: null, $vals, $newId, (int)$admin['id']);
                }
                if ($t === 'student_records' && $id > 0) {
                    // Block changed? Affected student sees it immediately; nothing else to sync.
                }
                flash('ok', 'Saved.' . ($t === 'schedules' ? ' Students and instructors see the change right away.' : ''));
                redirect(admin_url($t));
            }
            $formValues = $_POST;
            $_GET['a'] = $id > 0 ? 'edit' : 'new';
            $_GET['id'] = (string)$id;
        }
    } catch (PDOException $e) {
        $code = (int)($e->errorInfo[1] ?? 0);
        if ($code === 1062) {
            $errors[] = 'That value already exists. It must be unique.';
        } elseif ($code === 1451) {
            $errors[] = 'This cannot be deleted because other records depend on it.';
        } elseif ($code === 1452) {
            $errors[] = 'One of the selected items no longer exists.';
        } else {
            $errors[] = 'The database refused that change.';
        }
        $formValues = $_POST;
        $_GET['a'] = $id > 0 ? 'edit' : 'new';
        $_GET['id'] = (string)$id;
    }
}

$a  = (string)($_GET['a'] ?? 'list');
$id = (int)($_GET['id'] ?? 0);
if (!in_array($a, ['list', 'new', 'edit', 'roster', 'classes'], true)) $a = 'list';
if ($a === 'roster' && $t !== 'schedules') $a = 'list';
if ($a === 'classes' && $t !== 'student_records') $a = 'list';
if ($a === 'new' && !($T['create'] ?? true)) $a = 'list';

$edit = null;
if ($a === 'edit') {
    if ($t === 'schedules' && !$isAdmin) {
        flash('error', 'Schedules are assigned by the administrator.');
        redirect(admin_url($t));
    }
    $edit = q("SELECT * FROM `$t` WHERE id = ?", [$id])->fetch();
    if (!$edit) { flash('error', 'That record no longer exists.'); redirect(admin_url($t)); }
}
if ($t === 'schedules' && !$isAdmin && $a === 'new') { $a = 'list'; }

if ($a === 'roster') {
    $cls = q(SCHEDULE_SELECT . ' WHERE s.id = ?', [$id])->fetch();
    if (!$cls || (!$isAdmin && (int)$cls['instructor_id'] !== $ownInstructor)) {
        flash('error', 'Class not found.');
        redirect(admin_url('schedules'));
    }
    $people = class_roster($id);
}
if ($a === 'classes') {
    $rec = q('SELECT r.*, sec.code AS section_code, u.id AS user_id FROM student_records r
               LEFT JOIN sections sec ON sec.id = r.section_id LEFT JOIN users u ON u.student_record_id = r.id WHERE r.id = ?', [$id])->fetch();
    if (!$rec) {
        flash('error', 'Student not found.');
        redirect(admin_url('student_records'));
    }
    $inBlock = $rec['section_id'] ? q(SCHEDULE_SELECT . ' WHERE s.section_id = ? ORDER BY s.day_of_week, s.start_time', [$rec['section_id']])->fetchAll() : [];
    $extra = q(SCHEDULE_SELECT . ' WHERE s.id IN (SELECT schedule_id FROM student_classes WHERE record_id = ?) ORDER BY s.day_of_week, s.start_time', [$id])->fetchAll();
    $have = array_merge(array_column($inBlock, 'id'), array_column($extra, 'id'));
    $pool = q(SCHEDULE_SELECT . ($isAdmin ? '' : ' WHERE s.instructor_id = ' . $ownInstructor) . ' ORDER BY sec.code, s.day_of_week, s.start_time')->fetchAll();
    $pool = array_values(array_filter($pool, fn($r) => !in_array($r['id'], $have)));
}

// Administrator-only quick cards. Each count uses the same rule as the page the card opens.
$ops = null;
if ($isAdmin) {
    $one = function (string $sql): int { try { return (int)q($sql)->fetchColumn(); } catch (Throwable $e) { return 0; } };
    $ops = [
        'students'    => $one("SELECT COUNT(*) FROM users WHERE role = 'student' AND requested_role = 'student' AND status = 'approved'"),
        'instructors' => $one("SELECT COUNT(*) FROM users WHERE role IN ('instructor','staff') AND status = 'approved'"),
        'pending'     => pending_application_count(),
        'locations'   => $one('SELECT COUNT(*) FROM locations'),
        'schedules'   => $one('SELECT COUNT(*) FROM schedules'),
        'active7'     => $one('SELECT COUNT(*) FROM users WHERE last_login >= DATE_SUB(NOW(), INTERVAL 7 DAY)'),
        'logins24'    => $one("SELECT COUNT(*) FROM login_events WHERE role IN ('instructor','staff') AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"),
    ];
}
$showStats = $isAdmin && $_SERVER['REQUEST_METHOD'] === 'GET' && !isset($_GET['t']) && !isset($_GET['a']);
if ($showStats) { require __DIR__ . '/includes/stats.php'; }

render_head('Manage', 'admin');
?>
<div class="page-head">
  <div>
      <h1><?= $isAdmin ? 'Manage' : 'My Schedules' ?></h1>
      <p class="muted"><?= $isAdmin ? 'Administrator dashboard for schedules, records, calendar, and map data.' : 'Instructor dashboard. Your assigned classes and rosters are read-only and managed by the administrator.' ?></p>
    </div>
</div>

<?php if ($isAdmin && $ops): ?>
<section class="card" aria-labelledby="ops-title">
  <div class="card-head"><div><h2 id="ops-title">Administrator overview</h2><p class="muted">Select a card to open it. Counts are live database values.</p></div><span class="pill pill-live">Live</span></div>
  <div class="stat-grid">
    <?php foreach ([
        ['Students', $ops['students'], 'Approved accounts', 'verification.php?tab=students&f=approved', 'user'],
        ['Instructors', $ops['instructors'], 'Approved accounts', 'verification.php?tab=staff&role=instructor&f=approved', 'idcard'],
        ['Instructor applications', $ops['pending'], 'Review pending applications', 'verification.php?tab=pending', 'file'],
        ['Campus locations', $ops['locations'], 'Mapped places and facilities', 'admin.php?t=locations', 'pin'],
        ['Class schedules', $ops['schedules'], 'Configured schedule entries', 'admin.php?t=schedules', 'calendar'],
        ['Active accounts · 7 days', $ops['active7'], 'Users with a recent sign-in', 'verification.php?tab=accounts&f=active7', 'users'],
        ['Instructor sign-ins · 24 hours', $ops['logins24'], 'Recorded successful instructor sign-ins', 'verification.php?tab=logins&role=instructor&h=24', 'clock'],
    ] as [$lab, $n, $sub, $href, $ic]): ?>
      <a class="stat-card stat-link" href="<?= e($href) ?>"><span class="stat-ic"><?= icon($ic) ?></span><span class="muted"><?= e($lab) ?></span><strong><?= number_format($n) ?></strong><small><?= e($sub) ?></small></a>
    <?php endforeach; ?>
  </div>
  <div class="btn-row" style="margin-top:1rem">
    <a class="btn btn-ghost btn-small" href="verification.php?tab=pending">Instructor approvals</a>
    <a class="btn btn-ghost btn-small" href="map.php">Open campus map</a>
    <a class="btn btn-ghost btn-small" href="check.php">System diagnostics</a>
  </div>
</section>
<?php endif; ?>

<?php if ($showStats) { render_stats(stats_collect((string)($_GET['r'] ?? '30d'))); } ?>

<nav class="admin-tabs" aria-label="Admin sections">
  <?php foreach ($TABLES as $key => $def): if ($key === 'path_nodes') continue; // Walkway Points tab removed; routing data and routes are unaffected ?>
    <a href="<?= e(admin_url($key)) ?>"
       class="<?= $key === $t ? 'is-active' : '' ?>">
       <?= e($def['label']) ?>
    </a>
  <?php endforeach; ?>

</nav>

<?php foreach ($errors as $err): ?>
  <div class="notice notice-error" role="alert"><?= e($err) ?></div>
<?php endforeach; ?>

<?php if ($a === 'roster'): ?>
  <section class="card">
    <div class="card-head">
      <div>
        <h2><?= e($cls['subject_code']) ?> roster</h2>
        <p class="muted"><?= e($cls['section_code']) ?>, <?= e(day_name((int)$cls['day_of_week'])) ?> <?= e(fmt_time($cls['start_time'])) ?> to <?= e(fmt_time($cls['end_time'])) ?>, <?= e($cls['room_name'] ?? 'room TBA') ?></p>
      </div>
      <a class="btn btn-ghost btn-small" href="<?= e(admin_url('schedules')) ?>">Back</a>
    </div>
    <?php if (!$people): ?>
      <p class="muted">No students yet. Add them in <a class="link" href="<?= e(admin_url('student_records', ['a' => 'new'])) ?>">Student records</a> and put them in the block <?= e($cls['section_code']) ?>.</p>
    <?php else: ?>
      <p class="muted"><?= count($people) ?> student<?= count($people) === 1 ? '' : 's' ?>. "Verified" means the student made an account and confirmed this Student ID.</p>
      <div class="table-wrap"><table class="table">
        <thead><tr><th scope="col">Student ID</th><th scope="col">Name</th><th scope="col">Block</th><th scope="col">Account</th><th scope="col">How they get this class</th></tr></thead>
        <tbody>
        <?php foreach ($people as $p): ?>
          <tr>
            <td><?= e($p['student_no']) ?></td>
            <td><?= e($p['last_name'] . ', ' . $p['first_name']) ?></td>
            <td><?= e($p['section_code'] ?? '-') ?></td>
            <td><span class="pill <?= $p['has_account'] ? 'pill-live' : '' ?>"><?= $p['has_account'] ? 'Verified' : 'Not signed up yet' ?></span></td>
            <td><?= $p['individual'] ? 'Added to this student' : 'Part of the block' ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    <?php endif; ?>
  </section>

<?php elseif ($a === 'classes'): ?>
  <section class="card">
    <div class="card-head">
      <div>
        <h2><?= e($rec['first_name'] . ' ' . $rec['last_name']) ?></h2>
        <p class="muted">ID <?= e($rec['student_no']) ?>, block <?= e($rec['section_code'] ?? 'none') ?>. <?= $rec['user_id'] ? 'Account verified.' : 'Has not signed up yet. Their schedule appears as soon as they verify this ID.' ?></p>
      </div>
      <a class="btn btn-ghost btn-small" href="<?= e(admin_url('student_records')) ?>">Back</a>
    </div>

    <h3 class="day-sub">Classes from the block (<?= count($inBlock) ?>)</h3>
    <?php if (!$inBlock): ?><p class="muted">No block assigned. Pick a block in Edit.</p><?php else: ?>
      <ul class="mini-list static">
        <?php foreach ($inBlock as $r): ?>
          <li><span class="static-row"><time><?= e(day_short((int)$r['day_of_week'])) ?> <?= e(fmt_time($r['start_time'])) ?></time><span><strong><?= e($r['subject_code']) ?></strong> <?= e($r['room_name'] ?? 'room TBA') ?></span></span></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <h3 class="day-sub">Classes added to this student (<?= count($extra) ?>)</h3>
    <?php if (!$extra): ?><p class="muted">None.</p><?php else: ?>
      <ul class="mini-list static">
        <?php foreach ($extra as $r): ?>
          <li><span class="static-row"><time><?= e(day_short((int)$r['day_of_week'])) ?> <?= e(fmt_time($r['start_time'])) ?></time><span><strong><?= e($r['subject_code']) ?></strong> <?= e($r['section_code']) ?>, <?= e($r['room_name'] ?? 'room TBA') ?></span>
            <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="t" value="student_records"><input type="hidden" name="a" value="remove_class"><input type="hidden" name="id" value="<?= (int)$id ?>"><input type="hidden" name="schedule_id" value="<?= (int)$r['id'] ?>"><button class="btn btn-danger btn-small" type="submit">Remove</button></form></span></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <h3 class="day-sub">Add a class to this student</h3>
    <?php if (!$pool): ?><p class="muted">No other classes available to add.</p><?php else: ?>
      <form method="post" class="form form-wide">
        <?= csrf_field() ?>
        <input type="hidden" name="t" value="student_records"><input type="hidden" name="a" value="add_class"><input type="hidden" name="id" value="<?= (int)$id ?>">
        <label class="field"><span>Class</span>
          <select name="schedule_id" required>
            <option value="">Choose...</option>
            <?php foreach ($pool as $r): ?>
              <option value="<?= (int)$r['id'] ?>"><?= e($r['subject_code'] . ' (' . $r['section_code'] . ') ' . day_short((int)$r['day_of_week']) . ' ' . fmt_time($r['start_time']) . '-' . fmt_time($r['end_time']) . ', ' . ($r['room_name'] ?? 'room TBA')) ?></option>
            <?php endforeach; ?>
          </select>
          <small class="help">Use this for irregular students, transferees and extra subjects. It is checked for time clashes.</small></label>
        <button class="btn btn-primary" type="submit">Add class</button>
      </form>
    <?php endif; ?>
  </section>

<?php elseif ($a === 'list'): ?>
  <?php $rows = q($T['list'])->fetchAll(); ?>
  <section class="card">
    <div class="card-head">
      <h2><?= e($T['label']) ?> <small class="muted">(<?= count($rows) ?>)</small></h2>
      <?php if ($T['create'] ?? true): ?>
        <a class="btn btn-primary btn-small" href="<?= e(admin_url($t, ['a' => 'new'])) ?>">Add <?= e($T['singular']) ?></a>
      <?php endif; ?>
    </div>
    <?php if ($rows): ?>
      <label class="sr-only" for="filter">Filter rows</label>
      <input class="filter" id="filter" type="search" placeholder="Filter this list">
      <div class="table-wrap">
        <table class="table" id="admin-table">
          <thead><tr>
            <?php foreach (array_keys($rows[0]) as $h): if ($h === 'id') continue; ?><th scope="col"><?= e($h) ?></th><?php endforeach; ?>
            <th scope="col"><span class="sr-only">Actions</span></th>
          </tr></thead>
          <tbody>
          <?php foreach ($rows as $row): ?>
            <tr>
              <?php foreach ($row as $k => $v): if ($k === 'id') continue; ?><td><?= e($v) ?></td><?php endforeach; ?>
              <td class="actions">
                <?php if ($t === 'schedules'): ?><a class="btn btn-ghost btn-small" href="<?= e(admin_url($t, ['a' => 'roster', 'id' => $row['id']])) ?>">Roster</a><?php endif; ?>
                <?php if ($t === 'student_records'): ?><a class="btn btn-ghost btn-small" href="<?= e(admin_url($t, ['a' => 'classes', 'id' => $row['id']])) ?>">Classes</a><?php endif; ?>
                <?php if ($isAdmin || $t !== 'schedules'): ?><a class="btn btn-ghost btn-small" href="<?= e(admin_url($t, ['a' => 'edit', 'id' => $row['id']])) ?>">Edit</a><?php endif; ?>
                <?php if ($T['delete'] ?? true): ?>
                <form method="post" class="inline" onsubmit="return confirm('Delete this <?= e($T['singular']) ?>?');">
                  <?= csrf_field() ?>
                  <input type="hidden" name="t" value="<?= e($t) ?>">
                  <input type="hidden" name="a" value="delete">
                  <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                  <button class="btn btn-danger btn-small" type="submit">Delete</button>
                </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <p class="muted">Nothing here yet.</p>
    <?php endif; ?>
  </section>

<?php else:
    $values = $formValues ?: ($edit ?: []);
?>
  <section class="card">
    <div class="card-head"><h2><?= ($a === 'edit' ? 'Edit' : 'Add') . ' ' . e($T['singular']) ?></h2></div>
    <form method="post" class="form form-wide">
      <?= csrf_field() ?>
      <input type="hidden" name="t" value="<?= e($t) ?>">
      <input type="hidden" name="a" value="save">
      <input type="hidden" name="id" value="<?= $a === 'edit' ? (int)$id : 0 ?>">

      <?php foreach ($T['fields'] as $name => $f):
          $val = $values[$name] ?? '';
          if ($f['type'] === 'time' && is_string($val) && strlen($val) >= 5) $val = substr($val, 0, 5);
      ?>
        <label class="field">
          <span><?= e($f['label']) ?></span>
          <?php if ($f['type'] === 'select'): ?>
            <select name="<?= e($name) ?>">
              <?php foreach ($f['options'] as $ov => $ol): ?>
                <option value="<?= e($ov) ?>" <?= (string)$val === (string)$ov ? 'selected' : '' ?>><?= e($ol) ?></option>
              <?php endforeach; ?>
            </select>
          <?php elseif ($f['type'] === 'fk'): ?>
            <select name="<?= e($name) ?>" <?= empty($f['null']) ? 'required' : '' ?>>
              <option value="">
                <?= !empty($f['null']) ? 'None' : 'Choose...' ?>
              </option>
              <?php foreach (q($FK[$f['fk']])->fetchAll() as $o): ?>
                <option value="<?= (int)$o['id'] ?>" <?= (string)$val === (string)$o['id'] ? 'selected' : '' ?>><?= e($o['label']) ?></option>
              <?php endforeach; ?>
            </select>
          <?php else:
              $type = ['number' => 'number', 'time' => 'time', 'email' => 'email', 'date' => 'date'][$f['type']] ?? 'text';
          ?>
            <input type="<?= $type ?>" name="<?= e($name) ?>" value="<?= e($val) ?>"
              <?= $type === 'number' ? 'step="' . e($f['step'] ?? '1') . '"' : '' ?>
              <?= (empty($f['null']) && empty($f['empty'])) ? 'required' : '' ?>
              <?= isset($f['max']) ? 'maxlength="' . (int)$f['max'] . '"' : '' ?>>
          <?php endif; ?>
          <?php if (!empty($f['help'])): ?><small class="help"><?= e($f['help']) ?></small><?php endif; ?>
        </label>
      <?php endforeach; ?>

      <div class="btn-row">
        <button class="btn btn-primary" type="submit">Save</button>
        <a class="btn btn-ghost" href="<?= e(admin_url($t)) ?>">Cancel</a>
      </div>
    </form>
  </section>
<?php endif; ?>

<script>
(function () {
  var f = document.getElementById('filter');
  var t = document.getElementById('admin-table');
  if (!f || !t) return;
  f.addEventListener('input', function () {
    var q = f.value.toLowerCase();
    Array.prototype.forEach.call(t.tBodies[0].rows, function (r) {
      r.hidden = q !== '' && r.textContent.toLowerCase().indexOf(q) === -1;
    });
  });
})();
</script>
<?php render_foot('admin'); ?>
