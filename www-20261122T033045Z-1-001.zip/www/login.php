<?php
declare(strict_types=1);
$login_role = 'student';
require __DIR__ . '/includes/role_login.php';
