<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/verify.php';

$u = require_login();
$canVerify = in_array($u['mode'], ['guest', 'pending'], true);
$lockName  = $u['mode'] === 'student';   // a verified name matches the official record; ask staff to change it

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'verify' && $canVerify) {
        $errors = [];
        if (verify_student_id($u, (string)($_POST['student_no'] ?? ''), $errors)) {
            flash('ok', 'Student ID verified. Your schedule is ready.');
            redirect('schedule.php');
        }
        foreach ($errors as $err) flash('error', $err);
        redirect('settings.php#verify');
    }

    if ($action === 'profile') {
        $post = $_POST;
        if ($lockName) $post['full_name'] = $u['full_name'];
        $errors = [];
        $p = collect_profile($post, $errors);
        if ($p['mobile'] && q('SELECT 1 FROM users WHERE mobile = ? AND id <> ?', [$p['mobile'], $u['id']])->fetch()) {
            $errors[] = 'That mobile number is already used by another account.';
        }
        if ($errors) {
            foreach ($errors as $err) flash('error', $err);
        } else {
            q('UPDATE users SET full_name = ?, birthday = ?, address = ?, mobile = ? WHERE id = ?',
                [$p['full_name'], $p['birthday'], $p['address'], $p['mobile'], $u['id']]);
            flash('ok', 'Profile saved.');
        }
        redirect('settings.php');
    }

    if ($action === 'password') {
        $cur = (string)($_POST['current'] ?? '');
        $new = (string)($_POST['new'] ?? '');
        $row = q('SELECT password_hash FROM users WHERE id = ?', [$u['id']])->fetch();
        if (!rate_ok('chgpw', 5, 900)) {
            flash('error', 'Too many attempts. Try again in 15 minutes.');
        } elseif (!password_verify($cur, $row['password_hash'])) {
            audit('password_change_failed', 'user', (int)$u['id'], 'wrong current password');
            flash('error', 'Your current password is incorrect.');
        } elseif ($problem = password_problem($new, (string)$u['email'], is_staff($u))) {
            flash('error', $problem);
        } else {
            q('UPDATE users SET password_hash = ?, password_changed_at = NOW() WHERE id = ?', [hash_password($new), $u['id']]);
            $_SESSION['auth_at'] = time();            // this session stays signed in; all others are signed out
            audit('password_changed', 'user', (int)$u['id'], '');
            flash('ok', 'Password changed. Other devices were signed out.');
        }
        redirect('settings.php');
    }
}

$age = age_from_birthday($u['birthday']);
render_head('Settings', 'account');
?>
<div class="page-head"><div><h1>Settings</h1><p class="muted"><?= e($u['email']) ?></p></div></div>

<div class="account-grid">
  <?php if ($canVerify): ?>
    <section class="card card-accent" id="verify">
      <div class="card-head"><h2><?= icon('idcard') ?> Verify your Student ID</h2></div>
      <p class="muted">All NEMSU students confirm their Student ID. Once it matches the official records, your schedule, subjects and instructors unlock.</p>
      <form method="post" class="form">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="verify">
        <label class="field"><span>Student ID number</span>
          <input type="text" name="student_no" placeholder="24-00000" autocomplete="off" autocapitalize="characters" required maxlength="30"></label>
        <button class="btn btn-primary" type="submit"><?= icon('user-check') ?> Verify Student ID</button>
        <small class="help">We compare it with the name in your profile (<?= e($u['full_name']) ?>). If it does not match, update your name below or ask your instructor or the Registrar.</small>
      </form>
    </section>
  <?php endif; ?>

  <section class="card">
    <div class="card-head"><h2>Personal information</h2></div>
    <dl class="facts">
      <div><dt>Role</dt><dd><?= e(mode_label($u)) ?></dd></div>
      <?php if ($u['mode'] === 'student'): ?>
        <div><dt>Student ID</dt><dd><?= e($u['student_no']) ?></dd></div>
        <div><dt>Block</dt><dd><?= e($u['section_code'] ?? 'Not assigned yet') ?></dd></div>
        <div><dt>Program</dt><dd><?= e($u['section_program'] ?? '') ?></dd></div>
      <?php endif; ?>
      <?php if ($age !== null): ?><div><dt>Age</dt><dd><?= (int)$age ?></dd></div><?php endif; ?>
    </dl>
    <form method="post" class="form">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="profile">
      <label class="field"><span>Full name</span>
        <input type="text" name="full_name" value="<?= e($u['full_name']) ?>" <?= $lockName ? 'readonly' : 'required' ?> maxlength="120">
        <?php if ($lockName): ?><small class="help">Your name is tied to your Student ID. Ask the Registrar if it needs correcting.</small><?php endif; ?></label>
      <label class="field"><span>Birthday</span>
        <input type="date" name="birthday" value="<?= e($u['birthday'] ?? '') ?>" max="<?= e(date('Y-m-d')) ?>" required></label>
      <label class="field"><span>Address</span>
        <textarea name="address" rows="2" maxlength="250" required><?= e($u['address'] ?? '') ?></textarea></label>
      <label class="field"><span>Mobile number</span>
        <input type="tel" name="mobile" value="<?= e($u['mobile'] ?? '') ?>" placeholder="0917 123 4567" inputmode="tel"></label>
      <button class="btn btn-primary" type="submit">Save changes</button>
    </form>
  </section>

  <section class="card">
    <div class="card-head"><h2>Change password</h2></div>
    <form method="post" class="form">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="password">
      <label class="field"><span>Current password</span><input type="password" name="current" autocomplete="current-password" required></label>
      <label class="field"><span>New password</span><input type="password" name="new" autocomplete="new-password" minlength="12" required></label>
      <button class="btn btn-primary" type="submit">Save password</button>
    </form>
    <form method="post" action="logout.php" class="logout-form">
      <?= csrf_field() ?>
      <button class="btn btn-ghost" type="submit"><?= icon('logout') ?> Log out</button>
    </form>
  </section>
</div>
<?php render_foot('account'); ?>
