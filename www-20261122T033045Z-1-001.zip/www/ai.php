<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/schedule.php';
require __DIR__ . '/includes/ai.php';

$u = require_login();
$access = has_schedule_access($u);
$boot = ['mode' => $u['mode'], 'first' => first_name($u), 'q' => isset($_GET['q']) ? mb_substr((string)$_GET['q'], 0, 400) : ''];

render_head('Ask AI', 'ai', ['bleed' => true]);
?>
<div class="chat-layout">
  <section class="chat" aria-label="Chat with the assistant">
    <header class="chat-head">
      <span class="chat-avatar"><?= icon('ai') ?></span>
      <div>
        <h1>Campus assistant</h1>
        <p class="muted"><?= $access ? 'Knows your schedule and the campus map' : 'Knows the campus map' ?></p>
      </div>
    </header>

    <div class="chat-log" id="chat-log" aria-live="polite"></div>

    <div class="chat-chips" id="chat-chips"></div>

    <form class="chat-form" id="chat-form" autocomplete="off">
      <label class="sr-only" for="chat-input">Message</label>
      <input id="chat-input" type="text" maxlength="400" placeholder="<?= $access ? 'Ask about a class or a place' : 'Ask where something is' ?>" enterkeyhint="send">
      <button class="send" type="submit" aria-label="Send"><?= icon('send') ?></button>
    </form>
  </section>

  <aside class="chat-side">
    <h2>Try asking</h2>
    <ul class="mini-list">
      <?php if ($access): ?>
        <li><button type="button" data-ask="What time is my class this morning?">What time is my class this morning?<?= icon('chevron') ?></button></li>
        <li><button type="button" data-ask="Where is my next class?">Where is my next class?<?= icon('chevron') ?></button></li>
        <li><button type="button" data-ask="I have class in 20 minutes. Where should I go?">I have class in 20 minutes. Where should I go?<?= icon('chevron') ?></button></li>
        <li><button type="button" data-ask="Who teaches my next class?">Who teaches my next class?<?= icon('chevron') ?></button></li>
      <?php endif; ?>
      <li><button type="button" data-ask="Where is the Registrar's Office?">Where is the Registrar's Office?<?= icon('chevron') ?></button></li>
      <li><button type="button" data-ask="Where is CITE Laboratory 1?">Where is CITE Laboratory 1?<?= icon('chevron') ?></button></li>
      <?php if ($u['mode'] === 'instructor'): ?>
        <li><button type="button" data-ask="Who are my students in my next class?">Who are my students in my next class?<?= icon('chevron') ?></button></li>
      <?php endif; ?>
      <li><button type="button" data-ask="What buildings are on campus?">What buildings are on campus?<?= icon('chevron') ?></button></li>
    </ul>
  </aside>
</div>
<script>window.CN_AI = <?= json_encode($boot, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<?php render_foot('ai', ['assets/js/ai.js?v=4']); ?>
