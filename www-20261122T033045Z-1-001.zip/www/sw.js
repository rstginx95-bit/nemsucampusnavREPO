/* NEMSU CampusNav service worker: caches styles, scripts, icons and viewed map tiles so the app opens fast.
   Pages and API calls always try the network first (schedules must be current). */
const CACHE = 'campusnav-v4';
const ASSETS = [
  'assets/css/app.css?v=4',
  'assets/js/app.js?v=4',
  'assets/js/map.js?v=4',
  'assets/js/ai.js?v=4',
  'assets/js/calendar.js?v=4',
  'assets/js/onboarding.js?v=4',
  'assets/js/import.js?v=4',
  'assets/icons/icon.svg',
  'manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Map tiles: cache what the user has seen so the campus stays visible offline.
  if (url.hostname === 'tile.openstreetmap.org') {
    event.respondWith(
      caches.open(CACHE + '-tiles').then((cache) =>
        cache.match(req).then((hit) => hit || fetch(req).then((res) => {
          if (res.ok) cache.put(req, res.clone());
          return res;
        }).catch(() => hit))
      )
    );
    return;
  }

  if (url.origin !== location.origin) return;

  // Styles, scripts, icons: always try the network first so updates show up, fall back to the cache offline.
  if (url.pathname.includes('/assets/') || url.pathname.endsWith('manifest.json')) {
    event.respondWith(
      fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(req, copy));
        return res;
      }).catch(() => caches.match(req))
    );
    return;
  }
  // Everything else (pages, API): network only, never serve stale schedules.
});
