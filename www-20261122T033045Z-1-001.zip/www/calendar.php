<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/schedule.php';

$u = require_login();
render_head('Calendar', 'calendar');
?>
<div class="page-head">
  <div>
    <h1>NEMSU calendar</h1>
    <p class="muted">Academic dates, exams, holidays and events<?= has_schedule_access($u) ? ', with your weekly classes' : '' ?></p>
  </div>
  <?php if (is_staff($u)): ?>
    <a class="btn btn-primary btn-small" href="admin.php?t=calendar_events&amp;a=new">Add date</a>
  <?php endif; ?>
</div>

<div class="cal-layout">
  <section class="card cal-card" aria-label="Month view">
    <div class="cal-head">
      <button type="button" class="icon-btn icon-btn-quiet" id="cal-prev" aria-label="Previous month"><?= icon('chevron-left') ?></button>
      <h2 id="cal-title" aria-live="polite"></h2>
      <button type="button" class="icon-btn icon-btn-quiet" id="cal-next" aria-label="Next month"><?= icon('chevron') ?></button>
      <button type="button" class="btn btn-ghost btn-small" id="cal-today">Today</button>
    </div>
    <div class="cal-legend" aria-hidden="true">
      <span class="cat-academic">Academic</span><span class="cat-exam">Exams</span><span class="cat-holiday">Holidays</span><span class="cat-event">Events</span>
      <?php if (has_schedule_access($u)): ?><span class="cat-class">My classes</span><?php endif; ?>
    </div>
    <div class="cal-grid" id="cal-grid" role="grid" aria-labelledby="cal-title"></div>
  </section>

  <section class="card cal-day" aria-live="polite">
    <h2 id="day-title">Select a day</h2>
    <div id="day-body"><p class="muted">Tap a date to see what is happening.</p></div>
  </section>
</div>
<script>window.CN_CAL = <?= json_encode(['schedule' => has_schedule_access($u)], JSON_HEX_TAG | JSON_HEX_AMP) ?>;</script>
<?php render_foot('calendar', ['assets/js/calendar.js?v=4']); ?>
