<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/locations.php';
require __DIR__ . '/includes/schedule.php';

$u      = require_login();
$now    = new DateTimeImmutable('now');
$access = has_schedule_access($u);
$rows   = $access ? user_schedule($u) : [];
$changed = $access ? recently_changed_ids($u) : [];
$todayN = (int)$now->format('N');

$selected = isset($_GET['day']) ? max(1, min(7, (int)$_GET['day'])) : $todayN;
$days = [];
foreach ([1, 2, 3, 4, 5, 6] as $d) {
    $days[$d] = classes_on_day($rows, $d);
}
if ($rows && classes_on_day($rows, 7)) {
    $days[7] = classes_on_day($rows, 7);
}

function class_card(array $r, array $u, array $changed, ?DateTimeImmutable $now = null, bool $showState = false): void
{
    $state = $showState ? class_state($r, $now) : 'other';
    ?>
    <article class="class-card state-<?= e($state) ?>">
      <div class="class-time">
        <strong><?= e($r['start']) ?></strong>
        <span><?= e($r['end']) ?></span>
      </div>
      <div class="class-body">
        <h3>
          <?= e($r['subject_code']) ?>
          <?php if (in_array($r['id'], $changed, true)): ?><span class="pill pill-warn">Updated</span><?php endif; ?>
          <?php if ($state === 'now'): ?><span class="pill pill-live">Now</span><?php endif; ?>
        </h3>
        <p class="class-title"><?= e($r['subject_title']) ?></p>
        <dl class="class-facts">
          <?php if ($u['mode'] === 'instructor'): ?>
            <div><dt>Block</dt><dd><?= e($r['section_code']) ?></dd></div>
          <?php else: ?>
            <div><dt>Instructor</dt><dd><?= e($r['instructor_name'] ?? 'To be announced') ?></dd></div>
          <?php endif; ?>
          <div><dt>Room</dt><dd><?= e($r['place']) ?></dd></div>
        </dl>
      </div>
      <?php if ($r['room_id']): ?>
        <a class="icon-btn" href="map.php?to=<?= (int)$r['room_id'] ?>" aria-label="Navigate to <?= e($r['room_name']) ?>"><?= icon('nav') ?></a>
      <?php endif; ?>
    </article>
    <?php
}

render_head('Schedule', 'schedule');
?>
<div class="page-head">
  <div>
    <h1>Schedule</h1>
    <?php if ($u['mode'] === 'student'): ?>
      <p class="muted"><?= e($u['section_code'] ?? 'No block assigned') ?>, <?= e($u['section_program'] ?? '') ?></p>
    <?php elseif ($u['mode'] === 'instructor'): ?>
      <p class="muted">Your assigned classes</p>
    <?php endif; ?>
  </div>
</div>

<?php if (!$access): ?>
  <section class="card unlock">
    <div class="unlock-icon"><?= icon('lock') ?></div>
    <div>
      <?php if ($u['mode'] === 'guest'): ?>
        <h2>Your schedule is locked</h2>
        <p class="muted">Add your Student ID to confirm you are a NEMSU student. Then your subjects, instructors, rooms and block appear here. The map and AI assistant already work.</p>
        <a class="btn btn-primary" href="settings.php#verify"><?= icon('idcard') ?> Add my Student ID</a>
      <?php else: ?>
        <h2>No personal schedule</h2>
        <p class="muted">You are not assigned to teach any class yet. Manage schedules from the Manage page.</p>
        <a class="btn btn-primary" href="admin.php">Open Manage</a>
      <?php endif; ?>
    </div>
  </section>
<?php else: ?>

  <?php $changes = recent_changes($u); if ($changes): ?>
    <section class="notice notice-warn">
      <?= icon('alert') ?>
      <div><strong>Recent changes</strong>
        <?php foreach ($changes as $c): ?><p><?= e($c['summary']) ?></p><?php endforeach; ?>
      </div>
    </section>
  <?php endif; ?>

  <?php if (!$rows): ?>
    <section class="card empty"><h2>Nothing scheduled yet</h2><p class="muted">Your classes will appear here once the registrar assigns your block.</p></section>
  <?php else: ?>

  <!-- Mobile: day tabs + list -->
  <div class="day-view">
    <div class="day-tabs" role="tablist" aria-label="Day of the week">
      <?php foreach ($days as $d => $list): ?>
        <a role="tab" href="schedule.php?day=<?= $d ?>" aria-selected="<?= $d === $selected ? 'true' : 'false' ?>"
           class="day-tab<?= $d === $selected ? ' is-active' : '' ?><?= $d === $todayN ? ' is-today' : '' ?>">
          <span><?= e(day_short($d)) ?></span>
          <small><?= count($list) ?></small>
        </a>
      <?php endforeach; ?>
    </div>
    <h2 class="day-title"><?= e(day_name($selected)) ?><?= $selected === $todayN ? ' (today)' : '' ?></h2>
    <?php $list = classes_on_day($rows, $selected); if (!$list): ?>
      <p class="muted empty-line">No classes on <?= e(day_name($selected)) ?>.</p>
    <?php else: foreach ($list as $r) { class_card($r, $u, $changed, $now, $selected === $todayN); } endif; ?>
  </div>

  <!-- Desktop: weekly board -->
  <div class="week-view">
    <?php foreach ($days as $d => $list): ?>
      <section class="week-col<?= $d === $todayN ? ' is-today' : '' ?>">
        <h2><?= e(day_name($d)) ?></h2>
        <?php if (!$list): ?><p class="muted empty-line">No classes</p><?php endif; ?>
        <?php foreach ($list as $r) { class_card($r, $u, $changed, $now, $d === $todayN); } ?>
      </section>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
<?php endif; ?>
<?php render_foot('schedule'); ?>
