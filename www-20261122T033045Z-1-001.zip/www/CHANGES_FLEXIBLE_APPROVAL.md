# Changes: flexible instructor approval (Admin authority)

## Modified
| File | What changed |
|---|---|
| `verification.php` | Applications tab: missing-requirements panel, 3-way decision form (Approve / Keep pending / Reject), remarks, exception acknowledgement, confirm dialog; new **Decisions** tab; old approve/reject/more handlers replaced by one audited path |
| `includes/staff_verify.php` | `staff_approve/reject/request_more` can defer email; `activation_send` lists outstanding items and returns result; bulk approval now records decisions |
| `includes/mailer.php` | `send_mail` logs each attempt to `email_log`, distinguishes accepted-by-SMTP / logged-only / failed; removed stray blank line before `<?php` |
| `register.php` | Optional proof-of-employment upload on the instructor form (PDF/JPG/PNG, 3 MB, content-checked) |
| `status.php` | Pending applicants can upload an additional document |
| `config.php`, `developer.php`, `map.php` | Removed stray blank line before `<?php` (output before headers) |
| `assets/css/app.css` | Styles for the new panel (appended only) |
| `database/schema.sql` | Appended the 3 new tables for fresh installs |

## New
`includes/app_review.php`, `application-document.php` (Admin-only download), `database/migrations/002_flexible_instructor_approval.sql`,
`.htaccess` deny rules in `database/`, `includes/`, `storage/`, `storage/applications/`, `docs/preview/admin-review-preview.html`, this file, `MIGRATION_GUIDE.md`.

## Behaviour
- Admin sees every requirement, met or missing, before deciding. Requirements: email verified (**cannot be waived**), ID/department submitted, official roster match, proof document.
- Approve is allowed with soft requirements missing; the Admin must tick an acknowledgement; remarks optional. The missing list is recomputed on the server.
- Keep pending requires remarks, which are emailed to the applicant as what is needed. Reject remarks stay internal.
- Each decision stores admin, date/time, remarks, missing list and email outcome (`application_decisions`) plus an `audit_log` entry (`approval_exception` for exceptions).
- Approval uses the existing activation flow, so the account gets Instructor access only after the applicant activates it.
- Server-side: `require_admin()`, CSRF, password re-entry, row lock + status re-check (no double decisions), Admin cannot decide own application.

## Not done / limitations
See the chat summary: PHP was not available to run this code, so nothing here has been executed.
